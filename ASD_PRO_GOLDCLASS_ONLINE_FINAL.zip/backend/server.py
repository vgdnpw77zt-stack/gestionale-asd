"""
ASD Master - Backend API
Software gestionale per Associazione Sportiva Dilettantistica.
Single-tenant, MongoDB-backed, MVP fully functional for local Mac usage.
"""
from fastapi import FastAPI, APIRouter, HTTPException, Depends, UploadFile, File, Form, Query
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import io
import json
import base64
import zipfile
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Any, Dict
from datetime import datetime, timezone, timedelta, date
import uuid
import jwt
import asyncio
import csv
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr

# PDF (reportlab)
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage

# Stripe
import stripe as stripe_sdk
from fastapi import Request as FastAPIRequest

# XML per FatturaPA SdI
from xml.etree import ElementTree as ET
from xml.dom import minidom

# bcrypt
import bcrypt

# ---- Setup ----
ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

MONGO_URL = os.environ['MONGO_URL']
DB_NAME = os.environ['DB_NAME']
JWT_SECRET = os.environ.get('JWT_SECRET', 'change-me')
JWT_EXPIRE_HOURS = int(os.environ.get('JWT_EXPIRE_HOURS', '24'))
ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME', 'admin')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'admin123')
EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY', '')
RESEND_API_KEY = os.environ.get('RESEND_API_KEY', '')
RESEND_SENDER = os.environ.get('SENDER_EMAIL', 'onboarding@resend.dev')
STRIPE_SECRET_KEY = os.environ.get('STRIPE_SECRET_KEY', '')
STRIPE_WEBHOOK_SECRET = os.environ.get('STRIPE_WEBHOOK_SECRET', '')
stripe_sdk.api_key = STRIPE_SECRET_KEY

# Ruoli utente
ROLES = ("admin", "presidente", "segretario", "istruttore", "lettore")


def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()

def check_password(pw: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(pw.encode(), hashed.encode())
    except Exception:
        return False

client = AsyncIOMotorClient(MONGO_URL)
db = client[DB_NAME]

app = FastAPI(title="ASD Master API")
api = APIRouter(prefix="/api")
security = HTTPBearer(auto_error=False)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("asd")


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id() -> str:
    return str(uuid.uuid4())


# ---- Auth ----
class LoginRequest(BaseModel):
    username: str
    password: str


class RegisterRequest(BaseModel):
    username: str
    email: str
    password: str
    full_name: Optional[str] = ""
    role: Optional[str] = "lettore"


def create_token(username: str, role: str = "admin") -> str:
    payload = {
        "sub": username,
        "role": role,
        "exp": datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRE_HOURS),
        "iat": datetime.now(timezone.utc),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


async def _bootstrap_admin() -> None:
    """Seed admin utente dal .env se non esistono utenti."""
    count = await db.users.count_documents({})
    if count == 0 and ADMIN_USERNAME and ADMIN_PASSWORD:
        await db.users.insert_one({
            "id": new_id(),
            "username": ADMIN_USERNAME,
            "email": f"{ADMIN_USERNAME}@asd.local",
            "full_name": "Amministratore",
            "password_hash": hash_password(ADMIN_PASSWORD),
            "role": "admin",
            "status": "approved",
            "created_at": now_iso(),
        })


async def _get_user_by_username(username: str) -> Optional[Dict[str, Any]]:
    u = await db.users.find_one({"$or": [{"username": username}, {"email": username}]})
    return clean_doc(u) if u else None


async def require_auth(creds: HTTPAuthorizationCredentials = Depends(security)) -> Dict[str, Any]:
    if not creds or not creds.credentials:
        raise HTTPException(status_code=401, detail="Non autenticato")
    try:
        payload = jwt.decode(creds.credentials, JWT_SECRET, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token scaduto")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Token non valido")
    u = await _get_user_by_username(payload.get("sub", ""))
    if not u:
        # fallback ambiente base (compat) — accetta il token
        return {"username": payload.get("sub"), "role": payload.get("role", "admin"), "status": "approved"}
    if u.get("status") != "approved":
        raise HTTPException(status_code=403, detail="Utente non ancora approvato")
    return u


def require_role(*allowed: str):
    async def dep(user: Dict[str, Any] = Depends(require_auth)) -> Dict[str, Any]:
        if user.get("role") not in allowed and user.get("role") != "admin":
            raise HTTPException(403, "Permesso negato")
        return user
    return dep


@api.post("/auth/login")
async def login(req: LoginRequest):
    await _bootstrap_admin()
    u = await _get_user_by_username(req.username)
    if u:
        if u.get("status") != "approved":
            raise HTTPException(403, "Utente in attesa di approvazione")
        if not check_password(req.password, u.get("password_hash", "")):
            raise HTTPException(401, "Credenziali non valide")
        token = create_token(u["username"], u.get("role", "lettore"))
        return {"token": token, "username": u["username"], "role": u.get("role"), "full_name": u.get("full_name",""), "expires_in_hours": JWT_EXPIRE_HOURS}
    # bootstrap fallback for ADMIN_USERNAME (edge case: DB wiped)
    if req.username == ADMIN_USERNAME and req.password == ADMIN_PASSWORD:
        await _bootstrap_admin()
        token = create_token(ADMIN_USERNAME, "admin")
        return {"token": token, "username": ADMIN_USERNAME, "role": "admin", "expires_in_hours": JWT_EXPIRE_HOURS}
    raise HTTPException(401, "Credenziali non valide")


@api.post("/auth/register")
async def register(req: RegisterRequest):
    if len(req.password) < 6:
        raise HTTPException(400, "Password troppo corta (min 6 caratteri)")
    if req.role not in ROLES:
        raise HTTPException(400, "Ruolo non valido")
    if await db.users.find_one({"$or": [{"username": req.username}, {"email": req.email}]}):
        raise HTTPException(400, "Utente o email già esistenti")
    doc = {
        "id": new_id(),
        "username": req.username,
        "email": req.email,
        "full_name": req.full_name or "",
        "password_hash": hash_password(req.password),
        "role": req.role,
        "status": "pending",
        "created_at": now_iso(),
    }
    await db.users.insert_one(doc)
    return {"ok": True, "message": "Registrazione ricevuta. In attesa di approvazione admin."}


@api.get("/auth/me")
async def me(user: Dict[str, Any] = Depends(require_auth)):
    return {"username": user.get("username"), "role": user.get("role"), "full_name": user.get("full_name","")}


@api.get("/users")
async def list_users(user: Dict[str, Any] = Depends(require_role("admin"))):
    docs = await db.users.find({}, {"password_hash": 0}).sort("created_at", -1).to_list(500)
    return [clean_doc(d) for d in docs]


@api.post("/users/{uid}/approve")
async def approve_user(uid: str, user: Dict[str, Any] = Depends(require_role("admin"))):
    r = await db.users.update_one({"id": uid}, {"$set": {"status": "approved"}})
    if r.matched_count == 0: raise HTTPException(404, "Utente non trovato")
    return {"ok": True}


@api.post("/users/{uid}/disable")
async def disable_user(uid: str, user: Dict[str, Any] = Depends(require_role("admin"))):
    await db.users.update_one({"id": uid}, {"$set": {"status": "disabled"}})
    return {"ok": True}


class RoleChange(BaseModel):
    role: str


@api.put("/users/{uid}/role")
async def change_role(uid: str, req: RoleChange, user: Dict[str, Any] = Depends(require_role("admin"))):
    if req.role not in ROLES:
        raise HTTPException(400, "Ruolo non valido")
    await db.users.update_one({"id": uid}, {"$set": {"role": req.role}})
    return {"ok": True}


@api.delete("/users/{uid}")
async def delete_user(uid: str, user: Dict[str, Any] = Depends(require_role("admin"))):
    if user.get("id") == uid:
        raise HTTPException(400, "Non puoi eliminare te stesso")
    await db.users.delete_one({"id": uid})
    return {"ok": True}


# ---- Common models ----
def clean_doc(d: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if d is None:
        return None
    d.pop('_id', None)
    return d


# ---- Impostazioni ASD ----
SETTINGS_ID = "asd_settings_singleton"

class Settings(BaseModel):
    id: str = Field(default=SETTINGS_ID)
    ragione_sociale: str = "ASD Master"
    codice_fiscale: str = ""
    partita_iva: str = ""
    n_registro_coni: str = ""
    presidente: str = ""
    indirizzo: str = ""
    citta: str = ""
    cap: str = ""
    provincia: str = ""
    telefono: str = ""
    email: str = ""
    iban: str = ""
    logo_base64: str = ""  # data URL or base64
    # SMTP config per invio email (opzionale)
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from_email: str = ""
    smtp_from_name: str = ""
    smtp_use_tls: bool = True
    updated_at: str = Field(default_factory=now_iso)


@api.get("/settings")
async def get_settings(_: str = Depends(require_auth)):
    doc = await db.settings.find_one({"id": SETTINGS_ID})
    if not doc:
        s = Settings()
        await db.settings.insert_one(s.model_dump())
        return s.model_dump()
    return clean_doc(doc)


@api.put("/settings")
async def update_settings(payload: Dict[str, Any], _: str = Depends(require_auth)):
    payload["id"] = SETTINGS_ID
    payload["updated_at"] = now_iso()
    await db.settings.update_one({"id": SETTINGS_ID}, {"$set": payload}, upsert=True)
    doc = await db.settings.find_one({"id": SETTINGS_ID})
    return clean_doc(doc)


# ---- Soci ----
class Socio(BaseModel):
    id: str = Field(default_factory=new_id)
    nome: str
    cognome: str
    codice_fiscale: str = ""
    data_nascita: str = ""  # ISO date string
    luogo_nascita: str = ""
    sesso: str = ""  # M/F
    indirizzo: str = ""
    citta: str = ""
    cap: str = ""
    provincia: str = ""
    telefono: str = ""
    email: str = ""
    disciplina: str = ""  # Calcio / Basket / etc
    ruolo: str = "Socio"  # Socio / Atleta / Istruttore / Dirigente
    contatto_emergenza_nome: str = ""
    contatto_emergenza_telefono: str = ""
    note: str = ""
    foto_base64: str = ""
    attivo: bool = True
    created_at: str = Field(default_factory=now_iso)
    updated_at: str = Field(default_factory=now_iso)


@api.get("/soci")
async def list_soci(q: Optional[str] = None, disciplina: Optional[str] = None, attivo: Optional[bool] = None, _: str = Depends(require_auth)):
    query: Dict[str, Any] = {}
    if disciplina:
        query["disciplina"] = disciplina
    if attivo is not None:
        query["attivo"] = attivo
    if q:
        query["$or"] = [
            {"nome": {"$regex": q, "$options": "i"}},
            {"cognome": {"$regex": q, "$options": "i"}},
            {"codice_fiscale": {"$regex": q, "$options": "i"}},
            {"email": {"$regex": q, "$options": "i"}},
        ]
    docs = await db.soci.find(query).sort("cognome", 1).to_list(5000)
    return [clean_doc(d) for d in docs]


@api.post("/soci")
async def create_socio(payload: Socio, _: str = Depends(require_auth)):
    doc = payload.model_dump()
    await db.soci.insert_one(doc)
    return clean_doc(doc)


@api.get("/soci/{socio_id}")
async def get_socio(socio_id: str, _: str = Depends(require_auth)):
    doc = await db.soci.find_one({"id": socio_id})
    if not doc:
        raise HTTPException(404, "Socio non trovato")
    return clean_doc(doc)


@api.put("/soci/{socio_id}")
async def update_socio(socio_id: str, payload: Dict[str, Any], _: str = Depends(require_auth)):
    payload.pop("id", None)
    payload["updated_at"] = now_iso()
    res = await db.soci.update_one({"id": socio_id}, {"$set": payload})
    if res.matched_count == 0:
        raise HTTPException(404, "Socio non trovato")
    doc = await db.soci.find_one({"id": socio_id})
    return clean_doc(doc)


@api.delete("/soci/{socio_id}")
async def delete_socio(socio_id: str, _: str = Depends(require_auth)):
    await db.soci.delete_one({"id": socio_id})
    # cascade cleanup
    await db.tesseramenti.delete_many({"socio_id": socio_id})
    await db.pagamenti.delete_many({"socio_id": socio_id})
    await db.certificati.delete_many({"socio_id": socio_id})
    await db.documenti.delete_many({"socio_id": socio_id})
    await db.presenze.delete_many({"socio_id": socio_id})
    return {"ok": True}


# ---- Tesseramenti ----
class Tesseramento(BaseModel):
    id: str = Field(default_factory=new_id)
    socio_id: str
    stagione: str  # 2024/2025
    ente: str  # CSEN / UISP / ASI / FIP / FIGC ...
    numero_tessera: str = ""
    data_emissione: str = ""
    data_scadenza: str = ""
    note: str = ""
    created_at: str = Field(default_factory=now_iso)


@api.get("/tesseramenti")
async def list_tesseramenti(socio_id: Optional[str] = None, stagione: Optional[str] = None, _: str = Depends(require_auth)):
    q: Dict[str, Any] = {}
    if socio_id: q["socio_id"] = socio_id
    if stagione: q["stagione"] = stagione
    docs = await db.tesseramenti.find(q).sort("data_emissione", -1).to_list(5000)
    return [clean_doc(d) for d in docs]


@api.post("/tesseramenti")
async def create_tesseramento(payload: Tesseramento, _: str = Depends(require_auth)):
    doc = payload.model_dump()
    await db.tesseramenti.insert_one(doc)
    return clean_doc(doc)


@api.put("/tesseramenti/{tid}")
async def update_tesseramento(tid: str, payload: Dict[str, Any], _: str = Depends(require_auth)):
    payload.pop("id", None)
    res = await db.tesseramenti.update_one({"id": tid}, {"$set": payload})
    if res.matched_count == 0:
        raise HTTPException(404, "Tesseramento non trovato")
    return clean_doc(await db.tesseramenti.find_one({"id": tid}))


@api.delete("/tesseramenti/{tid}")
async def delete_tesseramento(tid: str, _: str = Depends(require_auth)):
    await db.tesseramenti.delete_one({"id": tid})
    return {"ok": True}


# ---- Pagamenti / Quote ----
class Pagamento(BaseModel):
    id: str = Field(default_factory=new_id)
    socio_id: str
    numero_ricevuta: str = ""  # progressivo
    causale: str
    importo: float
    metodo: str = "Contanti"  # Contanti / Bonifico / POS / Assegno
    data_pagamento: str  # ISO
    stagione: str = ""
    note: str = ""
    created_at: str = Field(default_factory=now_iso)


@api.get("/pagamenti")
async def list_pagamenti(socio_id: Optional[str] = None, stagione: Optional[str] = None, _: str = Depends(require_auth)):
    q: Dict[str, Any] = {}
    if socio_id: q["socio_id"] = socio_id
    if stagione: q["stagione"] = stagione
    docs = await db.pagamenti.find(q).sort("data_pagamento", -1).to_list(10000)
    return [clean_doc(d) for d in docs]


async def _next_ricevuta_number() -> str:
    year = datetime.now(timezone.utc).year
    prefix = f"{year}-"
    count = await db.pagamenti.count_documents({"numero_ricevuta": {"$regex": f"^{prefix}"}})
    return f"{prefix}{count + 1:04d}"


@api.post("/pagamenti")
async def create_pagamento(payload: Pagamento, _: str = Depends(require_auth)):
    doc = payload.model_dump()
    if not doc.get("numero_ricevuta"):
        doc["numero_ricevuta"] = await _next_ricevuta_number()
    await db.pagamenti.insert_one(doc)
    return clean_doc(doc)


@api.put("/pagamenti/{pid}")
async def update_pagamento(pid: str, payload: Dict[str, Any], _: str = Depends(require_auth)):
    payload.pop("id", None)
    res = await db.pagamenti.update_one({"id": pid}, {"$set": payload})
    if res.matched_count == 0:
        raise HTTPException(404, "Pagamento non trovato")
    return clean_doc(await db.pagamenti.find_one({"id": pid}))


@api.delete("/pagamenti/{pid}")
async def delete_pagamento(pid: str, _: str = Depends(require_auth)):
    await db.pagamenti.delete_one({"id": pid})
    return {"ok": True}


# ---- Certificati Medici ----
class Certificato(BaseModel):
    id: str = Field(default_factory=new_id)
    socio_id: str
    tipo: str = "non_agonistico"  # agonistico / non_agonistico
    data_rilascio: str
    data_scadenza: str
    medico: str = ""
    struttura: str = ""
    file_base64: str = ""  # optional scan
    file_name: str = ""
    note: str = ""
    created_at: str = Field(default_factory=now_iso)


@api.get("/certificati")
async def list_certificati(socio_id: Optional[str] = None, stato: Optional[str] = None, _: str = Depends(require_auth)):
    q: Dict[str, Any] = {}
    if socio_id: q["socio_id"] = socio_id
    docs = await db.certificati.find(q).sort("data_scadenza", 1).to_list(10000)
    result = [clean_doc(d) for d in docs]
    today = date.today()
    for c in result:
        try:
            dsc = datetime.fromisoformat(c["data_scadenza"]).date() if c.get("data_scadenza") else None
        except Exception:
            dsc = None
        if not dsc:
            c["stato"] = "sconosciuto"
            c["giorni_alla_scadenza"] = None
        else:
            delta = (dsc - today).days
            c["giorni_alla_scadenza"] = delta
            if delta < 0:
                c["stato"] = "scaduto"
            elif delta <= 30:
                c["stato"] = "in_scadenza"
            else:
                c["stato"] = "valido"
    if stato:
        result = [c for c in result if c.get("stato") == stato]
    return result


@api.post("/certificati")
async def create_certificato(payload: Certificato, _: str = Depends(require_auth)):
    doc = payload.model_dump()
    await db.certificati.insert_one(doc)
    return clean_doc(doc)


@api.put("/certificati/{cid}")
async def update_certificato(cid: str, payload: Dict[str, Any], _: str = Depends(require_auth)):
    payload.pop("id", None)
    res = await db.certificati.update_one({"id": cid}, {"$set": payload})
    if res.matched_count == 0:
        raise HTTPException(404, "Certificato non trovato")
    return clean_doc(await db.certificati.find_one({"id": cid}))


@api.delete("/certificati/{cid}")
async def delete_certificato(cid: str, _: str = Depends(require_auth)):
    await db.certificati.delete_one({"id": cid})
    return {"ok": True}


# ---- Documenti allegati socio ----
class Documento(BaseModel):
    id: str = Field(default_factory=new_id)
    socio_id: str
    nome: str
    tipo: str = "altro"  # carta_identita / privacy / iscrizione / altro
    file_name: str
    file_base64: str
    mime_type: str = "application/octet-stream"
    note: str = ""
    created_at: str = Field(default_factory=now_iso)


@api.get("/documenti")
async def list_documenti(socio_id: Optional[str] = None, _: str = Depends(require_auth)):
    q = {"socio_id": socio_id} if socio_id else {}
    docs = await db.documenti.find(q, {"file_base64": 0}).sort("created_at", -1).to_list(5000)
    return [clean_doc(d) for d in docs]


@api.get("/documenti/{did}")
async def get_documento(did: str, _: str = Depends(require_auth)):
    doc = await db.documenti.find_one({"id": did})
    if not doc:
        raise HTTPException(404, "Documento non trovato")
    return clean_doc(doc)


@api.post("/documenti")
async def create_documento(payload: Documento, _: str = Depends(require_auth)):
    doc = payload.model_dump()
    await db.documenti.insert_one(doc)
    doc.pop("file_base64", None)
    return clean_doc(doc)


@api.delete("/documenti/{did}")
async def delete_documento(did: str, _: str = Depends(require_auth)):
    await db.documenti.delete_one({"id": did})
    return {"ok": True}


# ---- Corsi ----
class Corso(BaseModel):
    id: str = Field(default_factory=new_id)
    nome: str
    disciplina: str = ""
    istruttore: str = ""
    giorno_settimana: str = ""  # Lunedi / Martedi ...
    ora_inizio: str = ""  # HH:MM
    ora_fine: str = ""
    luogo: str = ""
    descrizione: str = ""
    attivo: bool = True
    created_at: str = Field(default_factory=now_iso)


@api.get("/corsi")
async def list_corsi(_: str = Depends(require_auth)):
    docs = await db.corsi.find({}).sort("nome", 1).to_list(1000)
    return [clean_doc(d) for d in docs]


@api.post("/corsi")
async def create_corso(payload: Corso, _: str = Depends(require_auth)):
    doc = payload.model_dump()
    await db.corsi.insert_one(doc)
    return clean_doc(doc)


@api.put("/corsi/{cid}")
async def update_corso(cid: str, payload: Dict[str, Any], _: str = Depends(require_auth)):
    payload.pop("id", None)
    res = await db.corsi.update_one({"id": cid}, {"$set": payload})
    if res.matched_count == 0:
        raise HTTPException(404, "Corso non trovato")
    return clean_doc(await db.corsi.find_one({"id": cid}))


@api.delete("/corsi/{cid}")
async def delete_corso(cid: str, _: str = Depends(require_auth)):
    await db.corsi.delete_one({"id": cid})
    await db.presenze.delete_many({"corso_id": cid})
    return {"ok": True}


# ---- Presenze ----
class Presenza(BaseModel):
    id: str = Field(default_factory=new_id)
    corso_id: str
    socio_id: str
    data: str  # ISO date
    presente: bool = True
    note: str = ""
    created_at: str = Field(default_factory=now_iso)


@api.get("/presenze")
async def list_presenze(corso_id: Optional[str] = None, data: Optional[str] = None, socio_id: Optional[str] = None, _: str = Depends(require_auth)):
    q: Dict[str, Any] = {}
    if corso_id: q["corso_id"] = corso_id
    if data: q["data"] = data
    if socio_id: q["socio_id"] = socio_id
    docs = await db.presenze.find(q).to_list(20000)
    return [clean_doc(d) for d in docs]


@api.post("/presenze/bulk")
async def bulk_presenze(payload: Dict[str, Any], _: str = Depends(require_auth)):
    """payload: {corso_id, data, records: [{socio_id, presente, note}]}"""
    corso_id = payload["corso_id"]
    data_p = payload["data"]
    records = payload.get("records", [])
    # remove existing for that corso+data
    await db.presenze.delete_many({"corso_id": corso_id, "data": data_p})
    to_insert = []
    for r in records:
        p = Presenza(corso_id=corso_id, data=data_p, socio_id=r["socio_id"],
                     presente=bool(r.get("presente", True)), note=r.get("note", ""))
        to_insert.append(p.model_dump())
    if to_insert:
        await db.presenze.insert_many(to_insert)
    return {"ok": True, "count": len(to_insert)}


# ---- Comunicazioni ----
class Comunicazione(BaseModel):
    id: str = Field(default_factory=new_id)
    tipo: str = "generica"  # sollecito_certificato / sollecito_quota / assemblea / generica
    oggetto: str
    testo: str
    destinatari: List[str] = []  # socio_ids
    data: str = Field(default_factory=now_iso)
    inviata: bool = False


@api.get("/comunicazioni")
async def list_comunicazioni(_: str = Depends(require_auth)):
    docs = await db.comunicazioni.find({}).sort("data", -1).to_list(2000)
    return [clean_doc(d) for d in docs]


@api.post("/comunicazioni")
async def create_comunicazione(payload: Comunicazione, _: str = Depends(require_auth)):
    doc = payload.model_dump()
    await db.comunicazioni.insert_one(doc)
    return clean_doc(doc)


@api.delete("/comunicazioni/{cid}")
async def delete_comunicazione(cid: str, _: str = Depends(require_auth)):
    await db.comunicazioni.delete_one({"id": cid})
    return {"ok": True}


# ---- AI Assistant (Claude via emergentintegrations) ----
class AIRequest(BaseModel):
    prompt: str
    tipo: Optional[str] = "documento"  # documento / comunicazione / riepilogo / verbale / regolamento
    contesto: Optional[str] = ""
    model: Optional[str] = "claude"  # claude | gpt | gemini


AI_MODELS = {
    "claude": ("anthropic", "claude-sonnet-4-6"),
    "gpt": ("openai", "gpt-5.4"),
    "gemini": ("gemini", "gemini-3.1-pro-preview"),
}


SYSTEM_PROMPT_IT = (
    "Sei l'assistente AI di 'ASD Master', un software gestionale per Associazioni Sportive "
    "Dilettantistiche italiane. Rispondi SEMPRE in italiano, con tono professionale, chiaro, "
    "giuridicamente corretto secondo la normativa italiana ASD/APS (art. 90 L.289/2002, "
    "CONI/RASD, Codice del Terzo Settore ove applicabile). Genera testi già pronti per l'uso "
    "(lettere, verbali, comunicazioni, riepiloghi). Non inserire placeholder tipo '[nome]' se il "
    "contesto fornisce dati concreti; se mancano dati usa parentesi quadre minime. Struttura i "
    "testi con paragrafi chiari e, se serve, elenchi puntati."
)


@api.post("/ai/generate")
async def ai_generate(req: AIRequest, _: str = Depends(require_auth)):
    if not EMERGENT_LLM_KEY:
        raise HTTPException(500, "EMERGENT_LLM_KEY non configurato")
    try:
        from emergentintegrations.llm.chat import LlmChat, UserMessage
    except Exception as e:
        raise HTTPException(500, f"Libreria LLM non disponibile: {e}")

    session_id = f"ai-{uuid.uuid4()}"
    system = SYSTEM_PROMPT_IT
    if req.tipo:
        system += f"\n\nTipo richiesta: {req.tipo}."
    if req.contesto:
        system += f"\n\nContesto ASD:\n{req.contesto}"

    provider, model = AI_MODELS.get(req.model or "claude", AI_MODELS["claude"])
    chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=session_id,
        system_message=system,
    ).with_model(provider, model)

    try:
        response = await chat.send_message(UserMessage(text=req.prompt))
        text = response if isinstance(response, str) else str(response)
        await db.ai_history.insert_one({
            "id": new_id(),
            "prompt": req.prompt,
            "tipo": req.tipo,
            "contesto": req.contesto,
            "model": req.model,
            "response": text,
            "created_at": now_iso(),
        })
        return {"text": text, "model": f"{provider}/{model}"}
    except Exception as e:
        logger.exception("AI generate error")
        raise HTTPException(500, f"Errore generazione AI: {e}")


# ---- AI Image Generation (Gemini Nano Banana) ----
class AIImageRequest(BaseModel):
    prompt: str
    tipo: Optional[str] = "locandina"  # locandina / volantino / poster / logo


@api.post("/ai/image")
async def ai_image(req: AIImageRequest, _: str = Depends(require_auth)):
    if not EMERGENT_LLM_KEY:
        raise HTTPException(500, "EMERGENT_LLM_KEY non configurato")
    try:
        from emergentintegrations.llm.chat import LlmChat, UserMessage
    except Exception as e:
        raise HTTPException(500, f"Libreria LLM non disponibile: {e}")

    session_id = f"ai-img-{uuid.uuid4()}"
    system = (
        "Sei un designer grafico. Genera immagini eleganti per una ASD (Associazione Sportiva "
        "Dilettantistica) italiana. Usa colori vivaci sportivi, tipografia moderna, layout pulito."
    )
    prompt = req.prompt
    if req.tipo == "locandina":
        prompt = f"Locandina evento sportivo in italiano, formato verticale, elegante e professionale. Tema: {req.prompt}"
    elif req.tipo == "volantino":
        prompt = f"Volantino promozionale ASD in italiano, layout accattivante. Tema: {req.prompt}"
    elif req.tipo == "logo":
        prompt = f"Logo pulito e minimalista per una ASD italiana. Tema: {req.prompt}"

    chat = LlmChat(api_key=EMERGENT_LLM_KEY, session_id=session_id, system_message=system)
    chat.with_model("gemini", "gemini-3.1-flash-image-preview").with_params(modalities=["image", "text"])

    try:
        _text, images = await chat.send_message_multimodal_response(UserMessage(text=prompt))
        if not images:
            raise HTTPException(500, "Nessuna immagine generata")
        img = images[0]
        data_url = f"data:{img.get('mime_type','image/png')};base64,{img['data']}"
        await db.ai_images.insert_one({
            "id": new_id(), "prompt": prompt, "tipo": req.tipo, "created_at": now_iso(),
            "mime_type": img.get("mime_type","image/png"),
            "data_url": data_url,
        })
        return {"data_url": data_url, "mime_type": img.get("mime_type","image/png")}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("AI image error")
        raise HTTPException(500, f"Errore generazione immagine: {e}")


@api.get("/ai/images")
async def list_ai_images(_: str = Depends(require_auth)):
    docs = await db.ai_images.find({}).sort("created_at", -1).limit(30).to_list(30)
    return [clean_doc(d) for d in docs]


@api.get("/ai/history")
async def ai_history(_: str = Depends(require_auth)):
    docs = await db.ai_history.find({}).sort("created_at", -1).limit(50).to_list(50)
    return [clean_doc(d) for d in docs]


# ---- Dashboard stats ----
@api.get("/dashboard/stats")
async def dashboard_stats(_: str = Depends(require_auth)):
    today = date.today()
    year = today.year
    month_start = today.replace(day=1).isoformat()

    total_soci = await db.soci.count_documents({})
    soci_attivi = await db.soci.count_documents({"attivo": True})
    total_corsi = await db.corsi.count_documents({"attivo": True})

    # Incassi mese corrente
    pagamenti_mese = await db.pagamenti.find({"data_pagamento": {"$gte": month_start}}).to_list(10000)
    incassi_mese = sum(float(p.get("importo", 0)) for p in pagamenti_mese)

    # Incassi anno
    year_start = date(year, 1, 1).isoformat()
    pagamenti_anno = await db.pagamenti.find({"data_pagamento": {"$gte": year_start}}).to_list(50000)
    incassi_anno = sum(float(p.get("importo", 0)) for p in pagamenti_anno)

    # Certificati
    all_cert = await db.certificati.find({}).to_list(20000)
    scaduti = 0
    in_scadenza = 0
    validi = 0
    for c in all_cert:
        try:
            dsc = datetime.fromisoformat(c["data_scadenza"]).date() if c.get("data_scadenza") else None
        except Exception:
            dsc = None
        if not dsc:
            continue
        d = (dsc - today).days
        if d < 0: scaduti += 1
        elif d <= 30: in_scadenza += 1
        else: validi += 1

    # Andamento iscrizioni per mese (ultimi 12 mesi)
    andamento = []
    for i in range(11, -1, -1):
        y = today.year
        m = today.month - i
        while m <= 0:
            m += 12
            y -= 1
        start = date(y, m, 1).isoformat()
        end_month = m + 1
        end_year = y
        if end_month > 12:
            end_month = 1
            end_year += 1
        end = date(end_year, end_month, 1).isoformat()
        count = await db.soci.count_documents({"created_at": {"$gte": start, "$lt": end}})
        andamento.append({"mese": f"{y}-{m:02d}", "iscritti": count})

    # Per disciplina
    pipeline = [{"$group": {"_id": "$disciplina", "count": {"$sum": 1}}}]
    per_disc = []
    async for row in db.soci.aggregate(pipeline):
        per_disc.append({"disciplina": row["_id"] or "Non specificata", "count": row["count"]})

    return {
        "totale_soci": total_soci,
        "soci_attivi": soci_attivi,
        "corsi_attivi": total_corsi,
        "incassi_mese": round(incassi_mese, 2),
        "incassi_anno": round(incassi_anno, 2),
        "certificati_scaduti": scaduti,
        "certificati_in_scadenza": in_scadenza,
        "certificati_validi": validi,
        "andamento_iscrizioni": andamento,
        "per_disciplina": per_disc,
    }


# ---- Backup / Restore (SAFE PATH HANDLING) ----
BACKUP_COLLECTIONS = [
    "settings", "soci", "tesseramenti", "pagamenti", "certificati",
    "documenti", "corsi", "presenze", "comunicazioni", "ai_history",
]
BACKUP_FORMAT_VERSION = 2


def _is_safe_relpath(name: str) -> bool:
    """Only reject path traversal. Any file name/path is otherwise allowed."""
    if not name:
        return False
    n = name.replace("\\", "/").strip()
    if n.startswith("/"):
        return False
    parts = [p for p in n.split("/") if p]
    if any(p == ".." for p in parts):
        return False
    return True


@api.get("/backup/export")
async def backup_export(_: str = Depends(require_auth)):
    """Export all collections + config to a single ZIP file."""
    buf = io.BytesIO()
    manifest = {
        "app": "asd-master",
        "format": BACKUP_FORMAT_VERSION,
        "created_at": now_iso(),
        "collections": {},
    }
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for coll in BACKUP_COLLECTIONS:
            docs = await db[coll].find({}, {"_id": 0}).to_list(1000000)
            manifest["collections"][coll] = len(docs)
            zf.writestr(f"data/{coll}.json", json.dumps(docs, ensure_ascii=False, indent=2))
        zf.writestr("backup_manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    buf.seek(0)
    filename = f"backup_asd_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@api.post("/backup/restore")
async def backup_restore(file: UploadFile = File(...), replace: bool = Form(True), _: str = Depends(require_auth)):
    """
    Restore from a backup ZIP.
    - `replace=True` (default): each collection in the ZIP replaces the current one.
    - `replace=False`: documents are merged (upsert per `id`).
    Handles any collection files inside `data/*.json` — no hardcoded folder whitelist.
    Only rejects true path traversal (../) or absolute paths.
    """
    try:
        raw = await file.read()
        if not raw:
            raise HTTPException(400, "File di backup vuoto")
        try:
            zf = zipfile.ZipFile(io.BytesIO(raw))
        except zipfile.BadZipFile:
            raise HTTPException(400, "File non è un ZIP valido")

        bad = zf.testzip()
        if bad:
            raise HTTPException(400, f"Archivio ZIP danneggiato: {bad}")

        # Validate only against path traversal — permissive on names
        infos = zf.infolist()
        for info in infos:
            if info.is_dir():
                continue
            if not _is_safe_relpath(info.filename):
                raise HTTPException(400, f"Percorso non ammesso nel backup: {info.filename}")
            if info.file_size > 500 * 1024 * 1024:
                raise HTTPException(400, f"File troppo grande nel backup: {info.filename}")

        # Read manifest if present
        manifest = {}
        for name in ("backup_manifest.json", "manifest.json"):
            if name in zf.namelist():
                try:
                    manifest = json.loads(zf.read(name).decode("utf-8"))
                except Exception:
                    manifest = {}
                break

        # Collect json files under data/
        restored: Dict[str, int] = {}
        for info in infos:
            if info.is_dir():
                continue
            name = info.filename.replace("\\", "/")
            # Support: data/<coll>.json  OR  <coll>.json in root when coll matches known
            coll = None
            if name.startswith("data/") and name.endswith(".json"):
                coll = name[len("data/"):-len(".json")]
            elif "/" not in name and name.endswith(".json"):
                candidate = name[:-len(".json")]
                if candidate in BACKUP_COLLECTIONS:
                    coll = candidate
            if not coll:
                continue
            if coll not in BACKUP_COLLECTIONS:
                # skip unknown collections silently rather than erroring
                continue
            try:
                data = json.loads(zf.read(info).decode("utf-8"))
            except Exception as e:
                raise HTTPException(400, f"JSON non valido in {name}: {e}")
            if not isinstance(data, list):
                raise HTTPException(400, f"Formato non valido in {name}: attesa lista")
            if replace:
                await db[coll].delete_many({})
            if data:
                if replace:
                    # bulk insert
                    for d in data:
                        d.pop("_id", None)
                    await db[coll].insert_many(data)
                else:
                    for d in data:
                        d.pop("_id", None)
                        if d.get("id"):
                            await db[coll].update_one({"id": d["id"]}, {"$set": d}, upsert=True)
                        else:
                            await db[coll].insert_one(d)
            restored[coll] = len(data)

        return {"ok": True, "manifest": manifest, "restored": restored}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Restore error")
        raise HTTPException(500, f"Errore restore: {e}")


# ---- Seed demo data (optional) ----
@api.post("/dev/seed")
async def dev_seed(_: str = Depends(require_auth)):
    # Only seed if soci is empty
    count = await db.soci.count_documents({})
    if count > 0:
        return {"ok": False, "message": "Dati già presenti"}

    # Settings
    await db.settings.update_one(
        {"id": SETTINGS_ID},
        {"$set": Settings(
            ragione_sociale="ASD Polisportiva Roma Centro",
            codice_fiscale="12345678901",
            partita_iva="12345678901",
            n_registro_coni="RC-2024-001",
            presidente="Mario Rossi",
            indirizzo="Via dello Sport 10",
            citta="Roma", cap="00100", provincia="RM",
            telefono="06 1234567", email="info@asdroma.it",
            iban="IT60X0542811101000000123456",
        ).model_dump()},
        upsert=True,
    )

    disciplines = ["Calcio", "Basket", "Pallavolo", "Ginnastica", "Tennis"]
    names = [
        ("Marco", "Bianchi", "M"), ("Giulia", "Verdi", "F"), ("Luca", "Neri", "M"),
        ("Sara", "Rossi", "F"), ("Alessandro", "Ferrari", "M"), ("Chiara", "Romano", "F"),
        ("Davide", "Ricci", "M"), ("Elena", "Marino", "F"), ("Francesco", "Greco", "M"),
        ("Martina", "Bruno", "F"),
    ]
    soci_ids = []
    for i, (nome, cognome, sex) in enumerate(names):
        s = Socio(
            nome=nome, cognome=cognome, sesso=sex,
            codice_fiscale=f"{cognome[:3].upper()}{nome[:3].upper()}90A01H501X",
            data_nascita=f"199{i%10}-0{(i%9)+1}-15",
            luogo_nascita="Roma", indirizzo=f"Via Roma {i+1}", citta="Roma", cap="00100", provincia="RM",
            telefono=f"333 111{1000+i}", email=f"{nome.lower()}.{cognome.lower()}@example.it",
            disciplina=disciplines[i % len(disciplines)],
            ruolo="Atleta" if i > 0 else "Istruttore",
        )
        d = s.model_dump()
        await db.soci.insert_one(d)
        soci_ids.append(d["id"])

    # Tesseramenti
    for sid in soci_ids:
        t = Tesseramento(
            socio_id=sid, stagione="2024/2025", ente="CSEN",
            numero_tessera=f"CSEN-{sid[:6].upper()}",
            data_emissione="2024-09-01", data_scadenza="2025-08-31",
        )
        await db.tesseramenti.insert_one(t.model_dump())

    # Pagamenti
    today = date.today()
    for i, sid in enumerate(soci_ids):
        p = Pagamento(
            socio_id=sid, numero_ricevuta=f"{today.year}-{i+1:04d}",
            causale="Quota associativa 2024/2025", importo=150.0 + (i * 10),
            metodo="Bonifico" if i % 2 else "Contanti",
            data_pagamento=(today - timedelta(days=i*3)).isoformat(),
            stagione="2024/2025",
        )
        await db.pagamenti.insert_one(p.model_dump())

    # Certificati (mix valid/scaduti/in scadenza)
    for i, sid in enumerate(soci_ids):
        if i % 3 == 0:
            scad = (today + timedelta(days=15)).isoformat()  # in scadenza
        elif i % 3 == 1:
            scad = (today - timedelta(days=20)).isoformat()  # scaduto
        else:
            scad = (today + timedelta(days=200)).isoformat()  # valido
        c = Certificato(
            socio_id=sid,
            tipo="agonistico" if i % 2 else "non_agonistico",
            data_rilascio=(today - timedelta(days=180)).isoformat(),
            data_scadenza=scad,
            medico=f"Dr. {['Rossi','Bianchi','Verdi'][i%3]}",
            struttura="Centro Medico Sportivo Roma",
        )
        await db.certificati.insert_one(c.model_dump())

    # Corsi
    corsi_seed = [
        ("Calcio Under 15", "Calcio", "Mario Bianchi", "Lunedi", "17:00", "18:30", "Campo Sportivo A"),
        ("Basket Junior", "Basket", "Luca Neri", "Martedi", "18:00", "19:30", "Palestra Comunale"),
        ("Pallavolo Femminile", "Pallavolo", "Sara Rossi", "Mercoledi", "19:00", "20:30", "Palestra Comunale"),
        ("Ginnastica Ritmica", "Ginnastica", "Elena Marino", "Giovedi", "16:30", "18:00", "Palestra A"),
    ]
    for nome, disc, istr, gg, oi, of, luogo in corsi_seed:
        co = Corso(nome=nome, disciplina=disc, istruttore=istr,
                   giorno_settimana=gg, ora_inizio=oi, ora_fine=of, luogo=luogo)
        await db.corsi.insert_one(co.model_dump())

    return {"ok": True, "soci": len(soci_ids)}


# ---- Ricevuta PDF ----
@api.get("/pagamenti/{pid}/pdf")
async def pagamento_pdf(pid: str, _: str = Depends(require_auth)):
    p = await db.pagamenti.find_one({"id": pid})
    if not p:
        raise HTTPException(404, "Pagamento non trovato")
    p = clean_doc(p)
    socio = clean_doc(await db.soci.find_one({"id": p["socio_id"]})) or {}
    settings = clean_doc(await db.settings.find_one({"id": SETTINGS_ID})) or {}

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=18*mm, rightMargin=18*mm, topMargin=18*mm, bottomMargin=18*mm)
    styles = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=styles["Heading1"], fontSize=18, textColor=colors.HexColor("#0F172A"), spaceAfter=6)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], fontSize=11, textColor=colors.HexColor("#64748B"), spaceAfter=4)
    small = ParagraphStyle("small", parent=styles["Normal"], fontSize=9, textColor=colors.HexColor("#64748B"))
    body = ParagraphStyle("body", parent=styles["Normal"], fontSize=10.5, textColor=colors.HexColor("#0F172A"), spaceAfter=6)
    ric = ParagraphStyle("ric", parent=styles["Heading1"], fontSize=26, textColor=colors.HexColor("#0284C7"), alignment=2)

    story = []
    # Header: logo + dati ASD | numero ricevuta
    header_data = []
    left_text = f"<b>{settings.get('ragione_sociale','')}</b><br/>"\
                f"{settings.get('indirizzo','')}, {settings.get('cap','')} {settings.get('citta','')} ({settings.get('provincia','')})<br/>"\
                f"CF: {settings.get('codice_fiscale','')} — P.IVA: {settings.get('partita_iva','')}"
    right_text = f"<font size=8 color='#94A3B8'>RICEVUTA N.</font><br/>"\
                 f"<font size=22 color='#0284C7'><b>{p.get('numero_ricevuta','')}</b></font><br/>"\
                 f"<font size=9 color='#64748B'>{fmt_it_date(p.get('data_pagamento',''))}</font>"
    # Try to embed logo
    logo_flow = None
    logo_b64 = settings.get("logo_base64", "")
    if logo_b64 and "," in logo_b64:
        try:
            raw = base64.b64decode(logo_b64.split(",", 1)[1])
            logo_flow = RLImage(io.BytesIO(raw), width=28*mm, height=28*mm, kind='proportional')
        except Exception:
            logo_flow = None

    left_cells = [logo_flow, Paragraph(left_text, small)] if logo_flow else [Paragraph(left_text, small)]
    header = Table(
        [[Table([[c] for c in left_cells], colWidths=[80*mm]), Paragraph(right_text, ric)]],
        colWidths=[120*mm, 55*mm],
    )
    header.setStyle(TableStyle([("VALIGN", (0,0), (-1,-1), "TOP")]))
    story += [header, Spacer(1, 10*mm)]
    story += [Table([[""]], colWidths=[175*mm], style=TableStyle([("LINEBELOW", (0,0),(-1,-1), 0.8, colors.HexColor("#E2E8F0"))]))]
    story += [Spacer(1, 6*mm)]

    story += [Paragraph("RICEVUTO DA", h2),
              Paragraph(f"<b>{socio.get('cognome','')} {socio.get('nome','')}</b>", body),
              Paragraph(f"CF: {socio.get('codice_fiscale','—')}<br/>{socio.get('indirizzo','')} {socio.get('cap','')} {socio.get('citta','')} ({socio.get('provincia','')})", small),
              Spacer(1, 5*mm)]

    story += [Paragraph("CAUSALE", h2),
              Paragraph(p.get("causale",""), body),
              Spacer(1, 4*mm)]

    detail = Table(
        [["METODO", "STAGIONE", "IMPORTO"],
         [p.get("metodo",""), p.get("stagione","—"), fmt_it_euro(p.get("importo",0))]],
        colWidths=[58*mm, 58*mm, 58*mm],
    )
    detail.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#F1F5F9")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.HexColor("#64748B")),
        ("FONTSIZE", (0,0), (-1,0), 8),
        ("FONTSIZE", (0,1), (-1,1), 12),
        ("FONTNAME", (0,1), (-1,1), "Helvetica-Bold"),
        ("TEXTCOLOR", (2,1), (2,1), colors.HexColor("#059669")),
        ("BOX", (0,0), (-1,-1), 0.5, colors.HexColor("#E2E8F0")),
        ("INNERGRID", (0,0), (-1,-1), 0.3, colors.HexColor("#E2E8F0")),
        ("PADDING", (0,0), (-1,-1), 8),
    ]))
    story += [detail, Spacer(1, 10*mm)]

    story += [Paragraph(
        f"Documento non fiscale ai sensi della normativa applicabile alle Associazioni Sportive Dilettantistiche. "
        f"Emesso da {settings.get('ragione_sociale','')} — {settings.get('citta','')}, {fmt_it_date(p.get('data_pagamento',''))}.",
        small,
    )]
    story += [Spacer(1, 15*mm)]
    story += [Table([[Paragraph("Il Presidente<br/><br/>_________________________", small),
                      Paragraph(f"Firmato digitalmente<br/><font size=8 color='#94A3B8'>ID doc: {p['id'][:8]}</font>", small)]],
                    colWidths=[85*mm, 85*mm])]

    doc.build(story)
    buf.seek(0)
    filename = f"ricevuta_{p.get('numero_ricevuta','')}.pdf"
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": f'attachment; filename="{filename}"'})


def fmt_it_euro(n) -> str:
    try:
        return f"€ {float(n):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except Exception:
        return f"€ {n}"


def fmt_it_date(iso: str) -> str:
    if not iso: return "—"
    try:
        d = datetime.fromisoformat(iso).date() if "T" not in iso else datetime.fromisoformat(iso.replace("Z","+00:00")).date()
        return d.strftime("%d/%m/%Y")
    except Exception:
        return iso


# ---- CSV Import Soci ----
CSV_COLUMNS = ["nome","cognome","codice_fiscale","data_nascita","luogo_nascita","sesso",
               "indirizzo","citta","cap","provincia","telefono","email","disciplina","ruolo","note"]


@api.get("/soci/csv/template")
async def soci_csv_template(_: str = Depends(require_auth)):
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(CSV_COLUMNS)
    w.writerow(["Mario","Rossi","RSSMRA80A01H501U","1980-01-01","Roma","M",
                "Via Roma 1","Roma","00100","RM","3331234567","m.rossi@example.it",
                "Calcio","Atleta","Note opzionali"])
    data = buf.getvalue().encode("utf-8-sig")
    return StreamingResponse(io.BytesIO(data), media_type="text/csv",
                             headers={"Content-Disposition": 'attachment; filename="soci_template.csv"'})


@api.post("/soci/csv/import")
async def soci_csv_import(file: UploadFile = File(...), _: str = Depends(require_auth)):
    raw = (await file.read()).decode("utf-8-sig", errors="replace")
    # sniff delimiter
    try:
        dialect = csv.Sniffer().sniff(raw[:2048], delimiters=";,|\t")
        delim = dialect.delimiter
    except Exception:
        delim = ";"
    reader = csv.DictReader(io.StringIO(raw), delimiter=delim)
    if not reader.fieldnames:
        raise HTTPException(400, "CSV vuoto o non leggibile")
    fields = [f.strip().lower() for f in reader.fieldnames]
    missing = [c for c in ("nome","cognome") if c not in fields]
    if missing:
        raise HTTPException(400, f"Colonne obbligatorie mancanti: {', '.join(missing)}")

    created, skipped, errors = 0, 0, []
    for idx, row in enumerate(reader, start=2):  # header is row 1
        try:
            row_l = { (k or "").strip().lower(): (v or "").strip() for k, v in row.items() }
            if not row_l.get("nome") or not row_l.get("cognome"):
                skipped += 1
                continue
            payload = {c: row_l.get(c, "") for c in CSV_COLUMNS}
            # duplicate check by codice_fiscale (if provided) or email
            dup_q = None
            if payload["codice_fiscale"]:
                dup_q = {"codice_fiscale": payload["codice_fiscale"]}
            elif payload["email"]:
                dup_q = {"email": payload["email"]}
            if dup_q and await db.soci.find_one(dup_q):
                skipped += 1
                continue
            s = Socio(**payload)
            await db.soci.insert_one(s.model_dump())
            created += 1
        except Exception as e:
            errors.append(f"Riga {idx}: {e}")
    return {"created": created, "skipped": skipped, "errors": errors[:20]}


# ---- Email invio ----
class EmailSend(BaseModel):
    destinatari_socio_ids: Optional[List[str]] = None  # se presente, prende email dai soci
    destinatari_emails: Optional[List[str]] = None
    oggetto: str
    testo: str
    comunicazione_id: Optional[str] = None  # se collegato


def _send_via_smtp(cfg: Dict[str, Any], to_email: str, subject: str, body_text: str) -> None:
    host = cfg.get("smtp_host")
    port = int(cfg.get("smtp_port") or 587)
    user = cfg.get("smtp_user")
    pw = cfg.get("smtp_password")
    use_tls = bool(cfg.get("smtp_use_tls", True))
    from_email = cfg.get("smtp_from_email") or user
    from_name = cfg.get("smtp_from_name") or cfg.get("ragione_sociale") or "ASD Master"
    if not host or not from_email:
        raise RuntimeError("SMTP non configurato (host / mittente mancante)")

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = formataddr((from_name, from_email))
    msg["To"] = to_email
    msg.attach(MIMEText(body_text, "plain", "utf-8"))
    html_body = "<div style='font-family:Arial,sans-serif;font-size:14px;color:#0F172A;line-height:1.55;white-space:pre-wrap'>" + \
                body_text.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;") + "</div>"
    msg.attach(MIMEText(html_body, "html", "utf-8"))

    if port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=20) as s:
            if user: s.login(user, pw or "")
            s.sendmail(from_email, [to_email], msg.as_string())
    else:
        with smtplib.SMTP(host, port, timeout=20) as s:
            s.ehlo()
            if use_tls:
                s.starttls(); s.ehlo()
            if user: s.login(user, pw or "")
            s.sendmail(from_email, [to_email], msg.as_string())


def _send_via_resend(to_email: str, subject: str, body_text: str) -> Optional[str]:
    if not RESEND_API_KEY:
        return None
    import resend
    resend.api_key = RESEND_API_KEY
    html = "<div style='font-family:Arial,sans-serif;font-size:14px;color:#0F172A;line-height:1.55;white-space:pre-wrap'>" + \
           body_text.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;") + "</div>"
    res = resend.Emails.send({"from": RESEND_SENDER, "to": [to_email], "subject": subject, "html": html})
    return res.get("id") if isinstance(res, dict) else None


@api.post("/email/send")
async def email_send(req: EmailSend, _: str = Depends(require_auth)):
    settings = clean_doc(await db.settings.find_one({"id": SETTINGS_ID})) or {}
    # resolve recipients
    to = list(req.destinatari_emails or [])
    if req.destinatari_socio_ids:
        soci = await db.soci.find({"id": {"$in": req.destinatari_socio_ids}}).to_list(1000)
        to += [s.get("email") for s in soci if s.get("email")]
    to = [e for e in dict.fromkeys(to) if e]  # dedup + filter empty
    if not to:
        raise HTTPException(400, "Nessun destinatario con email valida")

    provider = "resend" if RESEND_API_KEY else "smtp"
    if provider == "smtp" and not settings.get("smtp_host"):
        raise HTTPException(400, "Provider email non configurato: imposta SMTP in Impostazioni o aggiungi RESEND_API_KEY")

    delivered, failed = [], []
    for email in to:
        try:
            if provider == "resend":
                mid = await asyncio.to_thread(_send_via_resend, email, req.oggetto, req.testo)
                delivered.append({"email": email, "id": mid, "provider": "resend"})
            else:
                await asyncio.to_thread(_send_via_smtp, settings, email, req.oggetto, req.testo)
                delivered.append({"email": email, "provider": "smtp"})
        except Exception as e:
            logger.exception("send fail")
            failed.append({"email": email, "error": str(e)})

    log_doc = {
        "id": new_id(),
        "oggetto": req.oggetto,
        "testo": req.testo,
        "delivered": delivered,
        "failed": failed,
        "provider": provider,
        "comunicazione_id": req.comunicazione_id,
        "created_at": now_iso(),
    }
    await db.email_log.insert_one(log_doc)

    if req.comunicazione_id and delivered and not failed:
        await db.comunicazioni.update_one({"id": req.comunicazione_id}, {"$set": {"inviata": True}})

    return {"delivered": len(delivered), "failed": len(failed), "details": {"delivered": delivered, "failed": failed}}


@api.get("/email/log")
async def email_log(_: str = Depends(require_auth)):
    docs = await db.email_log.find({}).sort("created_at", -1).limit(200).to_list(200)
    return [clean_doc(d) for d in docs]


@api.get("/email/status")
async def email_status(_: str = Depends(require_auth)):
    settings = clean_doc(await db.settings.find_one({"id": SETTINGS_ID})) or {}
    return {
        "resend_configured": bool(RESEND_API_KEY),
        "smtp_configured": bool(settings.get("smtp_host") and settings.get("smtp_from_email")),
        "active_provider": "resend" if RESEND_API_KEY else ("smtp" if settings.get("smtp_host") else "none"),
    }


# ---- Modelli Documenti (23+ template DOCX prontl per la ASD) ----
STATIC_DIR = ROOT_DIR / "static"
MODELLI_DIR = STATIC_DIR / "modelli_asd"

MODELLI_META = {
    "iscrizione_manleva": ("Domanda di iscrizione + manleva", "iscrizione"),
    "privacy_consensi": ("Informativa privacy + consensi GDPR", "privacy"),
    "liberatoria_immagini_adulto": ("Liberatoria immagini (adulto)", "privacy"),
    "liberatoria_immagini_minore": ("Liberatoria immagini (minore)", "privacy"),
    "delega_ritiro_minore": ("Delega ritiro minore", "minori"),
    "uscita_autonoma_minore": ("Autorizzazione uscita autonoma", "minori"),
    "tutela_minori": ("Tutela minori — informativa", "minori"),
    "presa_visione_safeguarding": ("Presa visione policy safeguarding", "minori"),
    "certificato_medico": ("Modulo richiesta certificato medico", "medici"),
    "scheda_emergenza_contatti": ("Scheda emergenza + contatti", "medici"),
    "dichiarazione_pagamento": ("Dichiarazione di pagamento", "fiscale"),
    "detrazione_730": ("Attestato per detrazione 730", "fiscale"),
    "dote_sport": ("Attestato Dote Sport", "fiscale"),
    "sponsorizzazione": ("Contratto di sponsorizzazione", "contratti"),
    "accordo_spazi": ("Accordo utilizzo spazi (generico)", "contratti"),
    "accordo_utilizzo_spazi_csen": ("Accordo utilizzo spazi tra ASD CSEN — €1000/mese", "contratti"),
    "collaboratore_volontario": ("Accordo collaboratore volontario", "contratti"),
    "rimborso_spese_volontario": ("Rimborso spese volontario", "contratti"),
    "verbale_consegna_documenti": ("Verbale consegna documenti", "verbali"),
}
# Modelli non necessari / superflui: nascosti dalla lista
MODELLI_HIDDEN = {
    "crediti_scolastici", "dati_f24", "idoneita_struttura", "manleva_spazi",
    "modello_ricevuta_bodymind", "modello_iscrizione_csen_80308",
}


def _list_modelli_files() -> List[Dict[str, str]]:
    if not MODELLI_DIR.exists():
        return []
    out = []
    for f in sorted(MODELLI_DIR.iterdir()):
        if f.suffix.lower() not in (".docx", ".pdf"):
            continue
        key = f.stem
        if key in MODELLI_HIDDEN:
            continue
        title, cat = MODELLI_META.get(key, (key.replace("_", " ").title(), "altro"))
        out.append({
            "id": key, "file_name": f.name, "title": title,
            "category": cat, "format": f.suffix.lower().lstrip("."),
            "size_kb": round(f.stat().st_size / 1024, 1),
        })
    return out


@api.get("/modelli")
async def list_modelli(_: str = Depends(require_auth)):
    return _list_modelli_files()


@api.get("/modelli/{key}/download")
async def download_modello(key: str, _: str = Depends(require_auth)):
    """Scarica il modello vuoto originale."""
    for ext in (".docx", ".pdf"):
        f = MODELLI_DIR / f"{key}{ext}"
        if f.exists():
            media = "application/vnd.openxmlformats-officedocument.wordprocessingml.document" if ext == ".docx" else "application/pdf"
            return StreamingResponse(io.BytesIO(f.read_bytes()), media_type=media,
                                     headers={"Content-Disposition": f'attachment; filename="{f.name}"'})
    raise HTTPException(404, "Modello non trovato")


def _build_placeholders(socio: Dict[str, Any], settings: Dict[str, Any], extra: Dict[str, Any]) -> Dict[str, str]:
    s = socio or {}
    a = settings or {}
    ex = extra or {}
    m = {
        "[NOME E COGNOME]": f"{s.get('nome','')} {s.get('cognome','')}".strip(),
        "[CODICE FISCALE]": s.get("codice_fiscale", ""),
        "[DATA NASCITA]": fmt_it_date(s.get("data_nascita", "")),
        "[LUOGO NASCITA]": s.get("luogo_nascita", ""),
        "[DISCIPLINA PRATICATA]": s.get("disciplina", ""),
        "[TELEFONO TESSERATO]": s.get("telefono", ""),
        "[EMAIL GENITORE]": s.get("email", ""),
        "[TELEFONO GENITORE]": s.get("contatto_emergenza_telefono", ""),
        "[MINORE TESSERATO]": f"{s.get('nome','')} {s.get('cognome','')}".strip(),
        "[GENITORE PAGANTE]": s.get("contatto_emergenza_nome", ""),
        "[DENOMINAZIONE ASD]": a.get("ragione_sociale", ""),
        "[SEDE LEGALE ASD]": f"{a.get('indirizzo','')}, {a.get('cap','')} {a.get('citta','')} ({a.get('provincia','')})",
        "[CF ASD]": a.get("codice_fiscale", ""),
        "[PIVA ASD]": a.get("partita_iva", ""),
        "[IBAN ASD]": a.get("iban", ""),
        "[CONTATTI ASD]": f"{a.get('telefono','')} — {a.get('email','')}",
        "[PRESIDENTE]": a.get("presidente", ""),
        "[LOGO ASD]": a.get("ragione_sociale", ""),
        "[STAGIONE SPORTIVA]": ex.get("stagione", "2024/2025"),
        "[LUOGO E DATA]": f"{a.get('citta','')}, {fmt_it_date(datetime.now(timezone.utc).date().isoformat())}",
        "[DATA CONSEGNA]": fmt_it_date(datetime.now(timezone.utc).date().isoformat()),
        "[DATA PAGAMENTO]": fmt_it_date(ex.get("data_pagamento", datetime.now(timezone.utc).date().isoformat())),
        "[IMPORTO PAGATO]": ex.get("importo", ""),
        "[QUOTA ASSOCIATIVA]": ex.get("quota_associativa", ""),
        "[QUOTA CORSO]": ex.get("quota_corso", ""),
        "[QUOTA ASSICURAZIONE]": ex.get("quota_assicurazione", ""),
        "[CAUSALE PAGAMENTO]": ex.get("causale", "Quota associativa"),
        "[NUMERO QUIETANZA]": ex.get("numero_ricevuta", ""),
        "[TOTALE VERSATO]": ex.get("totale", ""),
        "[TIPO CERTIFICATO]": ex.get("tipo_certificato", "Non agonistico"),
        "[MEDICO CERTIFICATORE]": ex.get("medico", ""),
        "[Data scadenza certificato]": fmt_it_date(ex.get("scadenza_certificato", "")),
        "[NOTE SANITARIE]": ex.get("note_sanitarie", ""),
        "[NOTE LEGALI]": ex.get("note_legali", ""),
        "[REFERENTE PRIVACY]": a.get("presidente", ""),
        "[REFERENTE SAFEGUARDING]": ex.get("referente_safeguarding", a.get("presidente", "")),
        "[CANALE SAFEGUARDING]": ex.get("canale_safeguarding", a.get("email", "")),
        "[FORO COMPETENTE]": ex.get("foro", a.get("citta", "")),
        "[SPONSOR]": ex.get("sponsor", ""),
        "[PARTI CONTRAENTI]": f"{a.get('ragione_sociale','')} e {ex.get('sponsor','')}",
        "[DENOMINAZIONE ASD OSPITANTE]": ex.get("asd_ospitante", "[ASD Ospitante — da compilare]"),
        "[SEDE ASD OSPITANTE]": ex.get("sede_ospitante", "[Sede da compilare]"),
        "[CF ASD OSPITANTE]": ex.get("cf_ospitante", ""),
        "[PRESIDENTE ASD OSPITANTE]": ex.get("presidente_ospitante", ""),
        "[IBAN ASD OSPITANTE]": ex.get("iban_ospitante", ""),
        "[ORARIO FISSO]": ex.get("orario_fisso", "18:00 – 20:00"),
        "[CORRISPETTIVO]": ex.get("corrispettivo", ""),
        "[DURATA CONTRATTO]": ex.get("durata", ""),
        "[PERIODO ATTIVITA]": ex.get("periodo", ex.get("stagione","")),
        "[PERIODO RIFERIMENTO]": ex.get("periodo", ex.get("stagione","")),
        "[GIORNI ORARI]": ex.get("orari", ""),
        "[TIPOLOGIA ATTIVITA]": s.get("disciplina", ""),
        "[DELEGATI RITIRO]": ex.get("delegati", ""),
        "[DOCUMENTI DELEGATI]": ex.get("documenti_delegati", ""),
        "[ELENCO DOCUMENTI CONSEGNATI]": ex.get("elenco_documenti", ""),
        "[DESTINATARI DATI]": ex.get("destinatari", "Enti sportivi affilianti, assicurazione, adempimenti fiscali."),
        "[CODICE TRIBUTO]": ex.get("codice_tributo", ""),
        "[RIFERIMENTO OPERAZIONE]": ex.get("rif_operazione", ""),
        "[RIFERIMENTO NORMATIVO]": ex.get("rif_normativo", "Art. 90 L. 289/2002 e s.m.i."),
        "[VALUTAZIONE]": ex.get("valutazione", ""),
        "[KPI REPORT]": ex.get("kpi", ""),
        "[IMPORTO RIMBORSO]": ex.get("importo_rimborso", ""),
        "[IMPORTO A CREDITO]": ex.get("importo_credito", ""),
        "[ALTRI IMPORTI]": ex.get("altri_importi", ""),
        "[RATEAZIONE]": ex.get("rateazione", ""),
        "[COSTI UTILIZZO]": ex.get("costi", ""),
    }
    return m


def _replace_in_docx(src_path: Path, mapping: Dict[str, str], header_ctx: Optional[Dict[str, Any]] = None) -> bytes:
    """Sostituisce i placeholder in un DOCX preservando la formattazione,
    e inietta intestazione ASD (logo + denominazione + CF/PIVA) in cima."""
    import docx
    from docx.shared import Cm, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    doc = docx.Document(str(src_path))

    def replace_in_paragraph(p):
        full = "".join(r.text or "" for r in p.runs)
        if not full: return
        new = full
        for k, v in mapping.items():
            if k in new: new = new.replace(k, str(v) if v is not None else "")
        if new != full:
            if p.runs:
                p.runs[0].text = new
                for r in p.runs[1:]: r.text = ""

    for p in doc.paragraphs: replace_in_paragraph(p)
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs: replace_in_paragraph(p)

    # Iniezione intestazione ASD (in testa alla PRIMA sezione, in cima al documento)
    if header_ctx:
        try:
            body = doc.paragraphs[0]._parent
            # Nuova sezione: paragrafi + tabella logo/dati (aggiunti in cima)
            asd_name = header_ctx.get("ragione_sociale") or "ASD"
            asd_addr = f"{header_ctx.get('indirizzo','')}, {header_ctx.get('cap','')} {header_ctx.get('citta','')} ({header_ctx.get('provincia','')})".strip(", ()")
            asd_fisc = f"C.F. {header_ctx.get('codice_fiscale','—')} • P.IVA {header_ctx.get('partita_iva','—')}"
            asd_reg = f"Reg. CONI: {header_ctx.get('n_registro_coni','—')}"
            logo_b64 = header_ctx.get("logo_base64") or ""

            # Inserisco all'inizio: table 2 colonne (logo | dati)
            first_par = doc.paragraphs[0]
            tbl = doc.add_table(rows=1, cols=2)
            tbl.autofit = True
            row = tbl.rows[0]
            c_logo = row.cells[0]; c_dati = row.cells[1]

            if logo_b64 and "," in logo_b64:
                try:
                    import base64 as _b64
                    raw = _b64.b64decode(logo_b64.split(",",1)[1])
                    from io import BytesIO
                    c_logo.paragraphs[0].add_run().add_picture(BytesIO(raw), width=Cm(2.5))
                except Exception:
                    c_logo.text = asd_name[:3].upper()

            p1 = c_dati.paragraphs[0]
            r1 = p1.add_run(asd_name); r1.bold = True; r1.font.size = Pt(12)
            p2 = c_dati.add_paragraph(asd_addr); p2.runs[0].font.size = Pt(9)
            p3 = c_dati.add_paragraph(asd_fisc); p3.runs[0].font.size = Pt(8); p3.runs[0].font.color.rgb = RGBColor(0x64,0x74,0x8B)
            p4 = c_dati.add_paragraph(asd_reg); p4.runs[0].font.size = Pt(8); p4.runs[0].font.color.rgb = RGBColor(0x64,0x74,0x8B)

            # Sposta la table in cima
            body_elm = doc.element.body
            body_elm.insert(0, tbl._element)
            # Separatore
            p_sep = doc.add_paragraph()
            p_sep_elm = p_sep._element
            body_elm.insert(1, p_sep_elm)
        except Exception:
            logger.exception("header injection failed (non-critical)")

    buf = io.BytesIO(); doc.save(buf); buf.seek(0)
    return buf.getvalue()


class CompileModello(BaseModel):
    socio_id: Optional[str] = None
    extra: Optional[Dict[str, Any]] = None


@api.post("/modelli/{key}/compile")
async def compile_modello(key: str, req: CompileModello, _: str = Depends(require_auth)):
    """Genera un DOCX compilato con dati socio + impostazioni + extra."""
    src = MODELLI_DIR / f"{key}.docx"
    if not src.exists():
        raise HTTPException(404, "Modello DOCX non trovato (solo i .docx sono compilabili)")
    socio = {}
    if req.socio_id:
        socio = clean_doc(await db.soci.find_one({"id": req.socio_id})) or {}
    settings = clean_doc(await db.settings.find_one({"id": SETTINGS_ID})) or {}
    mapping = _build_placeholders(socio, settings, req.extra or {})
    try:
        data = _replace_in_docx(src, mapping, header_ctx=settings)
    except Exception as e:
        raise HTTPException(500, f"Errore compilazione: {e}")
    name = key
    if socio.get("cognome"):
        name = f"{key}_{socio['cognome']}_{socio.get('nome','')}".replace(" ", "_")
    return StreamingResponse(
        io.BytesIO(data),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f'attachment; filename="{name}.docx"'},
    )


# ---- Default logo ----
@api.get("/logo/default")
async def default_logo(_: str = Depends(require_auth)):
    p = STATIC_DIR / "logo" / "app_icon.png"
    if not p.exists():
        raise HTTPException(404, "Logo non trovato")
    return StreamingResponse(io.BytesIO(p.read_bytes()), media_type="image/png",
                             headers={"Cache-Control": "public, max-age=86400"})


# ---- Mac Launcher bundle download ----
async def mac_launcher(_: str = Depends(require_auth)):
    """Genera uno ZIP con lo script AVVIA_ASD_MASTER.command per avviare il gestionale in locale su Mac."""
    buf = io.BytesIO()
    launcher = r"""#!/bin/bash
# ==============================================================
#  ASD MASTER - Launcher per macOS
#  Doppio click su questo file per avviare il gestionale.
# ==============================================================
set -e
cd "$(dirname "$0")"

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$APP_DIR/backend"
FRONTEND_DIR="$APP_DIR/frontend"
DATA_DIR="$APP_DIR/data"
LOGS_DIR="$APP_DIR/logs"
mkdir -p "$DATA_DIR" "$LOGS_DIR"

echo "🏆  ASD Master - Avvio in corso..."

# --- Homebrew check ---
if ! command -v brew >/dev/null 2>&1; then
  echo "⚠️  Homebrew non trovato. Installa da https://brew.sh e riprova."
  read -p "Premi INVIO per chiudere..." x; exit 1
fi

# --- MongoDB via brew ---
if ! command -v mongod >/dev/null 2>&1; then
  echo "→ Installo MongoDB Community..."
  brew tap mongodb/brew
  brew install mongodb-community@7.0 || true
fi

# --- Python venv ---
if [ ! -d "$BACKEND_DIR/.venv" ]; then
  echo "→ Creo venv Python..."
  python3 -m venv "$BACKEND_DIR/.venv"
fi
source "$BACKEND_DIR/.venv/bin/activate"
pip install --quiet --upgrade pip
pip install --quiet -r "$BACKEND_DIR/requirements.txt"

# --- Node deps ---
if ! command -v node >/dev/null 2>&1; then
  echo "→ Installo Node.js..."
  brew install node
fi
if ! command -v yarn >/dev/null 2>&1; then
  npm install -g yarn
fi
if [ ! -d "$FRONTEND_DIR/node_modules" ]; then
  echo "→ Installo dipendenze frontend..."
  (cd "$FRONTEND_DIR" && yarn install --silent)
fi

# --- Start MongoDB (local) ---
if ! pgrep -x "mongod" >/dev/null; then
  echo "→ Avvio MongoDB locale..."
  mongod --dbpath "$DATA_DIR" --logpath "$LOGS_DIR/mongo.log" --fork --port 27017 >/dev/null
fi

# --- Env ---
export MONGO_URL="mongodb://localhost:27017"
export DB_NAME="asd_master_local"
export CORS_ORIGINS="*"
export JWT_SECRET="local-secret-change-me"
export ADMIN_USERNAME="admin"
export ADMIN_PASSWORD="admin123"

# --- Backend ---
echo "→ Avvio backend FastAPI su 8001..."
(cd "$BACKEND_DIR" && "$BACKEND_DIR/.venv/bin/uvicorn" server:app --host 127.0.0.1 --port 8001 >"$LOGS_DIR/backend.log" 2>&1 &)
BACK_PID=$!

# --- Frontend ---
echo "→ Avvio frontend React su 3000..."
export REACT_APP_BACKEND_URL="http://127.0.0.1:8001"
(cd "$FRONTEND_DIR" && BROWSER=none yarn start >"$LOGS_DIR/frontend.log" 2>&1 &)
FRONT_PID=$!

sleep 6
open "http://127.0.0.1:3000"

echo ""
echo "✅ ASD Master avviato."
echo "   Backend PID: $BACK_PID   Frontend PID: $FRONT_PID"
echo "   Chiudi questa finestra per fermare l'app."
echo "   Log: $LOGS_DIR"
echo ""

trap "echo 'Fermo servizi...'; kill $BACK_PID $FRONT_PID 2>/dev/null; pkill -f mongod 2>/dev/null; exit 0" INT TERM
wait
"""

    readme = """# ASD Master — Launcher Mac

## Come usare
1. Scarica questo ZIP e scompattalo in una cartella (es. `~/Applicazioni/ASDMaster`).
2. **Copia dentro** le cartelle `backend/` e `frontend/` complete del progetto.
3. Doppio click su `AVVIA_ASD_MASTER.command`.
   - Al primo avvio autorizza in *Impostazioni → Privacy → Apri comunque*.
4. Il gestionale si aprirà automaticamente nel browser su `http://127.0.0.1:3000`.
5. Login: `admin` / `admin123` (modifica in `backend/.env`).

## Cosa fa lo script
- Verifica Homebrew, Node, Python, MongoDB e li installa se mancanti.
- Avvia MongoDB locale in `./data/`.
- Avvia il backend FastAPI su porta 8001 e il frontend React su porta 3000.
- Apre il browser sul gestionale.
- Al termine (chiusura terminale), spegne tutti i processi.

## Struttura consigliata
```
ASDMaster/
├── AVVIA_ASD_MASTER.command
├── LEGGIMI.md
├── backend/    (copiare da /app/backend)
├── frontend/   (copiare da /app/frontend)
├── data/       (creato in automatico)
└── logs/       (creato in automatico)
```
"""

    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        info = zipfile.ZipInfo("AVVIA_ASD_MASTER.command")
        info.external_attr = (0o755 << 16)
        zf.writestr(info, launcher)
        zf.writestr("LEGGIMI.md", readme)

    buf.seek(0)
    return StreamingResponse(buf, media_type="application/zip",
                             headers={"Content-Disposition": 'attachment; filename="ASD_Master_Mac_Launcher.zip"'})


# ---- Iscrizioni Online (Stripe Checkout con Klarna + Carte) ----
class CheckoutRequest(BaseModel):
    importo: float
    causale: str
    socio_id: Optional[str] = None
    email: Optional[str] = None
    stagione: Optional[str] = "2024/2025"
    origin_url: str


@api.post("/checkout/create")
async def create_checkout(req: CheckoutRequest, _: str = Depends(require_auth)):
    if not STRIPE_SECRET_KEY:
        raise HTTPException(500, "Stripe non configurato")
    if req.importo <= 0:
        raise HTTPException(400, "Importo non valido")

    socio = None
    email = req.email
    if req.socio_id:
        socio = clean_doc(await db.soci.find_one({"id": req.socio_id})) or None
        if socio and not email:
            email = socio.get("email")

    metadata = {
        "causale": req.causale,
        "stagione": req.stagione or "",
        "socio_id": req.socio_id or "",
        "socio_name": f"{(socio or {}).get('cognome','')} {(socio or {}).get('nome','')}".strip(),
    }

    try:
        session = stripe_sdk.checkout.Session.create(
            mode="payment",
            payment_method_types=["card", "klarna"],
            line_items=[{
                "price_data": {
                    "currency": "eur",
                    "product_data": {"name": req.causale[:120] or "Quota associativa"},
                    "unit_amount": int(round(req.importo * 100)),
                },
                "quantity": 1,
            }],
            customer_email=email or None,
            success_url=f"{req.origin_url.rstrip('/')}/pagamento/successo?session_id={{CHECKOUT_SESSION_ID}}",
            cancel_url=f"{req.origin_url.rstrip('/')}/pagamento/annullato",
            metadata=metadata,
            locale="it",
        )
    except Exception as e:
        logger.exception("stripe create session")
        raise HTTPException(500, f"Errore Stripe: {e}")

    tx = {
        "id": new_id(),
        "session_id": session.id,
        "socio_id": req.socio_id,
        "email": email,
        "causale": req.causale,
        "importo": float(req.importo),
        "stagione": req.stagione,
        "status": "initiated",
        "payment_status": "pending",
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "url": session.url,
    }
    await db.payment_transactions.insert_one(tx)
    return {"checkout_url": session.url, "session_id": session.id, "tx_id": tx["id"]}


async def _finalize_paid_tx(session_id: str, session_obj) -> None:
    tx = await db.payment_transactions.find_one({"session_id": session_id})
    if not tx or tx.get("payment_status") == "paid":
        return
    pi = None
    try:
        pi = session_obj.get("payment_intent") if isinstance(session_obj, dict) else getattr(session_obj, "payment_intent", None)
    except Exception:
        pi = None
    await db.payment_transactions.update_one(
        {"session_id": session_id, "payment_status": {"$ne": "paid"}},
        {"$set": {
            "status": "completed",
            "payment_status": "paid",
            "stripe_payment_intent_id": pi,
            "updated_at": now_iso(),
        }},
    )
    if tx.get("socio_id"):
        exists = await db.pagamenti.find_one({"stripe_session_id": session_id})
        if not exists:
            p = Pagamento(
                socio_id=tx["socio_id"],
                numero_ricevuta=await _next_ricevuta_number(),
                causale=tx.get("causale", "Quota associativa"),
                importo=float(tx.get("importo", 0)),
                metodo="Stripe (online)",
                data_pagamento=datetime.now(timezone.utc).date().isoformat(),
                stagione=tx.get("stagione", ""),
            )
            doc = p.model_dump()
            doc["stripe_session_id"] = session_id
            await db.pagamenti.insert_one(doc)
            # Invio automatico email di conferma con importo + causale
            try:
                asd = clean_doc(await db.settings.find_one({"id": SETTINGS_ID})) or {}
                dest_email = tx.get("email")
                if not dest_email and tx.get("socio_id"):
                    s = await db.soci.find_one({"id": tx["socio_id"]})
                    dest_email = (s or {}).get("email")
                if dest_email:
                    subj = f"Conferma pagamento — Ricevuta {doc['numero_ricevuta']}"
                    body = (
                        f"Gentile socio,\n\n"
                        f"abbiamo ricevuto il Suo pagamento di € {doc['importo']:.2f} "
                        f"per «{doc['causale']}».\n"
                        f"La ricevuta numero {doc['numero_ricevuta']} è stata registrata "
                        f"in data {doc['data_pagamento']}.\n\n"
                        f"Grazie,\n{asd.get('ragione_sociale','La Segreteria ASD')}"
                    )
                    if RESEND_API_KEY:
                        await asyncio.to_thread(_send_via_resend, dest_email, subj, body)
                    elif asd.get("smtp_host"):
                        await asyncio.to_thread(_send_via_smtp, asd, dest_email, subj, body)
                    await db.email_log.insert_one({
                        "id": new_id(), "oggetto": subj, "testo": body,
                        "delivered": [{"email": dest_email, "provider": "auto"}],
                        "failed": [], "provider": "auto-payment",
                        "created_at": now_iso(),
                    })
            except Exception:
                logger.exception("auto-email ricevuta fallita (non blocca)")


@api.get("/checkout/status/{session_id}")
async def checkout_status(session_id: str):
    tx = await db.payment_transactions.find_one({"session_id": session_id})
    if not tx:
        raise HTTPException(404, "Transazione non trovata")
    if tx.get("payment_status") != "paid":
        try:
            s = stripe_sdk.checkout.Session.retrieve(session_id)
            if s.payment_status == "paid" or s.status == "complete":
                await _finalize_paid_tx(session_id, s)
                tx = await db.payment_transactions.find_one({"session_id": session_id})
        except Exception:
            pass
    return {
        "session_id": session_id,
        "status": tx.get("status"),
        "payment_status": tx.get("payment_status"),
        "importo": tx.get("importo"),
        "causale": tx.get("causale"),
    }


@api.get("/checkout/list")
async def checkout_list(_: str = Depends(require_auth)):
    docs = await db.payment_transactions.find({}).sort("created_at", -1).limit(200).to_list(200)
    return [clean_doc(d) for d in docs]


@api.post("/stripe/webhook")
async def stripe_webhook(request: FastAPIRequest):
    payload = await request.body()
    sig = request.headers.get("stripe-signature", "")
    if not STRIPE_WEBHOOK_SECRET:
        raise HTTPException(500, "Webhook secret non configurato")
    try:
        event = stripe_sdk.Webhook.construct_event(payload, sig, STRIPE_WEBHOOK_SECRET)
    except stripe_sdk.error.SignatureVerificationError:
        raise HTTPException(400, "Firma webhook non valida")
    obj = event["data"]["object"]
    t = event["type"]
    if t == "checkout.session.completed":
        await _finalize_paid_tx(obj["id"], obj)
    elif t == "checkout.session.async_payment_succeeded":
        try:
            s = stripe_sdk.checkout.Session.retrieve(obj["id"])
            await _finalize_paid_tx(obj["id"], s)
        except Exception:
            pass
    elif t == "checkout.session.async_payment_failed":
        await db.payment_transactions.update_one({"session_id": obj["id"]},
            {"$set": {"status": "failed", "payment_status": "failed", "updated_at": now_iso()}})
    elif t == "checkout.session.expired":
        await db.payment_transactions.update_one({"session_id": obj["id"]},
            {"$set": {"status": "expired", "payment_status": "expired", "updated_at": now_iso()}})
    return {"ok": True}


# ---- Fatture Elettroniche (con XML FatturaPA SdI) ----
class RigaFattura(BaseModel):
    descrizione: str
    quantita: float = 1.0
    prezzo_unitario: float
    aliquota_iva: float = 0.0


class Fattura(BaseModel):
    id: str = Field(default_factory=new_id)
    numero: str = ""
    anno: int = Field(default_factory=lambda: datetime.now(timezone.utc).year)
    data_emissione: str
    socio_id: Optional[str] = None
    cliente_denominazione: str = ""
    cliente_cf: str = ""
    cliente_piva: str = ""
    cliente_indirizzo: str = ""
    cliente_cap: str = ""
    cliente_citta: str = ""
    cliente_provincia: str = ""
    cliente_paese: str = "IT"
    cliente_codice_sdi: str = "0000000"
    cliente_pec: str = ""
    righe: List[RigaFattura] = []
    tipo_documento: str = "TD01"
    causale: str = ""
    modalita_pagamento: str = "MP05"
    stato: str = "bozza"
    note: str = ""
    imponibile: float = 0.0
    iva: float = 0.0
    totale: float = 0.0
    created_at: str = Field(default_factory=now_iso)


async def _next_fattura_numero(anno: int) -> str:
    count = await db.fatture.count_documents({"anno": anno})
    return f"{anno}/{count + 1:04d}"


def _calc_totali(righe):
    imp = 0.0; iva = 0.0
    for r in righe:
        subt = float(r.get("quantita", 1)) * float(r.get("prezzo_unitario", 0))
        alq = float(r.get("aliquota_iva", 0))
        imp += subt
        iva += subt * alq / 100.0
    return round(imp, 2), round(iva, 2), round(imp + iva, 2)


@api.get("/fatture")
async def list_fatture(_: Dict = Depends(require_auth)):
    docs = await db.fatture.find({}).sort("data_emissione", -1).to_list(5000)
    return [clean_doc(d) for d in docs]


@api.post("/fatture")
async def create_fattura(payload: Fattura, _: Dict = Depends(require_auth)):
    doc = payload.model_dump()
    if not doc.get("numero"):
        doc["numero"] = await _next_fattura_numero(doc.get("anno") or datetime.now(timezone.utc).year)
    if doc.get("socio_id"):
        s = clean_doc(await db.soci.find_one({"id": doc["socio_id"]})) or {}
        if s:
            doc["cliente_denominazione"] = doc["cliente_denominazione"] or f"{s.get('cognome','')} {s.get('nome','')}".strip()
            doc["cliente_cf"] = doc["cliente_cf"] or s.get("codice_fiscale","")
            doc["cliente_indirizzo"] = doc["cliente_indirizzo"] or s.get("indirizzo","")
            doc["cliente_cap"] = doc["cliente_cap"] or s.get("cap","")
            doc["cliente_citta"] = doc["cliente_citta"] or s.get("citta","")
            doc["cliente_provincia"] = doc["cliente_provincia"] or s.get("provincia","")
    imp, iva, tot = _calc_totali(doc.get("righe", []))
    doc["imponibile"], doc["iva"], doc["totale"] = imp, iva, tot
    await db.fatture.insert_one(doc)
    return clean_doc(doc)


@api.put("/fatture/{fid}")
async def update_fattura(fid: str, payload: Dict[str, Any], _: Dict = Depends(require_auth)):
    payload.pop("id", None)
    if "righe" in payload:
        imp, iva, tot = _calc_totali(payload["righe"])
        payload["imponibile"], payload["iva"], payload["totale"] = imp, iva, tot
    r = await db.fatture.update_one({"id": fid}, {"$set": payload})
    if r.matched_count == 0: raise HTTPException(404, "Fattura non trovata")
    return clean_doc(await db.fatture.find_one({"id": fid}))


@api.delete("/fatture/{fid}")
async def delete_fattura(fid: str, _: Dict = Depends(require_auth)):
    await db.fatture.delete_one({"id": fid})
    return {"ok": True}


def _xml_fatturapa(f, asd):
    ns_p = "http://ivaservizi.agenziaentrate.gov.it/docs/xsd/fatture/v1.2"
    ET.register_namespace("p", ns_p)
    root = ET.Element(f"{{{ns_p}}}FatturaElettronica", {"versione": "FPR12"})
    hdr = ET.SubElement(root, "FatturaElettronicaHeader")
    dt = ET.SubElement(hdr, "DatiTrasmissione")
    idtx = ET.SubElement(dt, "IdTrasmittente")
    ET.SubElement(idtx, "IdPaese").text = "IT"
    ET.SubElement(idtx, "IdCodice").text = (asd.get("codice_fiscale") or "00000000000").replace(" ", "")
    ET.SubElement(dt, "ProgressivoInvio").text = (f["numero"] or "0").replace("/","-")[:10]
    ET.SubElement(dt, "FormatoTrasmissione").text = "FPR12"
    ET.SubElement(dt, "CodiceDestinatario").text = (f.get("cliente_codice_sdi") or "0000000")[:7]
    if f.get("cliente_pec"): ET.SubElement(dt, "PECDestinatario").text = f["cliente_pec"]

    ced = ET.SubElement(hdr, "CedentePrestatore")
    da = ET.SubElement(ced, "DatiAnagrafici")
    if asd.get("partita_iva"):
        pi = ET.SubElement(da, "IdFiscaleIVA")
        ET.SubElement(pi, "IdPaese").text = "IT"
        ET.SubElement(pi, "IdCodice").text = asd["partita_iva"]
    if asd.get("codice_fiscale"): ET.SubElement(da, "CodiceFiscale").text = asd["codice_fiscale"]
    an = ET.SubElement(da, "Anagrafica"); ET.SubElement(an, "Denominazione").text = asd.get("ragione_sociale","ASD")
    ET.SubElement(da, "RegimeFiscale").text = "RF19"
    sede = ET.SubElement(ced, "Sede")
    ET.SubElement(sede, "Indirizzo").text = asd.get("indirizzo","-")
    ET.SubElement(sede, "CAP").text = asd.get("cap","00000")
    ET.SubElement(sede, "Comune").text = asd.get("citta","-")
    if asd.get("provincia"): ET.SubElement(sede, "Provincia").text = asd["provincia"]
    ET.SubElement(sede, "Nazione").text = "IT"

    cess = ET.SubElement(hdr, "CessionarioCommittente")
    da2 = ET.SubElement(cess, "DatiAnagrafici")
    if f.get("cliente_piva"):
        pi2 = ET.SubElement(da2, "IdFiscaleIVA")
        ET.SubElement(pi2, "IdPaese").text = f.get("cliente_paese","IT")
        ET.SubElement(pi2, "IdCodice").text = f["cliente_piva"]
    if f.get("cliente_cf"): ET.SubElement(da2, "CodiceFiscale").text = f["cliente_cf"]
    an2 = ET.SubElement(da2, "Anagrafica"); ET.SubElement(an2, "Denominazione").text = f.get("cliente_denominazione","Cliente")
    sede2 = ET.SubElement(cess, "Sede")
    ET.SubElement(sede2, "Indirizzo").text = f.get("cliente_indirizzo","-")
    ET.SubElement(sede2, "CAP").text = f.get("cliente_cap","00000")
    ET.SubElement(sede2, "Comune").text = f.get("cliente_citta","-")
    if f.get("cliente_provincia"): ET.SubElement(sede2, "Provincia").text = f["cliente_provincia"]
    ET.SubElement(sede2, "Nazione").text = f.get("cliente_paese","IT")

    body = ET.SubElement(root, "FatturaElettronicaBody")
    dg = ET.SubElement(body, "DatiGenerali")
    dgd = ET.SubElement(dg, "DatiGeneraliDocumento")
    ET.SubElement(dgd, "TipoDocumento").text = f.get("tipo_documento","TD01")
    ET.SubElement(dgd, "Divisa").text = "EUR"
    ET.SubElement(dgd, "Data").text = f["data_emissione"][:10]
    ET.SubElement(dgd, "Numero").text = f["numero"]
    ET.SubElement(dgd, "ImportoTotaleDocumento").text = f"{f.get('totale',0):.2f}"
    if f.get("causale"): ET.SubElement(dgd, "Causale").text = f["causale"][:200]

    dbb = ET.SubElement(body, "DatiBeniServizi")
    for idx, r in enumerate(f.get("righe", []), start=1):
        dl = ET.SubElement(dbb, "DettaglioLinee")
        ET.SubElement(dl, "NumeroLinea").text = str(idx)
        ET.SubElement(dl, "Descrizione").text = (r.get("descrizione","-") or "-")[:1000]
        ET.SubElement(dl, "Quantita").text = f"{float(r.get('quantita',1)):.2f}"
        ET.SubElement(dl, "PrezzoUnitario").text = f"{float(r.get('prezzo_unitario',0)):.2f}"
        subt = float(r.get("quantita",1)) * float(r.get("prezzo_unitario",0))
        ET.SubElement(dl, "PrezzoTotale").text = f"{subt:.2f}"
        ET.SubElement(dl, "AliquotaIVA").text = f"{float(r.get('aliquota_iva',0)):.2f}"
    aliquote = {}
    for r in f.get("righe", []):
        alq = float(r.get("aliquota_iva",0))
        subt = float(r.get("quantita",1)) * float(r.get("prezzo_unitario",0))
        d = aliquote.setdefault(alq, {"imponibile":0.0,"imposta":0.0})
        d["imponibile"] += subt; d["imposta"] += subt * alq / 100.0
    for alq, tot in aliquote.items():
        dr = ET.SubElement(dbb, "DatiRiepilogo")
        ET.SubElement(dr, "AliquotaIVA").text = f"{alq:.2f}"
        if alq == 0: ET.SubElement(dr, "Natura").text = "N2.2"
        ET.SubElement(dr, "ImponibileImporto").text = f"{tot['imponibile']:.2f}"
        ET.SubElement(dr, "Imposta").text = f"{tot['imposta']:.2f}"
        ET.SubElement(dr, "EsigibilitaIVA").text = "I"

    dp = ET.SubElement(body, "DatiPagamento")
    ET.SubElement(dp, "CondizioniPagamento").text = "TP02"
    ddp = ET.SubElement(dp, "DettaglioPagamento")
    ET.SubElement(ddp, "ModalitaPagamento").text = f.get("modalita_pagamento","MP05")
    ET.SubElement(ddp, "ImportoPagamento").text = f"{f.get('totale',0):.2f}"
    if asd.get("iban"): ET.SubElement(ddp, "IBAN").text = asd["iban"].replace(" ","")

    xml_str = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    return minidom.parseString(xml_str).toprettyxml(indent="  ", encoding="utf-8")


@api.get("/fatture/{fid}/xml")
async def fattura_xml(fid: str, _: Dict = Depends(require_auth)):
    f = clean_doc(await db.fatture.find_one({"id": fid}))
    if not f: raise HTTPException(404, "Fattura non trovata")
    asd = clean_doc(await db.settings.find_one({"id": SETTINGS_ID})) or {}
    xml = _xml_fatturapa(f, asd)
    cf = (asd.get("codice_fiscale") or asd.get("partita_iva") or "00000000000").replace(" ", "")
    prog = (f["numero"] or "0").replace("/","-")[:5]
    filename = f"IT{cf}_{prog}.xml"
    return StreamingResponse(io.BytesIO(xml), media_type="application/xml",
                             headers={"Content-Disposition": f'attachment; filename="{filename}"'})


# ---- Vista Giornata ----
GIORNI_IT = ["Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato","Domenica"]


@api.get("/oggi")
async def oggi(_: Dict = Depends(require_auth)):
    today = date.today()
    iso = today.isoformat()
    giorno = GIORNI_IT[today.weekday()]
    corsi = await db.corsi.find({"attivo": True, "giorno_settimana": giorno}).to_list(200)
    presenze_oggi = await db.presenze.count_documents({"data": iso})
    pagamenti_oggi = await db.pagamenti.find({"data_pagamento": iso}).to_list(200)
    incassi_oggi = sum(float(p.get("importo",0)) for p in pagamenti_oggi)
    iscr_pending = await db.payment_transactions.count_documents({"payment_status": "pending"})
    all_cert = await db.certificati.find({}).to_list(20000)
    soci_map = {s["id"]: s for s in await db.soci.find({}, {"cognome":1,"nome":1,"id":1,"_id":0}).to_list(5000)}
    cert_scaduti = 0
    cert_in_scadenza = []
    for c in all_cert:
        try:
            dsc = datetime.fromisoformat(c["data_scadenza"]).date() if c.get("data_scadenza") else None
        except Exception: dsc = None
        if not dsc: continue
        d = (dsc - today).days
        if d < 0: cert_scaduti += 1
        elif d <= 7:
            s = soci_map.get(c.get("socio_id"), {})
            cert_in_scadenza.append({"socio": f"{s.get('cognome','')} {s.get('nome','')}".strip(),
                                     "socio_id": c.get("socio_id"), "data_scadenza": c.get("data_scadenza"), "giorni": d})
    cert_in_scadenza.sort(key=lambda x: x["giorni"])
    return {
        "data": iso, "giorno_settimana": giorno,
        "corsi_oggi": [clean_doc(c) for c in corsi],
        "presenze_oggi_count": presenze_oggi,
        "pagamenti_oggi": [clean_doc(p) for p in pagamenti_oggi],
        "incassi_oggi": round(incassi_oggi, 2),
        "iscrizioni_pending": iscr_pending,
        "certificati_scaduti": cert_scaduti,
        "certificati_in_scadenza_7gg": cert_in_scadenza,
    }



# ---- Reminder Certificati Medici ----
REMINDER_MILESTONES = [30, 15, 7]


async def _send_reminder_email(dest_email: str, socio_name: str, milestone: int, data_scad: str, asd: Dict[str, Any]) -> bool:
    if not dest_email: return False
    subj = f"Certificato medico in scadenza tra {milestone} giorni"
    body = (
        f"Gentile {socio_name},\n\n"
        f"il Suo certificato medico sportivo risulta in scadenza il {data_scad} "
        f"(tra {milestone} giorni). La invitiamo a provvedere per tempo al rinnovo "
        f"per continuare la Sua attività sportiva.\n\n"
        f"Cordiali saluti,\n{asd.get('ragione_sociale','La Segreteria')}"
    )
    try:
        if RESEND_API_KEY:
            await asyncio.to_thread(_send_via_resend, dest_email, subj, body)
        elif asd.get("smtp_host"):
            await asyncio.to_thread(_send_via_smtp, asd, dest_email, subj, body)
        else:
            return False
        return True
    except Exception:
        logger.exception("reminder send failed")
        return False


async def _run_reminder_scan() -> Dict[str, Any]:
    today = date.today()
    asd = clean_doc(await db.settings.find_one({"id": SETTINGS_ID})) or {}
    all_cert = await db.certificati.find({}).to_list(20000)
    soci_map = {}
    async for s in db.soci.find({}):
        soci_map[s["id"]] = clean_doc(s)
    sent, skipped, no_email = 0, 0, 0
    for c in all_cert:
        c = clean_doc(c)
        try:
            dsc = datetime.fromisoformat(c["data_scadenza"]).date() if c.get("data_scadenza") else None
        except Exception: dsc = None
        if not dsc: continue
        delta = (dsc - today).days
        if delta not in REMINDER_MILESTONES: continue
        key = f"{c['id']}::{delta}::{c['data_scadenza']}"
        if await db.reminders_sent.find_one({"key": key}):
            skipped += 1; continue
        socio = soci_map.get(c.get("socio_id"), {})
        email = socio.get("email")
        if not email:
            no_email += 1; continue
        name = f"{socio.get('nome','')} {socio.get('cognome','')}".strip() or "Socio"
        ok = await _send_reminder_email(email, name, delta, fmt_it_date(c["data_scadenza"]), asd)
        await db.reminders_sent.insert_one({
            "id": new_id(), "key": key, "socio_id": c.get("socio_id"), "email": email,
            "milestone": delta, "data_scadenza": c["data_scadenza"], "sent": ok,
            "created_at": now_iso(),
        })
        if ok: sent += 1
    return {"sent": sent, "skipped": skipped, "no_email": no_email, "checked": len(all_cert)}


@api.post("/reminders/run")
async def reminders_run(_: Dict = Depends(require_auth)):
    return await _run_reminder_scan()


@api.get("/reminders/log")
async def reminders_log(_: Dict = Depends(require_auth)):
    docs = await db.reminders_sent.find({}).sort("created_at", -1).limit(200).to_list(200)
    return [clean_doc(d) for d in docs]


@api.get("/reminders/preview")
async def reminders_preview(_: Dict = Depends(require_auth)):
    today = date.today()
    all_cert = await db.certificati.find({}).to_list(20000)
    soci_map = {}
    async for s in db.soci.find({}):
        soci_map[s["id"]] = clean_doc(s)
    preview = []
    for c in all_cert:
        c = clean_doc(c)
        try:
            dsc = datetime.fromisoformat(c["data_scadenza"]).date() if c.get("data_scadenza") else None
        except Exception: dsc = None
        if not dsc: continue
        delta = (dsc - today).days
        if delta not in REMINDER_MILESTONES: continue
        key = f"{c['id']}::{delta}::{c['data_scadenza']}"
        already = bool(await db.reminders_sent.find_one({"key": key}))
        socio = soci_map.get(c.get("socio_id"), {})
        preview.append({
            "socio": f"{socio.get('cognome','')} {socio.get('nome','')}".strip(),
            "email": socio.get("email", ""),
            "milestone": delta, "data_scadenza": c["data_scadenza"], "already_sent": already,
        })
    return sorted(preview, key=lambda x: x["milestone"])


# ---- Report Annuale ----
@api.get("/report/annuale")
async def report_annuale(anno: Optional[int] = None, _: Dict = Depends(require_auth)):
    y = anno or datetime.now(timezone.utc).year
    start = f"{y}-01-01"; end = f"{y+1}-01-01"

    soci_totali = await db.soci.count_documents({})
    soci_iscritti_anno = await db.soci.count_documents({"created_at": {"$gte": start, "$lt": end}})
    soci_attivi = await db.soci.count_documents({"attivo": True})

    per_disc = []
    async for row in db.soci.aggregate([{"$group": {"_id": "$disciplina", "count": {"$sum": 1}}}]):
        per_disc.append({"disciplina": row["_id"] or "Non specificata", "count": row["count"]})
    per_disc.sort(key=lambda x: -x["count"])

    pag = await db.pagamenti.find({"data_pagamento": {"$gte": start, "$lt": end}}).to_list(20000)
    incassi_totali = sum(float(p.get("importo", 0)) for p in pag)
    per_metodo, per_mese, top_causali_d = {}, {}, {}
    for p in pag:
        per_metodo[p.get("metodo","—")] = per_metodo.get(p.get("metodo","—"), 0) + float(p.get("importo",0))
        m = (p.get("data_pagamento") or "")[:7]
        per_mese[m] = per_mese.get(m, 0) + float(p.get("importo",0))
        c = (p.get("causale","—") or "—")[:60]
        top_causali_d[c] = top_causali_d.get(c, 0) + float(p.get("importo",0))
    top_causali = sorted(top_causali_d.items(), key=lambda x: -x[1])[:8]

    fatture = await db.fatture.find({"anno": y}).to_list(5000)
    fatt_totale = sum(float(f.get("totale", 0)) for f in fatture)
    fatt_imponibile = sum(float(f.get("imponibile", 0)) for f in fatture)
    fatt_iva = sum(float(f.get("iva", 0)) for f in fatture)

    corsi = await db.corsi.find({}).to_list(500)
    corsi_attivi = [c for c in corsi if c.get("attivo", True)]
    ore_erogate = 0.0
    for c in corsi_attivi:
        try:
            hi, hf = c.get("ora_inizio","0:0"), c.get("ora_fine","0:0")
            h1, m1 = map(int, hi.split(":"))
            h2, m2 = map(int, hf.split(":"))
            ore_erogate += max(0, (h2*60+m2) - (h1*60+m1)) / 60 * 52
        except Exception: pass

    presenze = await db.presenze.count_documents({"data": {"$gte": start, "$lt": end}, "presente": True})
    all_cert = await db.certificati.find({}).to_list(20000)
    today = date.today()
    cert_stat = {"validi": 0, "in_scadenza": 0, "scaduti": 0}
    for c in all_cert:
        try:
            dsc = datetime.fromisoformat(c["data_scadenza"]).date() if c.get("data_scadenza") else None
        except Exception: dsc = None
        if not dsc: continue
        d = (dsc - today).days
        if d < 0: cert_stat["scaduti"] += 1
        elif d <= 30: cert_stat["in_scadenza"] += 1
        else: cert_stat["validi"] += 1

    return {
        "anno": y,
        "soci": {"totale": soci_totali, "attivi": soci_attivi, "iscritti_anno": soci_iscritti_anno, "per_disciplina": per_disc},
        "incassi": {"totale": round(incassi_totali,2), "per_metodo": per_metodo, "per_mese": per_mese, "top_causali": top_causali},
        "fatture": {"count": len(fatture), "totale": round(fatt_totale,2), "imponibile": round(fatt_imponibile,2), "iva": round(fatt_iva,2)},
        "corsi": {"totali": len(corsi), "attivi": len(corsi_attivi), "ore_erogate_stimate": round(ore_erogate,1), "presenze_registrate": presenze},
        "certificati": cert_stat,
    }


@api.get("/report/annuale/pdf")
async def report_annuale_pdf(anno: Optional[int] = None, _: Dict = Depends(require_auth)):
    y = anno or datetime.now(timezone.utc).year
    r = await report_annuale(anno=y)
    asd = clean_doc(await db.settings.find_one({"id": SETTINGS_ID})) or {}

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=18*mm, rightMargin=18*mm, topMargin=18*mm, bottomMargin=18*mm)
    styles = getSampleStyleSheet()
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], fontSize=13, textColor=colors.HexColor("#0284C7"), spaceAfter=6, spaceBefore=10)
    small = ParagraphStyle("small", parent=styles["Normal"], fontSize=9, textColor=colors.HexColor("#64748B"))

    story = []
    left_text = f"<b>{asd.get('ragione_sociale','ASD')}</b><br/>{asd.get('indirizzo','')} {asd.get('cap','')} {asd.get('citta','')}<br/>C.F. {asd.get('codice_fiscale','—')} • P.IVA {asd.get('partita_iva','—')}"
    right_text = f"<font size=8 color='#94A3B8'>REPORT ANNUALE</font><br/><font size=24 color='#0284C7'><b>{y}</b></font>"
    logo_flow = None
    if asd.get("logo_base64") and "," in asd["logo_base64"]:
        try:
            raw = base64.b64decode(asd["logo_base64"].split(",",1)[1])
            logo_flow = RLImage(io.BytesIO(raw), width=22*mm, height=22*mm, kind='proportional')
        except Exception: pass
    header_left = [logo_flow, Paragraph(left_text, small)] if logo_flow else [Paragraph(left_text, small)]
    hdr = Table([[Table([[c] for c in header_left], colWidths=[80*mm]), Paragraph(right_text, styles["Heading1"])]], colWidths=[120*mm, 55*mm])
    hdr.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP")]))
    story += [hdr, Spacer(1, 4*mm), Paragraph(f"Sintesi dell'attività associativa e sportiva svolta nell'anno {y}, redatta per l'Assemblea dei Soci.", small)]

    def kv_table(cols, data, palette="slate"):
        colmap = {"slate": ("#F1F5F9","#E2E8F0"), "emerald": ("#ECFDF5","#D1FAE5"),
                  "indigo": ("#EEF2FF","#C7D2FE"), "amber": ("#FFF7ED","#FED7AA")}
        bg, br = colmap.get(palette, colmap["slate"])
        t = Table([cols, data], colWidths=[175/len(cols)*mm]*len(cols))
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0), colors.HexColor(bg)),
            ("FONTSIZE",(0,0),(-1,0), 9), ("FONTSIZE",(0,1),(-1,1), 12),
            ("FONTNAME",(0,1),(-1,1), "Helvetica-Bold"),
            ("BOX",(0,0),(-1,-1), 0.5, colors.HexColor(br)),
            ("INNERGRID",(0,0),(-1,-1), 0.3, colors.HexColor(br)),
            ("PADDING",(0,0),(-1,-1), 7),
        ]))
        return t

    story += [Paragraph("Soci e Tesserati", h2),
              kv_table(["Totali","Attivi",f"Iscritti nel {y}"],
                       [str(r["soci"]["totale"]), str(r["soci"]["attivi"]), str(r["soci"]["iscritti_anno"])])]
    disc_rows = [["Disciplina","Iscritti"]] + [[d["disciplina"], str(d["count"])] for d in r["soci"]["per_disciplina"]]
    tdisc = Table(disc_rows, colWidths=[130*mm, 45*mm])
    tdisc.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0), colors.HexColor("#EEF2FF")),
        ("FONTSIZE",(0,0),(-1,-1), 9),
        ("INNERGRID",(0,0),(-1,-1), 0.2, colors.HexColor("#E2E8F0")),
        ("BOX",(0,0),(-1,-1), 0.4, colors.HexColor("#E2E8F0"))]))
    story += [Spacer(1, 3*mm), tdisc]

    story += [Paragraph("Incassi e Pagamenti", h2),
              kv_table(["Incassato","Metodo prevalente","Mese migliore"],
                       [fmt_it_euro(r["incassi"]["totale"]),
                        (sorted(r["incassi"]["per_metodo"].items(), key=lambda x:-x[1])[0][0] if r["incassi"]["per_metodo"] else "—"),
                        (sorted(r["incassi"]["per_mese"].items(), key=lambda x:-x[1])[0][0] if r["incassi"]["per_mese"] else "—")],
                       "emerald")]
    if r["incassi"]["top_causali"]:
        story += [Spacer(1, 2*mm), Paragraph("<b>Top causali</b>", small)]
        for c, v in r["incassi"]["top_causali"]:
            story += [Paragraph(f"• {c}: <b>{fmt_it_euro(v)}</b>", small)]

    story += [Paragraph("Fatturazione elettronica", h2),
              kv_table(["Emesse","Imponibile","IVA","Totale"],
                       [str(r["fatture"]["count"]), fmt_it_euro(r["fatture"]["imponibile"]),
                        fmt_it_euro(r["fatture"]["iva"]), fmt_it_euro(r["fatture"]["totale"])])]

    story += [Paragraph("Attività sportiva", h2),
              kv_table(["Corsi","Attivi","Ore erogate","Presenze"],
                       [str(r["corsi"]["totali"]), str(r["corsi"]["attivi"]),
                        f"{r['corsi']['ore_erogate_stimate']} h", str(r["corsi"]["presenze_registrate"])],
                       "indigo")]

    story += [Paragraph("Certificati medici", h2),
              kv_table(["Validi","In scadenza (30gg)","Scaduti"],
                       [str(r["certificati"]["validi"]), str(r["certificati"]["in_scadenza"]),
                        str(r["certificati"]["scaduti"])], "amber")]

    story += [Spacer(1, 10*mm),
              Paragraph(f"<i>Report generato automaticamente da ASD Master in data {datetime.now(timezone.utc).strftime('%d/%m/%Y')}. Documento a uso interno per l'Assemblea dei Soci.</i>", small)]
    doc.build(story); buf.seek(0)
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": f'attachment; filename="report_annuale_{y}.pdf"'})


# ---- Scheduler reminder giornaliero (in background) ----
_REMINDER_TASK = None


async def _reminder_loop():
    while True:
        try:
            await asyncio.sleep(60 * 60)  # 1h
            if datetime.now(timezone.utc).hour == 8:
                logger.info("Reminder scan started")
                res = await _run_reminder_scan()
                logger.info(f"Reminder scan done: {res}")
        except asyncio.CancelledError:
            break
        except Exception:
            logger.exception("reminder loop error")
            await asyncio.sleep(60)


@app.on_event("startup")
async def _startup_scheduler():
    global _REMINDER_TASK
    _REMINDER_TASK = asyncio.create_task(_reminder_loop())



@api.get("/")
async def health():
    return {"status": "ok", "app": "ASD Master", "time": now_iso()}


# Register routers & middleware
app.include_router(api)
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("shutdown")
async def _shutdown():
    client.close()
