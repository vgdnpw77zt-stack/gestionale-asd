import React, { useEffect, useState } from "react";
import { Download } from "lucide-react";

export default function InstallPwaButton() {
  const [deferred, setDeferred] = useState(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handler = (e) => {
      e.preventDefault();
      setDeferred(e);
      setVisible(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    // Register SW
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/service-worker.js").catch(()=>{});
    }
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  if (!visible) return null;

  const install = async () => {
    if (!deferred) return;
    deferred.prompt();
    await deferred.userChoice;
    setDeferred(null); setVisible(false);
  };

  return (
    <button data-testid="pwa-install-btn" onClick={install}
      className="fixed bottom-6 right-6 z-40 inline-flex items-center gap-2 h-11 px-4 rounded-full bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold shadow-lg">
      <Download className="w-4 h-4" />Installa app
    </button>
  );
}
