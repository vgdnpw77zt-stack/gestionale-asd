import React, { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { api, API } from "../lib/api";
import { CheckCircle2, XCircle, Loader2, Home } from "lucide-react";
import { fmtEuro } from "../lib/utils-app";

export function PaymentSuccess() {
  const [sp] = useSearchParams();
  const nav = useNavigate();
  const sid = sp.get("session_id");
  const [state, setState] = useState({ loading: true, paid: false, data: null });

  useEffect(() => {
    if (!sid) { setState({ loading: false, paid: false }); return; }
    let attempts = 0;
    const poll = async () => {
      try {
        const r = await fetch(`${API}/checkout/status/${sid}`);
        const d = await r.json();
        if (d.payment_status === "paid") { setState({ loading: false, paid: true, data: d }); return; }
        if (++attempts < 15) setTimeout(poll, 2000);
        else setState({ loading: false, paid: false, data: d });
      } catch { setState({ loading: false, paid: false }); }
    };
    poll();
  }, [sid]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
      <div className="card-elev p-10 max-w-md w-full text-center">
        {state.loading ? (
          <>
            <Loader2 className="w-14 h-14 mx-auto text-sky-600 animate-spin" />
            <h1 className="text-2xl font-extrabold mt-4">Verifica pagamento…</h1>
            <p className="text-slate-500 text-sm mt-2">Non chiudere questa pagina.</p>
          </>
        ) : state.paid ? (
          <>
            <CheckCircle2 className="w-16 h-16 mx-auto text-emerald-600" />
            <h1 className="text-3xl font-extrabold mt-4">Pagamento riuscito</h1>
            <p className="text-slate-600 mt-2">{state.data?.causale}</p>
            <div className="stat-num text-4xl mt-4 text-emerald-700">{fmtEuro(state.data?.importo)}</div>
            <div className="text-xs text-slate-400 mt-4">La ricevuta è stata registrata automaticamente.</div>
            <button onClick={()=>nav("/")} className="mt-6 inline-flex items-center gap-2 h-10 px-4 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold"><Home className="w-4 h-4" />Vai al gestionale</button>
          </>
        ) : (
          <>
            <XCircle className="w-16 h-16 mx-auto text-amber-500" />
            <h1 className="text-2xl font-extrabold mt-4">In attesa di conferma</h1>
            <p className="text-slate-500 mt-2">Il pagamento non risulta ancora confermato. Ricontrolla tra qualche minuto.</p>
          </>
        )}
      </div>
    </div>
  );
}

export function PaymentCancel() {
  const nav = useNavigate();
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
      <div className="card-elev p-10 max-w-md w-full text-center">
        <XCircle className="w-16 h-16 mx-auto text-slate-400" />
        <h1 className="text-2xl font-extrabold mt-4">Pagamento annullato</h1>
        <p className="text-slate-500 mt-2">Nessun addebito è stato effettuato. Puoi riprovare in qualsiasi momento.</p>
        <button onClick={()=>nav("/")} className="mt-6 inline-flex items-center gap-2 h-10 px-4 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold"><Home className="w-4 h-4" />Vai al gestionale</button>
      </div>
    </div>
  );
}
