import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Btn, Input, Textarea, Select, Modal, Badge, EmptyState } from "./_ui";
import { toast } from "sonner";
import { Plus, Trash2, MailPlus, Send, CheckCircle2 } from "lucide-react";
import { fmtDateTime } from "../lib/utils-app";

const templates = {
  sollecito_certificato: {
    oggetto: "Sollecito rinnovo certificato medico",
    testo: "Gentile Socio,\n\nla informiamo che il Suo certificato medico sportivo risulta in scadenza o scaduto. La invitiamo a provvedere al rinnovo il prima possibile, presentando in segreteria copia del nuovo certificato per poter continuare la Sua attività sportiva presso la nostra ASD.\n\nCordiali saluti,\nLa Segreteria",
  },
  sollecito_quota: {
    oggetto: "Sollecito quota associativa",
    testo: "Gentile Socio,\n\nrisulta ancora da saldare la quota associativa per la stagione sportiva in corso. La preghiamo di regolarizzare la Sua posizione presso la segreteria.\n\nCordiali saluti,\nLa Segreteria",
  },
  assemblea: {
    oggetto: "Convocazione Assemblea dei Soci",
    testo: "Ai sensi dello Statuto sociale, si convoca l'Assemblea dei Soci ordinaria per il giorno [data], alle ore [orario], presso [luogo], con il seguente ordine del giorno:\n\n1. Approvazione bilancio\n2. Attività e programma sportivo\n3. Varie ed eventuali\n\nLa Presidenza",
  },
  generica: { oggetto: "", testo: "" },
};

export default function Comunicazioni() {
  const [items, setItems] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ tipo: "generica", oggetto: "", testo: "", destinatari: [] });
  const [soci, setSoci] = useState([]);
  const [sendOpen, setSendOpen] = useState(null); // comunicazione da inviare
  const [emailStatus, setEmailStatus] = useState(null);
  const [selectedSoci, setSelectedSoci] = useState([]);
  const [sending, setSending] = useState(false);

  const load = async () => {
    const [c, s, e] = await Promise.all([api.get("/comunicazioni"), api.get("/soci"), api.get("/email/status")]);
    setItems(c.data); setSoci(s.data); setEmailStatus(e.data);
  };
  useEffect(() => { load(); }, []);

  const applyTemplate = (t) => { setForm({ ...form, tipo: t, ...templates[t] }); };
  const save = async () => {
    if (!form.oggetto || !form.testo) { toast.error("Oggetto e testo obbligatori"); return; }
    await api.post("/comunicazioni", form);
    toast.success("Comunicazione salvata"); setModal(false); setForm({ tipo: "generica", oggetto: "", testo: "", destinatari: [] }); load();
  };
  const del = async (c) => { if (!window.confirm("Eliminare?")) return; await api.delete(`/comunicazioni/${c.id}`); toast.success("Eliminato"); load(); };

  const openSend = (c) => {
    setSendOpen(c);
    // default: tutti i soci con email
    setSelectedSoci(soci.filter(s => s.email).map(s => s.id));
  };
  const toggleSocio = (id) => {
    setSelectedSoci(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };
  const doSend = async () => {
    if (selectedSoci.length === 0) { toast.error("Seleziona almeno un destinatario"); return; }
    setSending(true);
    try {
      const r = await api.post("/email/send", {
        destinatari_socio_ids: selectedSoci,
        oggetto: sendOpen.oggetto,
        testo: sendOpen.testo,
        comunicazione_id: sendOpen.id,
      });
      const { delivered, failed } = r.data;
      if (failed === 0) toast.success(`Inviata a ${delivered} destinatari`);
      else toast.warning(`Consegnate ${delivered}, fallite ${failed}`);
      setSendOpen(null); load();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Errore invio");
    } finally { setSending(false); }
  };

  return (
    <div>
      <PageHeader title="Comunicazioni" subtitle="Modelli pronti per lettere e avvisi ai soci, con invio email."
        action={<Btn testid="com-new-btn" onClick={()=>setModal(true)}><Plus className="w-4 h-4" />Nuova comunicazione</Btn>} />

      {emailStatus && emailStatus.active_provider === "none" && (
        <div className="card-elev p-4 mb-4 bg-amber-50 border-amber-200 text-sm text-amber-900" data-testid="com-email-warning">
          <b>Invio email non configurato.</b> Vai in <span className="mono">Impostazioni ASD → SMTP</span> per abilitare l'invio.
        </div>
      )}

      {items.length === 0 ? <EmptyState title="Nessuna comunicazione" /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {items.map(c => (
            <div key={c.id} className="card-elev p-5" data-testid={`com-card-${c.id}`}>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <Badge tone="indigo">{c.tipo}</Badge>
                  {c.inviata && <Badge tone="emerald"><CheckCircle2 className="w-3 h-3 mr-1 inline" />Inviata</Badge>}
                </div>
                <button data-testid={`com-del-${c.id}`} onClick={()=>del(c)} className="p-1.5 rounded-md hover:bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
              </div>
              <h3 className="font-bold mt-2">{c.oggetto}</h3>
              <div className="text-xs text-slate-400 mt-1">{fmtDateTime(c.data)}</div>
              <p className="text-sm text-slate-600 mt-3 whitespace-pre-wrap line-clamp-6">{c.testo}</p>
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <div className="text-xs text-slate-500">Destinatari: {c.destinatari?.length || 0}</div>
                <button data-testid={`com-send-${c.id}`} onClick={()=>openSend(c)}
                  className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold">
                  <Send className="w-4 h-4" />Invia
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={!!sendOpen} onClose={()=>setSendOpen(null)} title={sendOpen ? `Invia: ${sendOpen.oggetto}` : ""} wide>
        {sendOpen && (
          <div className="space-y-4">
            <div className="rounded-lg bg-sky-50 border border-sky-200 p-3 text-sm text-sky-900">
              Provider attivo: <b>{emailStatus?.active_provider === "smtp" ? "SMTP" : emailStatus?.active_provider === "resend" ? "Resend" : "Nessuno"}</b>. {emailStatus?.active_provider === "none" && "Configura SMTP in Impostazioni."}
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Destinatari ({selectedSoci.length} selezionati)</span>
                <div className="flex gap-2">
                  <button data-testid="com-sel-all" onClick={()=>setSelectedSoci(soci.filter(s=>s.email).map(s=>s.id))} className="text-xs text-sky-700 font-semibold">Tutti</button>
                  <button data-testid="com-sel-none" onClick={()=>setSelectedSoci([])} className="text-xs text-slate-500 font-semibold">Nessuno</button>
                </div>
              </div>
              <div className="max-h-72 overflow-y-auto border border-slate-100 rounded-lg p-2 space-y-1">
                {soci.map(s => (
                  <label key={s.id} className={`flex items-center gap-3 px-2 py-1.5 rounded-md ${!s.email ? "opacity-50 cursor-not-allowed" : "hover:bg-slate-50 cursor-pointer"}`}>
                    <input type="checkbox" data-testid={`com-dest-${s.id}`} disabled={!s.email}
                      checked={selectedSoci.includes(s.id)} onChange={()=>toggleSocio(s.id)} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-slate-900 truncate">{s.cognome} {s.nome}</div>
                      <div className="text-xs text-slate-400 truncate">{s.email || "— nessuna email —"}</div>
                    </div>
                  </label>
                ))}
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <Btn variant="ghost" onClick={()=>setSendOpen(null)}>Annulla</Btn>
              <Btn testid="com-send-confirm" onClick={doSend} disabled={sending || emailStatus?.active_provider === "none"}>
                <Send className="w-4 h-4" />{sending ? "Invio..." : `Invia a ${selectedSoci.length}`}
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      <Modal open={modal} onClose={()=>setModal(false)} title="Nuova comunicazione" wide>
        <div className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {Object.keys(templates).map(t => (
              <button key={t} data-testid={`com-tpl-${t}`} onClick={()=>applyTemplate(t)}
                className={`h-9 px-3 rounded-lg text-sm font-semibold transition ${form.tipo===t ? "bg-sky-600 text-white" : "bg-slate-100 hover:bg-slate-200 text-slate-700"}`}>
                {t}
              </button>
            ))}
          </div>
          <Input testid="com-form-oggetto" label="Oggetto *" value={form.oggetto} onChange={(e)=>setForm({...form, oggetto: e.target.value})} />
          <Textarea testid="com-form-testo" label="Testo *" rows={10} value={form.testo} onChange={(e)=>setForm({...form, testo: e.target.value})}
            style={{ minHeight: 220 }} />
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Btn variant="ghost" onClick={()=>setModal(false)}>Annulla</Btn>
          <Btn testid="com-form-save" onClick={save}><MailPlus className="w-4 h-4" />Salva</Btn>
        </div>
      </Modal>
    </div>
  );
}
