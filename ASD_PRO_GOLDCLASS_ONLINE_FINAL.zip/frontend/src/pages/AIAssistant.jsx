import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Btn, Textarea, Select, Badge, Input } from "./_ui";
import { toast } from "sonner";
import { Sparkles, Loader2, Copy, History, Image as ImageIcon, Type, Download } from "lucide-react";
import { fmtDateTime } from "../lib/utils-app";

const suggestions = [
  { tipo: "verbale", label: "Verbale assemblea", prompt: "Redigi un verbale di assemblea ordinaria dei soci con approvazione del bilancio consuntivo 2024 e preventivo 2025." },
  { tipo: "comunicazione", label: "Sollecito certificato", prompt: "Scrivi una lettera formale di sollecito per il rinnovo del certificato medico sportivo." },
  { tipo: "regolamento", label: "Regolamento interno", prompt: "Redigi un breve regolamento interno per l'utilizzo degli spogliatoi e delle attrezzature sportive." },
  { tipo: "riepilogo", label: "Riepilogo mensile", prompt: "Prepara un riepilogo mensile delle attività della ASD." },
];

const imgSuggestions = [
  { tipo: "locandina", label: "Locandina torneo", prompt: "Torneo di calcio giovanile con logo scudetto, pallone in evidenza, colori blu e verde." },
  { tipo: "volantino", label: "Volantino corso", prompt: "Volantino iscrizioni corso di ginnastica ritmica per bambine 6-12 anni, colori pastello." },
  { tipo: "poster", label: "Poster evento", prompt: "Poster festa di fine anno ASD con foto di squadre miste, colori sportivi." },
  { tipo: "logo", label: "Idea logo", prompt: "Logo minimalista per ASD di basket, colori arancio e nero." },
];

export default function AIAssistant() {
  const [tab, setTab] = useState("testo");
  const [prompt, setPrompt] = useState("");
  const [tipo, setTipo] = useState("documento");
  const [model, setModel] = useState("claude");
  const [contesto, setContesto] = useState("");
  const [out, setOut] = useState("");
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);
  const [imgTipo, setImgTipo] = useState("locandina");
  const [imgPrompt, setImgPrompt] = useState("");
  const [imgOut, setImgOut] = useState(null);
  const [imgLoading, setImgLoading] = useState(false);
  const [imgHistory, setImgHistory] = useState([]);

  useEffect(() => {
    api.get("/settings").then(r => {
      setContesto(`Nome ASD: ${r.data.ragione_sociale || ""}\nPresidente: ${r.data.presidente || ""}\nSede: ${r.data.indirizzo || ""}, ${r.data.citta || ""}`);
    });
    api.get("/ai/history").then(r => setHistory(r.data));
    api.get("/ai/images").then(r => setImgHistory(r.data));
  }, []);

  const generate = async () => {
    if (!prompt) { toast.error("Inserisci una richiesta"); return; }
    setLoading(true); setOut("");
    try {
      const r = await api.post("/ai/generate", { prompt, tipo, contesto, model });
      setOut(r.data.text);
      const h = await api.get("/ai/history"); setHistory(h.data);
      toast.success(`Generato con ${r.data.model}`);
    } catch (e) { toast.error(e?.response?.data?.detail || "Errore AI"); }
    finally { setLoading(false); }
  };

  const generateImage = async () => {
    if (!imgPrompt) { toast.error("Inserisci una descrizione"); return; }
    setImgLoading(true); setImgOut(null);
    try {
      const r = await api.post("/ai/image", { prompt: imgPrompt, tipo: imgTipo });
      setImgOut(r.data);
      const h = await api.get("/ai/images"); setImgHistory(h.data);
      toast.success("Immagine generata");
    } catch (e) { toast.error(e?.response?.data?.detail || "Errore generazione immagine"); }
    finally { setImgLoading(false); }
  };

  const copyOut = () => { navigator.clipboard.writeText(out); toast.success("Copiato negli appunti"); };

  const downloadImg = (url, name = "immagine_asd.png") => {
    const a = document.createElement("a"); a.href = url; a.download = name; a.click();
  };

  return (
    <div>
      <PageHeader title="Assistente AI" subtitle="Testi + immagini per la tua ASD. Scegli il modello preferito." />

      <div className="card-elev p-1 mb-4 inline-flex gap-1">
        <button data-testid="ai-tab-testo" onClick={()=>setTab("testo")}
          className={`h-9 px-4 rounded-lg text-sm font-semibold inline-flex items-center gap-2 ${tab==="testo" ? "bg-sky-600 text-white" : "text-slate-700 hover:bg-slate-100"}`}>
          <Type className="w-4 h-4" />Testo
        </button>
        <button data-testid="ai-tab-immagine" onClick={()=>setTab("immagine")}
          className={`h-9 px-4 rounded-lg text-sm font-semibold inline-flex items-center gap-2 ${tab==="immagine" ? "bg-sky-600 text-white" : "text-slate-700 hover:bg-slate-100"}`}>
          <ImageIcon className="w-4 h-4" />Immagine
        </button>
      </div>

      {tab === "testo" ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 space-y-4">
            <div className="card-elev p-5">
              <div className="flex flex-wrap gap-2 mb-4">
                {suggestions.map(s => (
                  <button key={s.label} data-testid={`ai-sugg-${s.tipo}`} onClick={()=>{ setTipo(s.tipo); setPrompt(s.prompt); }}
                    className="h-9 px-3 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-sm font-semibold transition">
                    {s.label}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 mb-3">
                <Select testid="ai-model" label="Modello AI" value={model} onChange={(e)=>setModel(e.target.value)}>
                  <option value="claude">Claude Sonnet 4.6</option>
                  <option value="gpt">ChatGPT 5.4</option>
                  <option value="gemini">Gemini 3.1 Pro</option>
                </Select>
                <Select testid="ai-tipo" label="Tipo" value={tipo} onChange={(e)=>setTipo(e.target.value)}>
                  <option value="documento">Documento</option>
                  <option value="comunicazione">Comunicazione</option>
                  <option value="verbale">Verbale</option>
                  <option value="regolamento">Regolamento</option>
                  <option value="riepilogo">Riepilogo</option>
                </Select>
                <div className="sm:col-span-2"><Textarea testid="ai-contesto" label="Contesto ASD" rows={2} value={contesto} onChange={(e)=>setContesto(e.target.value)} /></div>
              </div>
              <Textarea testid="ai-prompt" label="La tua richiesta *" rows={5} placeholder="Es. Scrivi una lettera di convocazione..." value={prompt} onChange={(e)=>setPrompt(e.target.value)} style={{minHeight:140}} />
              <div className="mt-4 flex justify-end">
                <Btn testid="ai-generate-btn" onClick={generate} disabled={loading}>
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}Genera
                </Btn>
              </div>
            </div>
            {out && (
              <div className="card-elev p-5" data-testid="ai-output">
                <div className="flex items-center justify-between mb-3">
                  <Badge tone="indigo">Risultato</Badge>
                  <Btn variant="outline" testid="ai-copy-btn" onClick={copyOut}><Copy className="w-4 h-4" />Copia</Btn>
                </div>
                <div className="whitespace-pre-wrap text-slate-800 leading-relaxed text-sm">{out}</div>
              </div>
            )}
          </div>
          <div className="card-elev p-5 self-start">
            <div className="flex items-center gap-2 mb-3 text-slate-600"><History className="w-4 h-4" /><span className="text-sm font-semibold">Storico testi</span></div>
            {history.length === 0 ? <div className="text-sm text-slate-400">Nessuna richiesta.</div> : (
              <div className="space-y-3 max-h-[500px] overflow-y-auto">
                {history.map(h => (
                  <button key={h.id} onClick={()=>setOut(h.response)} className="w-full text-left rounded-lg border border-slate-100 p-3 hover:border-sky-200 hover:bg-sky-50 transition">
                    <div className="text-xs text-slate-400 flex items-center justify-between">
                      <span>{fmtDateTime(h.created_at)}</span>
                      {h.model && <Badge tone="slate">{h.model}</Badge>}
                    </div>
                    <div className="text-sm font-semibold text-slate-800 line-clamp-1 mt-1">{h.prompt}</div>
                    <div className="text-xs text-slate-500 line-clamp-2 mt-1">{h.response?.slice(0, 120)}…</div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 space-y-4">
            <div className="card-elev p-5">
              <div className="flex flex-wrap gap-2 mb-4">
                {imgSuggestions.map(s => (
                  <button key={s.label} data-testid={`ai-img-sugg-${s.tipo}`} onClick={()=>{ setImgTipo(s.tipo); setImgPrompt(s.prompt); }}
                    className="h-9 px-3 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-sm font-semibold transition">
                    {s.label}
                  </button>
                ))}
              </div>
              <Select testid="ai-img-tipo" label="Formato" value={imgTipo} onChange={(e)=>setImgTipo(e.target.value)}>
                <option value="locandina">Locandina evento</option>
                <option value="volantino">Volantino</option>
                <option value="poster">Poster</option>
                <option value="logo">Logo</option>
              </Select>
              <div className="mt-3">
                <Textarea testid="ai-img-prompt" label="Descrivi l'immagine *" rows={4} placeholder="Es. Torneo estivo di beach volley, sfondo mare, colori corallo..." value={imgPrompt} onChange={(e)=>setImgPrompt(e.target.value)} style={{minHeight:120}} />
              </div>
              <div className="mt-4 flex justify-end">
                <Btn testid="ai-img-generate" onClick={generateImage} disabled={imgLoading}>
                  {imgLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />}Genera immagine
                </Btn>
              </div>
              <div className="mt-2 text-xs text-slate-400">Powered by Gemini Nano Banana (Emergent LLM Key)</div>
            </div>
            {imgOut && (
              <div className="card-elev p-5" data-testid="ai-img-output">
                <div className="flex items-center justify-between mb-3">
                  <Badge tone="rose">Immagine generata</Badge>
                  <Btn variant="outline" testid="ai-img-download" onClick={()=>downloadImg(imgOut.data_url)}><Download className="w-4 h-4" />Scarica</Btn>
                </div>
                <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-50">
                  <img alt="Immagine generata" src={imgOut.data_url} className="w-full h-auto" />
                </div>
              </div>
            )}
          </div>
          <div className="card-elev p-5 self-start">
            <div className="flex items-center gap-2 mb-3 text-slate-600"><History className="w-4 h-4" /><span className="text-sm font-semibold">Storico immagini</span></div>
            {imgHistory.length === 0 ? <div className="text-sm text-slate-400">Nessuna immagine.</div> : (
              <div className="grid grid-cols-2 gap-2 max-h-[500px] overflow-y-auto">
                {imgHistory.map(h => (
                  <button key={h.id} onClick={()=>setImgOut(h)} className="rounded-lg border border-slate-100 overflow-hidden hover:border-rose-300 transition">
                    <img alt="storico" src={h.data_url} className="w-full h-24 object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
