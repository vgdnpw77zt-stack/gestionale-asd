import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../lib/auth.jsx";
import { toast } from "sonner";
import { Trophy, ShieldCheck, Loader2 } from "lucide-react";

export default function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(username, password);
      toast.success("Accesso effettuato");
      nav("/", { replace: true });
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Credenziali non valide");
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen w-full grid grid-cols-1 lg:grid-cols-2">
      <div className="hidden lg:flex relative gradient-header grain items-center justify-center p-10 text-white overflow-hidden">
        <div className="max-w-md relative z-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center">
              <Trophy className="w-6 h-6" />
            </div>
            <span className="text-sm uppercase tracking-widest font-semibold text-sky-100">ASD Master</span>
          </div>
          <h1 className="text-4xl xl:text-5xl font-extrabold leading-tight mb-4">
            Il gestionale della tua Associazione Sportiva.
          </h1>
          <p className="text-sky-100/90 text-lg leading-relaxed">
            Soci, tesseramenti, quote, certificati medici, corsi, presenze e comunicazioni — tutto integrato,
            in italiano, con assistente AI e backup sicuro.
          </p>
          <div className="mt-10 grid grid-cols-2 gap-4 text-sm">
            {[
              ["Anagrafica", "Soci e Atleti"],
              ["Tesseramenti", "CSEN / UISP / FIP"],
              ["Ricevute", "Numerate ASD"],
              ["Alert Medici", "Scadenze 30gg"],
            ].map(([a,b]) => (
              <div key={a} className="rounded-xl bg-white/10 backdrop-blur border border-white/15 p-4">
                <div className="font-semibold">{a}</div>
                <div className="text-sky-100/80 text-xs">{b}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="flex items-center justify-center p-6 sm:p-10 bg-slate-50">
        <form onSubmit={onSubmit} className="w-full max-w-md card-elev p-8" data-testid="login-form">
          <div className="flex items-center gap-2 mb-1 text-sky-700">
            <ShieldCheck className="w-4 h-4" />
            <span className="text-xs font-semibold uppercase tracking-widest">Accesso Segreteria</span>
          </div>
          <h2 className="text-2xl font-bold mb-1">Bentornato</h2>
          <p className="text-slate-500 text-sm mb-6">Accedi per gestire la tua ASD.</p>

          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Utente</label>
          <input
            data-testid="login-username-input"
            className="mt-1 mb-4 w-full h-11 px-3 rounded-lg border border-slate-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-100 outline-none"
            value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username"
          />
          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Password</label>
          <input
            data-testid="login-password-input"
            type="password"
            className="mt-1 mb-6 w-full h-11 px-3 rounded-lg border border-slate-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-100 outline-none"
            value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password"
          />
          <button
            data-testid="login-submit-btn"
            disabled={loading}
            className="w-full h-11 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-semibold flex items-center justify-center gap-2 transition-colors disabled:opacity-60"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
            Accedi
          </button>
          <p className="text-xs text-slate-400 mt-6">
            Default: <span className="mono">admin / admin123</span> — modificabili in <span className="mono">backend/.env</span>.
          </p>
        </form>
      </div>
    </div>
  );
}
