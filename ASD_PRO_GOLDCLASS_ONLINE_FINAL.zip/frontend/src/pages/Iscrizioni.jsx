import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Btn, Input, Select, Modal, Badge, EmptyState } from "./_ui";
import { toast } from "sonner";
import { CreditCard, Link2, Copy, ExternalLink, CheckCircle2, Clock, XCircle } from "lucide-react";
import { fmtEuro, fmtDateTime } from "../lib/utils-app";

const statusBadge = (s, ps) => {
  if (ps === "paid") return <Badge tone="emerald"><CheckCircle2 className="w-3 h-3 mr-1 inline" />Pagato</Badge>;
  if (ps === "pending") return <Badge tone="amber"><Clock className="w-3 h-3 mr-1 inline" />In attesa</Badge>;
  if (ps === "failed" || s === "failed") return <Badge tone="rose"><XCircle className="w-3 h-3 mr-1 inline" />Fallito</Badge>;
  if (s === "expired") return <Badge tone="slate">Scaduto</Badge>;
  return <Badge tone="slate">{ps || s}</Badge>;
};

export default function Iscrizioni() {
  const [items, setItems] = useState([]);
  const [soci, setSoci] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ importo: 150, causale: "Quota associativa 2024/2025", socio_id: "", email: "", stagione: "2024/2025" });
  const [result, setResult] = useState(null);

  const load = async () => {
    const [t, s] = await Promise.all([api.get("/checkout/list"), api.get("/soci")]);
    setItems(t.data); setSoci(s.data);
  };
  useEffect(() => { load(); const i = setInterval(load, 8000); return () => clearInterval(i); }, []);

  const sName = (id) => { const s = soci.find(x => x.id === id); return s ? `${s.cognome} ${s.nome}` : "—"; };

  const create = async () => {
    if (!form.importo || !form.causale) { toast.error("Importo e causale obbligatori"); return; }
    try {
      const r = await api.post("/checkout/create", { ...form, origin_url: window.location.origin });
      setResult(r.data);
      toast.success("Link di pagamento creato");
      load();
    } catch (e) { toast.error(e?.response?.data?.detail || "Errore"); }
  };

  const copy = (url) => { navigator.clipboard.writeText(url); toast.success("Link copiato"); };

  const total = items.filter(t => t.payment_status === "paid").reduce((a, b) => a + Number(b.importo || 0), 0);
  const pending = items.filter(t => t.payment_status === "pending").length;

  return (
    <div>
      <PageHeader title="Iscrizioni Online" subtitle="Genera link Stripe (carte + Klarna) da inviare ai soci per pagare quote e iscrizioni."
        action={<Btn testid="isc-new-btn" onClick={()=>{ setResult(null); setModal(true); }}><Link2 className="w-4 h-4" />Nuovo link di pagamento</Btn>} />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="card-elev p-4"><div className="text-xs font-semibold uppercase tracking-wider text-slate-500">Link totali</div><div className="stat-num text-2xl mt-1">{items.length}</div></div>
        <div className="card-elev p-4"><div className="text-xs font-semibold uppercase tracking-wider text-slate-500">Incassato online</div><div className="stat-num text-2xl mt-1 text-emerald-700">{fmtEuro(total)}</div></div>
        <div className="card-elev p-4"><div className="text-xs font-semibold uppercase tracking-wider text-slate-500">In attesa</div><div className="stat-num text-2xl mt-1 text-amber-700">{pending}</div></div>
        <div className="card-elev p-4 bg-indigo-50 border-indigo-100"><div className="text-xs font-semibold uppercase tracking-wider text-indigo-700">Metodi supportati</div><div className="mt-1 text-sm text-indigo-900">Carte • Klarna • Apple Pay • Google Pay</div></div>
      </div>

      {items.length === 0 ? <EmptyState title="Nessun link generato" subtitle="Genera un link e invialo al socio via email o WhatsApp."
        action={<Btn onClick={()=>setModal(true)}><Link2 className="w-4 h-4" />Nuovo link</Btn>} /> : (
        <div className="card-elev overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="text-left px-4 py-3">Data</th>
                <th className="text-left px-4 py-3">Socio / Email</th>
                <th className="text-left px-4 py-3">Causale</th>
                <th className="text-right px-4 py-3">Importo</th>
                <th className="text-left px-4 py-3">Stato</th>
                <th className="text-right px-4 py-3">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {items.map(t => (
                <tr key={t.id} className="border-t border-slate-100 hover:bg-slate-50" data-testid={`isc-row-${t.id}`}>
                  <td className="px-4 py-3">{fmtDateTime(t.created_at)}</td>
                  <td className="px-4 py-3">
                    <div className="font-semibold text-slate-900">{t.socio_id ? sName(t.socio_id) : "—"}</div>
                    <div className="text-xs text-slate-500">{t.email || "—"}</div>
                  </td>
                  <td className="px-4 py-3">{t.causale}</td>
                  <td className="px-4 py-3 text-right font-bold text-emerald-700">{fmtEuro(t.importo)}</td>
                  <td className="px-4 py-3">{statusBadge(t.status, t.payment_status)}</td>
                  <td className="px-4 py-3 text-right">
                    <button data-testid={`isc-copy-${t.id}`} onClick={()=>copy(t.url)} className="p-2 rounded-lg hover:bg-sky-50 text-sky-700" title="Copia link"><Copy className="w-4 h-4" /></button>
                    <a data-testid={`isc-open-${t.id}`} href={t.url} target="_blank" rel="noreferrer" className="inline-block p-2 rounded-lg hover:bg-indigo-50 text-indigo-700"><ExternalLink className="w-4 h-4" /></a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={modal} onClose={()=>setModal(false)} title={result ? "Link pronto" : "Nuovo link di pagamento"}>
        {!result ? (
          <>
            <div className="grid grid-cols-2 gap-3">
              <Select testid="isc-form-socio" label="Socio (opzionale, per abbinare la ricevuta)" value={form.socio_id} onChange={(e)=>setForm({...form, socio_id: e.target.value})}>
                <option value="">— Nessuno —</option>
                {soci.map(s => <option key={s.id} value={s.id}>{s.cognome} {s.nome}</option>)}
              </Select>
              <Input testid="isc-form-email" label="Email (opzionale)" placeholder="socio@example.it" value={form.email} onChange={(e)=>setForm({...form, email: e.target.value})} />
              <div className="col-span-2"><Input testid="isc-form-causale" label="Causale *" value={form.causale} onChange={(e)=>setForm({...form, causale: e.target.value})} /></div>
              <Input testid="isc-form-importo" type="number" step="0.01" label="Importo € *" value={form.importo} onChange={(e)=>setForm({...form, importo: Number(e.target.value)})} />
              <Input testid="isc-form-stagione" label="Stagione" value={form.stagione} onChange={(e)=>setForm({...form, stagione: e.target.value})} />
            </div>
            <div className="mt-4 rounded-lg bg-slate-50 p-3 text-xs text-slate-600 border border-slate-100">
              Modalità test: usa carta <span className="mono">4242 4242 4242 4242</span>, scadenza futura, CVC qualsiasi.
              Klarna richiede un flusso demo che si completa da solo nel sandbox.
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <Btn variant="ghost" onClick={()=>setModal(false)}>Annulla</Btn>
              <Btn testid="isc-form-create" onClick={create}><CreditCard className="w-4 h-4" />Genera link</Btn>
            </div>
          </>
        ) : (
          <div className="space-y-4">
            <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-4">
              <div className="text-sm text-emerald-900 mb-3">Link Stripe pronto — invialo al socio.</div>
              <div className="flex items-center gap-2 bg-white rounded-lg border border-slate-200 p-2">
                <input readOnly value={result.checkout_url} className="flex-1 text-xs mono outline-none px-2" />
                <button data-testid="isc-result-copy" onClick={()=>copy(result.checkout_url)}
                  className="h-9 px-3 rounded-md bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold flex items-center gap-1"><Copy className="w-4 h-4" />Copia</button>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <a href={result.checkout_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 h-10 px-4 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold">
                <ExternalLink className="w-4 h-4" />Apri checkout
              </a>
              <Btn onClick={()=>{ setModal(false); setResult(null); }}>Chiudi</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
