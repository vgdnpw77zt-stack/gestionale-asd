import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Select, Input, Btn, Badge, EmptyState } from "./_ui";
import { toast } from "sonner";
import { todayIso } from "../lib/utils-app";
import { CheckCircle2, XCircle } from "lucide-react";

export default function Presenze() {
  const [corsi, setCorsi] = useState([]);
  const [soci, setSoci] = useState([]);
  const [corsoId, setCorsoId] = useState("");
  const [data, setData] = useState(todayIso());
  const [rec, setRec] = useState({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      const [c, s] = await Promise.all([api.get("/corsi"), api.get("/soci")]);
      setCorsi(c.data); setSoci(s.data);
      if (c.data[0]) setCorsoId(c.data[0].id);
    })();
  }, []);

  useEffect(() => {
    if (!corsoId || !data) return;
    (async () => {
      const r = await api.get("/presenze", { params: { corso_id: corsoId, data } });
      const m = {};
      r.data.forEach(p => { m[p.socio_id] = p.presente; });
      setRec(m);
    })();
  }, [corsoId, data]);

  const soggetti = soci.filter(s => s.attivo);
  const toggle = (id) => setRec({ ...rec, [id]: !rec[id] });

  const save = async () => {
    if (!corsoId) { toast.error("Seleziona corso"); return; }
    setLoading(true);
    try {
      const records = soggetti.map(s => ({ socio_id: s.id, presente: !!rec[s.id] }));
      await api.post("/presenze/bulk", { corso_id: corsoId, data, records });
      toast.success("Presenze salvate");
    } catch { toast.error("Errore"); }
    finally { setLoading(false); }
  };

  const totalPres = soggetti.filter(s => rec[s.id]).length;

  return (
    <div>
      <PageHeader title="Registro Presenze" subtitle="Check-in rapido per corso e data."
        action={<Btn testid="presenze-save-btn" onClick={save} disabled={loading}>Salva presenze</Btn>} />

      <div className="card-elev p-4 mb-4 grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
        <Select testid="presenze-corso" label="Corso" value={corsoId} onChange={(e)=>setCorsoId(e.target.value)}>
          <option value="">Seleziona corso</option>
          {corsi.map(c => <option key={c.id} value={c.id}>{c.nome}</option>)}
        </Select>
        <Input type="date" testid="presenze-data" label="Data" value={data} onChange={(e)=>setData(e.target.value)} />
        <div className="text-right">
          <Badge tone="emerald">{totalPres} presenti / {soggetti.length}</Badge>
        </div>
      </div>

      {soggetti.length === 0 ? <EmptyState title="Nessun socio attivo" /> : (
        <div className="card-elev overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr><th className="text-left px-4 py-3">Socio</th><th className="text-left px-4 py-3">Disciplina</th><th className="text-right px-4 py-3">Presenza</th></tr>
            </thead>
            <tbody>
              {soggetti.map((s) => (
                <tr key={s.id} className="border-t border-slate-100">
                  <td className="px-4 py-3 font-semibold">{s.cognome} {s.nome}</td>
                  <td className="px-4 py-3 text-slate-600">{s.disciplina || "—"}</td>
                  <td className="px-4 py-3 text-right">
                    <button data-testid={`pres-toggle-${s.id}`} onClick={()=>toggle(s.id)}
                      className={`inline-flex items-center gap-2 h-9 px-3 rounded-lg text-sm font-semibold transition ${rec[s.id] ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                      {rec[s.id] ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                      {rec[s.id] ? "Presente" : "Assente"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
