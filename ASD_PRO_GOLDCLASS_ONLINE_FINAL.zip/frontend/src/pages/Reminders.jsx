import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Btn, Badge, EmptyState } from "./_ui";
import { toast } from "sonner";
import { Send, ShieldCheck, CheckCircle2, AlertTriangle, Play } from "lucide-react";
import { fmtDate, fmtDateTime } from "../lib/utils-app";

export default function Reminders() {
  const [preview, setPreview] = useState([]);
  const [log, setLog] = useState([]);
  const [running, setRunning] = useState(false);

  const load = async () => {
    const [p, l] = await Promise.all([api.get("/reminders/preview"), api.get("/reminders/log")]);
    setPreview(p.data); setLog(l.data);
  };
  useEffect(() => { load(); }, []);

  const runNow = async () => {
    if (!window.confirm("Inviare adesso i reminder ai soci con certificato in scadenza a 30/15/7 giorni?")) return;
    setRunning(true);
    try {
      const r = await api.post("/reminders/run");
      toast.success(`Inviati ${r.data.sent}, saltati ${r.data.skipped}, senza email ${r.data.no_email}`);
      load();
    } catch (e) { toast.error(e?.response?.data?.detail || "Errore invio"); }
    finally { setRunning(false); }
  };

  const tone = (m) => m <= 7 ? "rose" : m <= 15 ? "amber" : "sky";

  return (
    <div>
      <PageHeader title="Reminder Certificati" subtitle="Invio automatico ogni giorno alle 08:00 UTC a 30, 15 e 7 giorni dalla scadenza."
        action={<Btn testid="rem-run-btn" onClick={runNow} disabled={running}><Play className="w-4 h-4" />{running ? "Invio…" : "Esegui ora"}</Btn>} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card-elev p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-lg">In coda oggi</h3>
            <Badge tone="sky">{preview.filter(x=>!x.already_sent).length} da inviare</Badge>
          </div>
          {preview.length === 0 ? <div className="text-sm text-slate-400">Nessun reminder in coda oggi.</div> : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {preview.map((p, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100">
                  <div>
                    <div className="text-sm font-semibold text-slate-900">{p.socio || "—"}</div>
                    <div className="text-xs text-slate-500">{p.email || "— nessuna email —"}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge tone={tone(p.milestone)}>{p.milestone} giorni • {fmtDate(p.data_scadenza)}</Badge>
                    {p.already_sent && <Badge tone="emerald"><CheckCircle2 className="w-3 h-3 mr-1 inline" />Inviato</Badge>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card-elev p-5">
          <h3 className="font-bold text-lg mb-3">Storico invii</h3>
          {log.length === 0 ? <div className="text-sm text-slate-400">Nessun invio registrato.</div> : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {log.map(l => (
                <div key={l.id} className="flex items-center justify-between p-2 rounded-lg border border-slate-100">
                  <div className="min-w-0">
                    <div className="text-sm font-semibold truncate">{l.email}</div>
                    <div className="text-xs text-slate-400">{fmtDateTime(l.created_at)}</div>
                  </div>
                  <div className="flex gap-2">
                    <Badge tone={tone(l.milestone)}>-{l.milestone}gg</Badge>
                    {l.sent ? <Badge tone="emerald">OK</Badge> : <Badge tone="rose">FAIL</Badge>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="card-elev p-5 mt-4">
        <div className="flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-sky-600 mt-1" />
          <div className="text-sm text-slate-600">
            <div className="font-semibold text-slate-800 mb-1">Come funziona</div>
            <ul className="list-disc pl-5 space-y-1">
              <li>Ogni giorno alle 08:00 UTC il sistema scansiona tutti i certificati e invia email a 30, 15 e 7 giorni dalla scadenza.</li>
              <li>Ogni promemoria viene inviato una sola volta (idempotenza per socio + scadenza + milestone).</li>
              <li>Provider email attivo: <span className="mono">Resend</span> se disponibile, altrimenti <span className="mono">SMTP</span> di Impostazioni.</li>
              <li>Puoi eseguire manualmente con "Esegui ora" per testare.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
