import React, { useEffect, useState } from "react";
import { api, API } from "../lib/api";
import { PageHeader, Btn, Input, Select, Modal, Badge, EmptyState, Textarea } from "./_ui";
import { toast } from "sonner";
import { Plus, Trash2, Pencil, FileText, FileCode2, Receipt } from "lucide-react";
import { fmtDate, fmtEuro, todayIso } from "../lib/utils-app";

const empty = {
  data_emissione: todayIso(), anno: new Date().getFullYear(), socio_id: "",
  cliente_denominazione: "", cliente_cf: "", cliente_piva: "", cliente_indirizzo: "",
  cliente_cap: "", cliente_citta: "", cliente_provincia: "", cliente_paese: "IT",
  cliente_codice_sdi: "0000000", cliente_pec: "",
  righe: [{ descrizione: "Quota associativa", quantita: 1, prezzo_unitario: 150, aliquota_iva: 0 }],
  tipo_documento: "TD01", causale: "", modalita_pagamento: "MP05", stato: "bozza", note: "",
};

export default function Fatture() {
  const [items, setItems] = useState([]);
  const [soci, setSoci] = useState([]);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);

  const load = async () => {
    const [f, s] = await Promise.all([api.get("/fatture"), api.get("/soci")]);
    setItems(f.data); setSoci(s.data);
  };
  useEffect(() => { load(); }, []);

  const setRiga = (i, k, v) => {
    const r = [...form.righe]; r[i] = { ...r[i], [k]: k === "descrizione" ? v : Number(v) };
    setForm({ ...form, righe: r });
  };
  const addRiga = () => setForm({ ...form, righe: [...form.righe, { descrizione: "", quantita: 1, prezzo_unitario: 0, aliquota_iva: 0 }] });
  const delRiga = (i) => setForm({ ...form, righe: form.righe.filter((_,x)=>x!==i) });

  const preview = form.righe.reduce((a,r) => a + r.quantita * r.prezzo_unitario, 0);
  const previewIva = form.righe.reduce((a,r) => a + r.quantita * r.prezzo_unitario * r.aliquota_iva / 100, 0);

  const openNew = () => { setEditing(null); setForm({ ...empty, data_emissione: todayIso() }); setModal(true); };
  const openEdit = (f) => { setEditing(f); setForm({ ...empty, ...f, righe: f.righe?.length ? f.righe : empty.righe }); setModal(true); };

  const save = async () => {
    try {
      if (editing) await api.put(`/fatture/${editing.id}`, form);
      else await api.post("/fatture", form);
      toast.success("Fattura salvata"); setModal(false); load();
    } catch (e) { toast.error(e?.response?.data?.detail || "Errore"); }
  };

  const del = async (f) => { if (!window.confirm(`Eliminare fattura ${f.numero}?`)) return; await api.delete(`/fatture/${f.id}`); toast.success("Eliminata"); load(); };

  const downloadXml = async (f) => {
    const token = localStorage.getItem("asd_token");
    const res = await fetch(`${API}/fatture/${f.id}/xml`, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) return toast.error("Errore XML");
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `fattura_${f.numero.replace('/','_')}.xml`; a.click();
    URL.revokeObjectURL(url);
    toast.success("XML SdI scaricato");
  };

  const sName = (id) => { const s = soci.find(x=>x.id===id); return s ? `${s.cognome} ${s.nome}` : ""; };
  const total = items.reduce((a,f)=>a + Number(f.totale||0), 0);

  return (
    <div>
      <PageHeader title="Fatture Elettroniche" subtitle="Emissione fatture PA/B2B/B2C con esportazione XML SdI (FatturaPA 1.2)."
        action={<Btn testid="fatt-new-btn" onClick={openNew}><Plus className="w-4 h-4" />Nuova fattura</Btn>} />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="card-elev p-4"><div className="text-xs font-semibold uppercase tracking-wider text-slate-500">Fatture totali</div><div className="stat-num text-2xl mt-1">{items.length}</div></div>
        <div className="card-elev p-4"><div className="text-xs font-semibold uppercase tracking-wider text-slate-500">Fatturato totale</div><div className="stat-num text-2xl mt-1 text-emerald-700">{fmtEuro(total)}</div></div>
        <div className="card-elev p-4 bg-indigo-50 border-indigo-100"><div className="text-xs font-semibold uppercase tracking-wider text-indigo-700">Formato SdI</div><div className="mt-1 text-sm text-indigo-900">FatturaPA 1.2 • FPR12</div></div>
      </div>

      {items.length === 0 ? <EmptyState title="Nessuna fattura" action={<Btn onClick={openNew}><Plus className="w-4 h-4" />Nuova</Btn>} /> : (
        <div className="card-elev overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="text-left px-4 py-3">Numero</th>
                <th className="text-left px-4 py-3">Data</th>
                <th className="text-left px-4 py-3">Cliente</th>
                <th className="text-left px-4 py-3">Causale</th>
                <th className="text-right px-4 py-3">Imponibile</th>
                <th className="text-right px-4 py-3">IVA</th>
                <th className="text-right px-4 py-3">Totale</th>
                <th className="text-right px-4 py-3">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {items.map(f => (
                <tr key={f.id} className="border-t border-slate-100 hover:bg-slate-50" data-testid={`fatt-row-${f.id}`}>
                  <td className="px-4 py-3 font-mono font-semibold text-sky-700">{f.numero}</td>
                  <td className="px-4 py-3">{fmtDate(f.data_emissione)}</td>
                  <td className="px-4 py-3">{f.cliente_denominazione || sName(f.socio_id) || "—"}</td>
                  <td className="px-4 py-3 text-slate-600">{f.causale}</td>
                  <td className="px-4 py-3 text-right">{fmtEuro(f.imponibile)}</td>
                  <td className="px-4 py-3 text-right text-slate-500">{fmtEuro(f.iva)}</td>
                  <td className="px-4 py-3 text-right font-bold text-emerald-700">{fmtEuro(f.totale)}</td>
                  <td className="px-4 py-3 text-right">
                    <button data-testid={`fatt-xml-${f.id}`} onClick={()=>downloadXml(f)} className="p-2 rounded-lg hover:bg-indigo-50 text-indigo-700" title="Scarica XML SdI"><FileCode2 className="w-4 h-4" /></button>
                    <button data-testid={`fatt-edit-${f.id}`} onClick={()=>openEdit(f)} className="p-2 rounded-lg hover:bg-sky-50 text-sky-700"><Pencil className="w-4 h-4" /></button>
                    <button data-testid={`fatt-del-${f.id}`} onClick={()=>del(f)} className="p-2 rounded-lg hover:bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={modal} onClose={()=>setModal(false)} title={editing ? `Modifica fattura ${editing.numero}` : "Nuova fattura"} wide>
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Input type="date" testid="fatt-form-data" label="Data emissione *" value={form.data_emissione} onChange={(e)=>setForm({...form, data_emissione: e.target.value})} />
            <Select testid="fatt-form-tipo" label="Tipo documento" value={form.tipo_documento} onChange={(e)=>setForm({...form, tipo_documento: e.target.value})}>
              <option value="TD01">TD01 Fattura</option>
              <option value="TD04">TD04 Nota di credito</option>
              <option value="TD24">TD24 Fatt. differita</option>
            </Select>
            <Select testid="fatt-form-mp" label="Modalità pagam." value={form.modalita_pagamento} onChange={(e)=>setForm({...form, modalita_pagamento: e.target.value})}>
              <option value="MP01">MP01 Contanti</option>
              <option value="MP02">MP02 Assegno</option>
              <option value="MP05">MP05 Bonifico</option>
              <option value="MP08">MP08 Carta pagam.</option>
            </Select>
            <Select testid="fatt-form-stato" label="Stato" value={form.stato} onChange={(e)=>setForm({...form, stato: e.target.value})}>
              <option value="bozza">Bozza</option><option value="emessa">Emessa</option><option value="pagata">Pagata</option>
            </Select>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Select testid="fatt-form-socio" label="Socio (auto-compila anagrafica)" value={form.socio_id} onChange={(e)=>setForm({...form, socio_id: e.target.value})}>
              <option value="">—</option>
              {soci.map(s => <option key={s.id} value={s.id}>{s.cognome} {s.nome}</option>)}
            </Select>
            <Input testid="fatt-form-cliente" label="Denominazione cliente" value={form.cliente_denominazione} onChange={(e)=>setForm({...form, cliente_denominazione: e.target.value})} />
            <Input testid="fatt-form-cf" label="Codice Fiscale" value={form.cliente_cf} onChange={(e)=>setForm({...form, cliente_cf: e.target.value})} />
            <Input testid="fatt-form-piva" label="Partita IVA" value={form.cliente_piva} onChange={(e)=>setForm({...form, cliente_piva: e.target.value})} />
            <Input testid="fatt-form-sdi" label="Codice destinatario SdI (7 char)" value={form.cliente_codice_sdi} onChange={(e)=>setForm({...form, cliente_codice_sdi: e.target.value})} />
            <Input testid="fatt-form-pec" label="PEC destinatario" value={form.cliente_pec} onChange={(e)=>setForm({...form, cliente_pec: e.target.value})} />
          </div>
          <div>
            <Input testid="fatt-form-causale" label="Causale" value={form.causale} onChange={(e)=>setForm({...form, causale: e.target.value})} />
          </div>

          <div className="border-t border-slate-100 pt-3">
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm font-semibold text-slate-700">Righe</div>
              <button data-testid="fatt-form-add-riga" onClick={addRiga} className="text-xs text-sky-700 font-semibold">+ Aggiungi riga</button>
            </div>
            <div className="space-y-2">
              {form.righe.map((r, i) => (
                <div key={i} className="grid grid-cols-12 gap-2 items-end">
                  <div className="col-span-6"><Input testid={`fatt-riga-desc-${i}`} label={i===0?"Descrizione":""} value={r.descrizione} onChange={(e)=>setRiga(i,"descrizione",e.target.value)} /></div>
                  <div className="col-span-1"><Input testid={`fatt-riga-qta-${i}`} type="number" step="0.01" label={i===0?"Q.tà":""} value={r.quantita} onChange={(e)=>setRiga(i,"quantita",e.target.value)} /></div>
                  <div className="col-span-2"><Input testid={`fatt-riga-price-${i}`} type="number" step="0.01" label={i===0?"Prezzo":""} value={r.prezzo_unitario} onChange={(e)=>setRiga(i,"prezzo_unitario",e.target.value)} /></div>
                  <div className="col-span-2"><Input testid={`fatt-riga-iva-${i}`} type="number" step="0.5" label={i===0?"IVA %":""} value={r.aliquota_iva} onChange={(e)=>setRiga(i,"aliquota_iva",e.target.value)} /></div>
                  <div className="col-span-1">{form.righe.length > 1 && <button data-testid={`fatt-riga-del-${i}`} onClick={()=>delRiga(i)} className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>}</div>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-lg bg-slate-50 p-3 border border-slate-100 grid grid-cols-3 gap-3 text-sm">
              <div><span className="text-slate-500">Imponibile</span><div className="font-bold">{fmtEuro(preview)}</div></div>
              <div><span className="text-slate-500">IVA</span><div className="font-bold">{fmtEuro(previewIva)}</div></div>
              <div><span className="text-slate-500">Totale</span><div className="font-bold text-emerald-700">{fmtEuro(preview + previewIva)}</div></div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <Btn variant="ghost" onClick={()=>setModal(false)}>Annulla</Btn>
            <Btn testid="fatt-form-save" onClick={save}>{editing ? "Salva" : "Crea fattura"}</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}
