import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Input, Select, Btn, Modal, Badge, EmptyState, Textarea } from "./_ui";
import { toast } from "sonner";
import { Plus, Trash2, Pencil, GraduationCap, Calendar } from "lucide-react";
import { disciplines } from "../lib/utils-app";

const empty = { nome: "", disciplina: "", istruttore: "", giorno_settimana: "Lunedi", ora_inizio: "17:00", ora_fine: "18:30", luogo: "", descrizione: "", attivo: true };
const giorni = ["Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato","Domenica"];

export default function Corsi() {
  const [items, setItems] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);

  const load = async () => setItems((await api.get("/corsi")).data);
  useEffect(() => { load(); }, []);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const openNew = () => { setEditing(null); setForm(empty); setModal(true); };
  const openEdit = (c) => { setEditing(c); setForm({ ...empty, ...c }); setModal(true); };

  const save = async () => {
    if (!form.nome) { toast.error("Nome corso obbligatorio"); return; }
    if (editing) await api.put(`/corsi/${editing.id}`, form);
    else await api.post("/corsi", form);
    toast.success("Corso salvato"); setModal(false); load();
  };
  const del = async (c) => { if (!window.confirm("Eliminare corso e presenze collegate?")) return; await api.delete(`/corsi/${c.id}`); toast.success("Eliminato"); load(); };

  return (
    <div>
      <PageHeader title="Corsi & Calendario" subtitle="Programmazione corsi settimanali."
        action={<Btn testid="corsi-new-btn" onClick={openNew}><Plus className="w-4 h-4" />Nuovo corso</Btn>} />

      {items.length === 0 ? <EmptyState title="Nessun corso" action={<Btn onClick={openNew}><Plus className="w-4 h-4" />Nuovo</Btn>} /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((c) => (
            <div key={c.id} className="card-elev p-5 group hover:shadow-lg transition" data-testid={`corso-card-${c.id}`}>
              <div className="flex items-start justify-between">
                <div className="w-11 h-11 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center"><GraduationCap className="w-5 h-5" /></div>
                <div className="flex gap-1">
                  <button data-testid={`corso-edit-${c.id}`} onClick={()=>openEdit(c)} className="p-1.5 rounded-md hover:bg-sky-50 text-sky-700"><Pencil className="w-4 h-4" /></button>
                  <button data-testid={`corso-delete-${c.id}`} onClick={()=>del(c)} className="p-1.5 rounded-md hover:bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
              <h3 className="font-bold text-lg mt-3">{c.nome}</h3>
              <div className="text-sm text-slate-500">{c.disciplina}</div>
              <div className="mt-3 space-y-1 text-sm">
                <div className="flex items-center gap-2 text-slate-700"><Calendar className="w-4 h-4 text-slate-400" />{c.giorno_settimana} • {c.ora_inizio}–{c.ora_fine}</div>
                <div className="text-slate-500">📍 {c.luogo || "—"}</div>
                <div className="text-slate-500">👤 {c.istruttore || "—"}</div>
              </div>
              <div className="mt-4">{c.attivo ? <Badge tone="emerald">Attivo</Badge> : <Badge>Non attivo</Badge>}</div>
            </div>
          ))}
        </div>
      )}

      <Modal open={modal} onClose={()=>setModal(false)} title={editing ? "Modifica corso" : "Nuovo corso"}>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2"><Input testid="corso-form-nome" label="Nome *" value={form.nome} onChange={set("nome")} /></div>
          <Select testid="corso-form-disc" label="Disciplina" value={form.disciplina} onChange={set("disciplina")}>
            <option value="">—</option>{disciplines.map(d => <option key={d}>{d}</option>)}
          </Select>
          <Input testid="corso-form-istr" label="Istruttore" value={form.istruttore} onChange={set("istruttore")} />
          <Select testid="corso-form-giorno" label="Giorno" value={form.giorno_settimana} onChange={set("giorno_settimana")}>
            {giorni.map(g => <option key={g}>{g}</option>)}
          </Select>
          <Input testid="corso-form-luogo" label="Luogo" value={form.luogo} onChange={set("luogo")} />
          <Input testid="corso-form-inizio" type="time" label="Ora inizio" value={form.ora_inizio} onChange={set("ora_inizio")} />
          <Input testid="corso-form-fine" type="time" label="Ora fine" value={form.ora_fine} onChange={set("ora_fine")} />
          <div className="col-span-2"><Textarea testid="corso-form-desc" label="Descrizione" value={form.descrizione} onChange={set("descrizione")} /></div>
          <label className="col-span-2 flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" data-testid="corso-form-attivo" checked={form.attivo} onChange={set("attivo")} /> Corso attivo
          </label>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Btn variant="ghost" onClick={()=>setModal(false)}>Annulla</Btn>
          <Btn testid="corso-form-save" onClick={save}>{editing ? "Salva" : "Crea"}</Btn>
        </div>
      </Modal>
    </div>
  );
}
