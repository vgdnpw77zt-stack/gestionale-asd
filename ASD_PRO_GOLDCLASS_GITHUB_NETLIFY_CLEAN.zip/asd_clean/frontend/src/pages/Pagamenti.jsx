import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Input, Select, Btn, Modal, Badge, EmptyState } from "./_ui";
import { toast } from "sonner";
import { Plus, Trash2, Pencil, Receipt, Printer, FileDown } from "lucide-react";
import { fmtDate, fmtEuro, todayIso } from "../lib/utils-app";

const empty = { socio_id: "", numero_ricevuta: "", causale: "Quota associativa", importo: 0, metodo: "Contanti", data_pagamento: todayIso(), stagione: "2024/2025", note: "" };

export default function Pagamenti() {
  const [items, setItems] = useState([]);
  const [soci, setSoci] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);
  const [settings, setSettings] = useState(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewData, setPreviewData] = useState(null);

  const load = async () => {
    const [p, s, st] = await Promise.all([api.get("/pagamenti"), api.get("/soci"), api.get("/settings")]);
    setItems(p.data); setSoci(s.data); setSettings(st.data);
  };
  useEffect(() => { load(); }, []);

  const sName = (id) => { const s = soci.find(x => x.id === id); return s ? `${s.cognome} ${s.nome}` : "—"; };
  const total = items.reduce((a, p) => a + Number(p.importo || 0), 0);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === "number" ? Number(e.target.value) : e.target.value });

  const openNew = () => { setEditing(null); setForm({ ...empty, data_pagamento: todayIso() }); setModal(true); };
  const openEdit = (p) => { setEditing(p); setForm({ ...empty, ...p }); setModal(true); };

  const save = async () => {
    if (!form.socio_id || !form.causale || !form.importo) { toast.error("Compila socio, causale, importo"); return; }
    try {
      if (editing) await api.put(`/pagamenti/${editing.id}`, form);
      else await api.post("/pagamenti", form);
      toast.success("Pagamento registrato"); setModal(false); load();
    } catch (e) { toast.error(e?.response?.data?.detail || "Errore"); }
  };

  const del = async (p) => {
    if (!window.confirm(`Eliminare ricevuta ${p.numero_ricevuta}?`)) return;
    await api.delete(`/pagamenti/${p.id}`);
    toast.success("Eliminato"); load();
  };

  const preview = (p) => { setPreviewData(p); setPreviewOpen(true); };
  const printReceipt = () => window.print();

  const downloadPdf = async (p) => {
    try {
      const token = localStorage.getItem("asd_token");
      const res = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/pagamenti/${p.id}/pdf`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Errore PDF");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = `ricevuta_${p.numero_ricevuta}.pdf`; a.click();
      URL.revokeObjectURL(url);
      toast.success("PDF scaricato");
    } catch (e) { toast.error("Errore export PDF"); }
  };

  return (
    <div>
      <PageHeader title="Quote & Pagamenti" subtitle="Registro incassi con ricevute numerate."
        action={<Btn testid="pag-new-btn" onClick={openNew}><Plus className="w-4 h-4" />Nuova ricevuta</Btn>} />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="card-elev p-4">
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">Totale ricevute</div>
          <div className="stat-num text-2xl mt-1">{items.length}</div>
        </div>
        <div className="card-elev p-4">
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">Incassato totale</div>
          <div className="stat-num text-2xl mt-1 text-emerald-700">{fmtEuro(total)}</div>
        </div>
        <div className="card-elev p-4">
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">Media per ricevuta</div>
          <div className="stat-num text-2xl mt-1">{fmtEuro(items.length ? total / items.length : 0)}</div>
        </div>
      </div>

      {items.length === 0 ? <EmptyState title="Nessuna ricevuta" action={<Btn onClick={openNew}><Plus className="w-4 h-4" />Nuova</Btn>} /> : (
        <div className="card-elev overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="text-left px-4 py-3">N. Ricevuta</th>
                <th className="text-left px-4 py-3">Data</th>
                <th className="text-left px-4 py-3">Socio</th>
                <th className="text-left px-4 py-3">Causale</th>
                <th className="text-left px-4 py-3">Metodo</th>
                <th className="text-right px-4 py-3">Importo</th>
                <th className="text-right px-4 py-3">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {items.map((p) => (
                <tr key={p.id} className="border-t border-slate-100 hover:bg-slate-50" data-testid={`pag-row-${p.id}`}>
                  <td className="px-4 py-3 font-mono font-semibold text-sky-700">{p.numero_ricevuta}</td>
                  <td className="px-4 py-3">{fmtDate(p.data_pagamento)}</td>
                  <td className="px-4 py-3 font-semibold">{sName(p.socio_id)}</td>
                  <td className="px-4 py-3 text-slate-700">{p.causale}</td>
                  <td className="px-4 py-3"><Badge tone="indigo">{p.metodo}</Badge></td>
                  <td className="px-4 py-3 text-right font-bold text-emerald-700">{fmtEuro(p.importo)}</td>
                  <td className="px-4 py-3 text-right">
                    <button data-testid={`pag-pdf-${p.id}`} onClick={()=>downloadPdf(p)} className="p-2 rounded-lg hover:bg-emerald-50 text-emerald-700" title="Scarica PDF"><FileDown className="w-4 h-4" /></button>
                    <button data-testid={`pag-print-${p.id}`} onClick={()=>preview(p)} className="p-2 rounded-lg hover:bg-sky-50 text-sky-700" title="Anteprima"><Printer className="w-4 h-4" /></button>
                    <button data-testid={`pag-edit-${p.id}`} onClick={()=>openEdit(p)} className="p-2 rounded-lg hover:bg-sky-50 text-sky-700"><Pencil className="w-4 h-4" /></button>
                    <button data-testid={`pag-delete-${p.id}`} onClick={()=>del(p)} className="p-2 rounded-lg hover:bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={modal} onClose={()=>setModal(false)} title={editing ? "Modifica pagamento" : "Nuova ricevuta"}>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <Select testid="pag-form-socio" label="Socio *" value={form.socio_id} onChange={set("socio_id")}>
              <option value="">Seleziona…</option>
              {soci.map(s => <option key={s.id} value={s.id}>{s.cognome} {s.nome}</option>)}
            </Select>
          </div>
          <div className="col-span-2"><Input testid="pag-form-causale" label="Causale *" value={form.causale} onChange={set("causale")} /></div>
          <Input testid="pag-form-importo" type="number" step="0.01" label="Importo € *" value={form.importo} onChange={set("importo")} />
          <Select testid="pag-form-metodo" label="Metodo" value={form.metodo} onChange={set("metodo")}>
            {["Contanti","Bonifico","POS","Assegno","PayPal"].map(m => <option key={m}>{m}</option>)}
          </Select>
          <Input type="date" testid="pag-form-data" label="Data pagamento" value={form.data_pagamento} onChange={set("data_pagamento")} />
          <Input testid="pag-form-stagione" label="Stagione" value={form.stagione} onChange={set("stagione")} />
          {editing && <Input testid="pag-form-numero" label="Numero ricevuta" value={form.numero_ricevuta} onChange={set("numero_ricevuta")} />}
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Btn variant="ghost" onClick={()=>setModal(false)}>Annulla</Btn>
          <Btn testid="pag-form-save" onClick={save}>{editing ? "Salva" : "Registra"}</Btn>
        </div>
      </Modal>

      <Modal open={previewOpen} onClose={()=>setPreviewOpen(false)} title={`Ricevuta ${previewData?.numero_ricevuta || ""}`} wide>
        {previewData && settings && (
          <div className="bg-white p-8 print:p-0" id="ricevuta-print">
            <div className="flex items-start justify-between border-b pb-4 mb-4">
              <div>
                <h2 className="text-2xl font-bold">{settings.ragione_sociale}</h2>
                <div className="text-sm text-slate-600">{settings.indirizzo}, {settings.cap} {settings.citta} ({settings.provincia})</div>
                <div className="text-xs text-slate-500 mono mt-1">CF: {settings.codice_fiscale} • P.IVA: {settings.partita_iva}</div>
              </div>
              <div className="text-right">
                <div className="text-xs uppercase tracking-widest text-slate-400">Ricevuta n.</div>
                <div className="text-3xl font-extrabold text-sky-700 mono">{previewData.numero_ricevuta}</div>
                <div className="text-sm text-slate-600 mt-1">{fmtDate(previewData.data_pagamento)}</div>
              </div>
            </div>
            <div className="mb-4">
              <div className="text-xs uppercase text-slate-400 mb-1">Ricevuto da</div>
              <div className="font-semibold text-lg">{sName(previewData.socio_id)}</div>
            </div>
            <div className="mb-4">
              <div className="text-xs uppercase text-slate-400 mb-1">Causale</div>
              <div className="text-slate-800">{previewData.causale}</div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-xs uppercase text-slate-400 mb-1">Metodo</div>
                <div>{previewData.metodo}</div>
              </div>
              <div className="text-right">
                <div className="text-xs uppercase text-slate-400 mb-1">Importo</div>
                <div className="text-3xl font-extrabold text-emerald-700">{fmtEuro(previewData.importo)}</div>
              </div>
            </div>
            <div className="mt-8 pt-8 border-t text-xs text-slate-500">
              Documento non fiscale ai sensi della normativa applicabile alle ASD.
              Emesso da {settings.ragione_sociale}.
            </div>
          </div>
        )}
        <div className="mt-4 flex justify-end gap-2 print:hidden">
          <Btn variant="ghost" onClick={()=>setPreviewOpen(false)}>Chiudi</Btn>
          <Btn testid="ricevuta-print-btn" onClick={printReceipt}><Printer className="w-4 h-4" />Stampa</Btn>
        </div>
      </Modal>
    </div>
  );
}
