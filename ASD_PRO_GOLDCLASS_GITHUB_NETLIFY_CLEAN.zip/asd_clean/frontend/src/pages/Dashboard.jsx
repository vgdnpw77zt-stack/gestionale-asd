import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { fmtEuro } from "../lib/utils-app";
import { Users, Activity, Wallet, HeartPulse, TrendingUp, AlertTriangle, CircleCheck, Sparkles, FileDown, Smartphone } from "lucide-react";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, BarChart, Bar, CartesianGrid } from "recharts";
import { toast } from "sonner";

const Stat = ({ icon: Icon, label, value, sub, tone = "sky", testid }) => (
  <div className="card-elev p-5 relative overflow-hidden" data-testid={testid}>
    <div className={`absolute -right-6 -top-6 w-24 h-24 rounded-full opacity-10 bg-${tone}-500`} />
    <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
      <Icon className={`w-4 h-4 text-${tone}-600`} />
      {label}
    </div>
    <div className="stat-num text-3xl mt-2 text-slate-900">{value}</div>
    {sub && <div className="text-xs text-slate-500 mt-1">{sub}</div>}
  </div>
);

export default function Dashboard() {
  const [s, setS] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const r = await api.get("/dashboard/stats");
      setS(r.data);
    } catch { toast.error("Errore caricamento statistiche"); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const seed = async () => {
    try {
      const r = await api.post("/dev/seed");
      if (r.data.ok) toast.success(`Dati demo creati: ${r.data.soci} soci`); else toast.info(r.data.message);
      load();
    } catch { toast.error("Errore seed"); }
  };

  if (loading) return <div className="text-slate-500">Caricamento…</div>;
  if (!s) return null;

  return (
    <div>
      <div className="flex items-start justify-between mb-6 flex-wrap gap-3">
        <div>
          <div className="text-xs font-semibold uppercase tracking-widest text-sky-700">Panoramica</div>
          <h1 className="text-3xl font-extrabold tracking-tight">Dashboard</h1>
          <p className="text-slate-500 text-sm mt-1">Il quadro completo della tua ASD, aggiornato in tempo reale.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <a data-testid="dash-mobile-link" href="/mobile" target="_blank" rel="noreferrer"
            className="h-10 px-4 rounded-lg text-sm font-semibold inline-flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800">
            <Smartphone className="w-4 h-4" />Vista istruttore
          </a>
          <button data-testid="dash-report-btn" onClick={async () => {
            const token = localStorage.getItem("asd_token");
            const y = new Date().getFullYear();
            const res = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/report/annuale/pdf?anno=${y}`, { headers: { Authorization: `Bearer ${token}` } });
            if (!res.ok) { toast.error("Errore report"); return; }
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a"); a.href = url; a.download = `report_annuale_${y}.pdf`; a.click();
            URL.revokeObjectURL(url);
            toast.success("Report scaricato");
          }} className="h-10 px-4 rounded-lg text-sm font-semibold inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white">
            <FileDown className="w-4 h-4" />Report annuale PDF
          </button>
          {s.totale_soci === 0 && (
            <button data-testid="seed-demo-btn" onClick={seed}
              className="flex items-center gap-2 h-10 px-4 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold transition">
              <Sparkles className="w-4 h-4" /> Popola dati demo
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Stat icon={Users} label="Soci Totali" value={s.totale_soci} sub={`${s.soci_attivi} attivi`} tone="sky" testid="stat-soci" />
        <Stat icon={Activity} label="Corsi Attivi" value={s.corsi_attivi} sub="in programmazione" tone="indigo" testid="stat-corsi" />
        <Stat icon={Wallet} label="Incassi Mese" value={fmtEuro(s.incassi_mese)} sub={`Anno: ${fmtEuro(s.incassi_anno)}`} tone="emerald" testid="stat-incassi" />
        <Stat icon={HeartPulse} label="Certificati Scaduti" value={s.certificati_scaduti} sub={`${s.certificati_in_scadenza} in scadenza`} tone="rose" testid="stat-certificati" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <div className="card-elev p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-lg">Andamento iscrizioni</h3>
              <p className="text-xs text-slate-500">Ultimi 12 mesi</p>
            </div>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="h-64">
            <ResponsiveContainer>
              <LineChart data={s.andamento_iscrizioni}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="mese" stroke="#94A3B8" fontSize={11} />
                <YAxis stroke="#94A3B8" fontSize={11} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid #E2E8F0" }} />
                <Line type="monotone" dataKey="iscritti" stroke="#0284C7" strokeWidth={2.5} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="card-elev p-5">
          <h3 className="font-bold text-lg mb-2">Certificati Medici</h3>
          <p className="text-xs text-slate-500 mb-4">Stato attuale</p>
          <div className="space-y-3">
            <Row label="Validi" value={s.certificati_validi} color="emerald" icon={CircleCheck} />
            <Row label="In scadenza (≤30gg)" value={s.certificati_in_scadenza} color="amber" icon={AlertTriangle} />
            <Row label="Scaduti" value={s.certificati_scaduti} color="rose" icon={AlertTriangle} />
          </div>
        </div>
      </div>

      <div className="card-elev p-5">
        <h3 className="font-bold text-lg mb-4">Soci per disciplina</h3>
        <div className="h-64">
          <ResponsiveContainer>
            <BarChart data={s.per_disciplina}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="disciplina" stroke="#94A3B8" fontSize={11} />
              <YAxis stroke="#94A3B8" fontSize={11} allowDecimals={false} />
              <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid #E2E8F0" }} />
              <Bar dataKey="count" fill="#6366F1" radius={[6,6,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

const Row = ({ label, value, color, icon: Icon }) => (
  <div className={`flex items-center justify-between p-3 rounded-lg bg-${color}-50 border border-${color}-100`}>
    <div className={`flex items-center gap-2 text-${color}-700 text-sm font-medium`}>
      <Icon className="w-4 h-4" />
      {label}
    </div>
    <div className={`text-lg font-bold text-${color}-700`}>{value}</div>
  </div>
);
