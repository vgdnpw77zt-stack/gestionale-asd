// ASD Master — Service Worker minimale (cache-first per shell, network-first per API)
const CACHE = "asd-master-v1";
const SHELL = ["/", "/index.html", "/manifest.json", "/favicon.ico"];

self.addEventListener("install", (e) => {
  self.skipWaiting();
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL).catch(()=>{})));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  // Non intercettare API né richieste non-GET
  if (e.request.method !== "GET") return;
  if (url.pathname.startsWith("/api/")) return;
  // Cache-first per stessa origin, network-first altrimenti
  if (url.origin === self.location.origin) {
    e.respondWith(
      caches.match(e.request).then((r) => r || fetch(e.request).then((res) => {
        const clone = res.clone();
        caches.open(CACHE).then((c) => c.put(e.request, clone)).catch(()=>{});
        return res;
      }).catch(() => caches.match("/index.html")))
    );
  }
});
