# ASD Pro Goldclass — GitHub + Netlify

This repository is cleaned for source control and Netlify deployment.

## Removed from the repository
- node_modules and npm/yarn caches
- Python caches and bytecode
- Git metadata
- local .env secrets
- large development artifact `z`
- local test reports/credentials

## Netlify
Netlify uses the root `netlify.toml`, builds `frontend`, and publishes `frontend/build`.
Set the Netlify environment variable `REACT_APP_BACKEND_URL` to the public URL of the deployed FastAPI backend.

The React app uses BrowserRouter; the Netlify redirect keeps direct routes from returning 404.

## Important
Netlify hosts the React frontend only. The FastAPI/MongoDB backend must be deployed separately and its public URL supplied as `REACT_APP_BACKEND_URL`.
