# ASD Pro Goldclass — Netlify Ready

Questa cartella è già la **root del sito**: `index.html` è al livello principale.

## Deploy manuale Netlify

Caricare su Netlify **il contenuto di questa cartella** oppure l'archivio ZIP senza aggiungere una cartella contenitore sopra di essa.

Struttura prevista:

- `index.html`
- `netlify.toml`
- `.nojekyll`
- `assets/`

Il progetto è una web app statica client-side. I dati demo/locali vengono gestiti dal browser tramite `localStorage`; non contiene il backend Flask/SQLite della versione desktop.
