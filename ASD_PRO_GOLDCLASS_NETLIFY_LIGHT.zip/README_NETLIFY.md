# ASD Pro Goldclass — Netlify Ready (Light)

Questa è una build web statica volutamente minimale.

- `index.html` è direttamente nella root.
- Nessuna cartella `node_modules`.
- Nessun backend Python/FastAPI.
- Nessun MongoDB/Stripe/AI.
- Nessun React/build tool necessario per il deploy.
- Dati operativi salvati nel browser tramite localStorage.
- Backup/ripristino JSON locale.
- Routing tramite hash + `_redirects`, quindi niente 404 sulle sezioni.

Per Netlify: caricare questa cartella oppure il suo ZIP. Il publish directory è `.`.
