# Licenze ASD Pro Goldclass

Questa cartella è **solo sviluppatore**.
Non deve essere inclusa nella build cliente, nel DMG o nell'EXE.

## Generazione GUI
macOS:

```bash
SVILUPPATORE/MAC/GENERA_LICENZA.command
```

macOS:

```bat
SVILUPPATORE/MAC/GENERA_LICENZA.command
```

## Output corretto
Il file generato deve chiamarsi `license.json` e va installato nel runtime cliente:

- macOS: `~/Library/Application Support/ASD Pro Goldclass/license.json`
- macOS: `~/Library/Application Support/ASD Pro Goldclass/license.json`

Non copiarlo dentro `SVILUPPATORE/APP`, non metterlo nel DMG, non inserirlo nell'EXE.

## Bypass sviluppatore
Il bypass resta in `OWNER_DEV_LICENSE_KIT` ed è solo tuo. Deve restare fuori dal pacchetto commerciale.
