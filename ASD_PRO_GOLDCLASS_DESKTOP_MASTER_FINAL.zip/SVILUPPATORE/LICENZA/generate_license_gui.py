#!/usr/bin/env python3
"""
Generatore licenze ASD Pro Goldclass - SOLO SVILUPPATORE.
Non includere questo file nella build cliente / DMG.
Genera un license.json firmato per l'installazione locale:
- macOS: ~/Library/Application Support/ASD Pro Goldclass/license.json
- macOS: ~/Library/Application Support/ASD Pro Goldclass/license.json
"""
from __future__ import annotations

import sys
import tkinter as tk
from datetime import date, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

# Lo script viene lanciato da SVILUPPATORE/MAC o WINDOWS con PYTHONPATH già puntato ad APP.
# Questo fallback rende il file robusto anche se avviato a mano da Finder/Terminale.
THIS_FILE = Path(__file__).resolve()
APP_DIR = THIS_FILE.parents[1] / "APP"
if APP_DIR.exists() and str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

try:
    from asd_app.license_manager import save_license, validate_license_file, current_device_fingerprint
except Exception as exc:  # pragma: no cover - errore mostrato graficamente
    raise SystemExit(f"Impossibile importare asd_app.license_manager da {APP_DIR}: {exc}")


FEATURE_PRESETS = [
    "all",
    "tesserati",
    "pagamenti",
    "documenti",
    "promemoria",
    "collaboratori",
    "danza_aerea",
    "backup",
]


def default_output_path() -> Path:
    desktop = Path.home() / "Desktop"
    return desktop / "license.json" if desktop.exists() else Path.cwd() / "license.json"


class LicenseGenerator(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("ASD Pro Goldclass - Generatore Licenza")
        self.geometry("720x560")
        self.minsize(680, 520)

        self.cliente = tk.StringVar()
        self.codice = tk.StringVar()
        self.scadenza = tk.StringVar(value=(date.today() + timedelta(days=365)).isoformat())
        self.max_utenti = tk.StringVar(value="3")
        self.piano = tk.StringVar(value="standard")
        self.device_id = tk.StringVar(value="")
        self.output = tk.StringVar(value=str(default_output_path()))
        self.feature_vars: dict[str, tk.BooleanVar] = {f: tk.BooleanVar(value=(f == "all")) for f in FEATURE_PRESETS}

        self._build_ui()

    def _build_ui(self) -> None:
        root = ttk.Frame(self, padding=18)
        root.pack(fill="both", expand=True)

        title = ttk.Label(root, text="Generatore licenza cliente", font=("Helvetica", 18, "bold"))
        title.pack(anchor="w", pady=(0, 8))

        subtitle = ttk.Label(
            root,
            text="Crea un license.json firmato. Non inserirlo nel DMG/EXE: va copiato nel runtime del cliente.",
            wraplength=660,
        )
        subtitle.pack(anchor="w", pady=(0, 14))

        form = ttk.Frame(root)
        form.pack(fill="x")

        self._row(form, "Cliente / ASD", self.cliente, 0, "Es. Bodymind Aerial Studio A.S.D.")
        self._row(form, "Codice cliente", self.codice, 1, "Es. BODYMIND-2026-001")
        self._row(form, "Scadenza", self.scadenza, 2, "YYYY-MM-DD")
        self._row(form, "Max utenti", self.max_utenti, 3, "Es. 3")

        ttk.Label(form, text="Piano").grid(row=4, column=0, sticky="w", pady=6)
        piano = ttk.Combobox(form, textvariable=self.piano, values=["standard", "pro", "enterprise", "developer"], state="readonly")
        piano.grid(row=4, column=1, sticky="ew", pady=6)
        self._row(form, "Device ID", self.device_id, 5, "Vuoto = licenza non legata al dispositivo; * = universale")
        ttk.Button(form, text="Usa ID di questo Mac/PC", command=lambda: self.device_id.set(current_device_fingerprint())).grid(row=5, column=3, sticky="w", padx=(8, 0))

        form.columnconfigure(1, weight=1)

        features_box = ttk.LabelFrame(root, text="Funzioni abilitate", padding=10)
        features_box.pack(fill="x", pady=14)
        for idx, feature in enumerate(FEATURE_PRESETS):
            ttk.Checkbutton(features_box, text=feature, variable=self.feature_vars[feature]).grid(
                row=idx // 4, column=idx % 4, sticky="w", padx=8, pady=4
            )

        out_frame = ttk.LabelFrame(root, text="Destinazione file licenza", padding=10)
        out_frame.pack(fill="x", pady=(0, 12))
        ttk.Entry(out_frame, textvariable=self.output).pack(side="left", fill="x", expand=True)
        ttk.Button(out_frame, text="Scegli…", command=self.choose_output).pack(side="left", padx=(8, 0))

        buttons = ttk.Frame(root)
        buttons.pack(fill="x", pady=8)
        ttk.Button(buttons, text="Genera license.json", command=self.generate).pack(side="right")
        ttk.Button(buttons, text="Verifica licenza esistente", command=self.verify_existing).pack(side="right", padx=(0, 8))

        note = ttk.Label(
            root,
            text=(
                "Installazione cliente:\n"
                "macOS → ~/Library/Application Support/ASD Pro Goldclass/license.json\n"
                ""
                "La licenza sviluppo/bypass resta solo nello spazio sviluppatore e non deve entrare nella build commerciale."
            ),
            wraplength=660,
            justify="left",
        )
        note.pack(anchor="w", pady=(12, 0))

    def _row(self, parent: ttk.Frame, label: str, variable: tk.StringVar, row: int, placeholder: str) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=6)
        entry = ttk.Entry(parent, textvariable=variable)
        entry.grid(row=row, column=1, sticky="ew", pady=6)
        ttk.Label(parent, text=placeholder, foreground="#666").grid(row=row, column=2, sticky="w", padx=(8, 0))

    def choose_output(self) -> None:
        selected = filedialog.asksaveasfilename(
            title="Salva licenza cliente",
            defaultextension=".json",
            initialfile="license.json",
            filetypes=[("JSON", "*.json"), ("Tutti i file", "*.*")],
        )
        if selected:
            self.output.set(selected)

    def _collect_data(self) -> dict:
        try:
            max_users = int(self.max_utenti.get().strip())
        except ValueError as exc:
            raise ValueError("Max utenti deve essere un numero intero") from exc
        if max_users < 1:
            raise ValueError("Max utenti deve essere almeno 1")

        data = {
            "cliente": self.cliente.get().strip(),
            "codice_cliente": self.codice.get().strip().upper(),
            "scadenza": self.scadenza.get().strip(),
            "max_utenti": max_users,
            "piano": self.piano.get().strip().lower(),
            "features": [f for f, v in self.feature_vars.items() if v.get()],
            "device_id": self.device_id.get().strip(),
        }
        if not data["cliente"]:
            raise ValueError("Campo Cliente / ASD obbligatorio")
        if not data["codice_cliente"]:
            raise ValueError("Campo Codice cliente obbligatorio")
        # validate_license_file farà anche il parsing data dopo il salvataggio, ma qui diamo errore immediato più chiaro.
        parts = data["scadenza"].split("-")
        if len(parts) != 3 or not all(p.isdigit() for p in parts):
            raise ValueError("Scadenza non valida: usare formato YYYY-MM-DD")
        return data

    def generate(self) -> None:
        try:
            data = self._collect_data()
            out = Path(self.output.get()).expanduser().resolve()
            out.parent.mkdir(parents=True, exist_ok=True)
            save_license(data, out)
            ok, detail = validate_license_file(out)
            if not ok:
                raise RuntimeError(f"Licenza generata ma non valida: {detail}")
            messagebox.showinfo("Licenza creata", f"Licenza creata e verificata:\n{out}")
        except Exception as exc:
            messagebox.showerror("Errore", str(exc))

    def verify_existing(self) -> None:
        selected = filedialog.askopenfilename(
            title="Seleziona license.json",
            filetypes=[("JSON", "*.json"), ("Tutti i file", "*.*")],
        )
        if not selected:
            return
        ok, detail = validate_license_file(selected)
        if ok:
            messagebox.showinfo("Licenza valida", f"Licenza valida:\n{detail}")
        else:
            messagebox.showerror("Licenza non valida", str(detail))


def main() -> int:
    app = LicenseGenerator()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
