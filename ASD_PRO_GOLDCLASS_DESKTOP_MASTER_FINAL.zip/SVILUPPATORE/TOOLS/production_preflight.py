#!/usr/bin/env python3
"""Preflight produzione: fallisce se il pacchetto contiene dati runtime o configurazioni pericolose."""
from __future__ import annotations
import os, re, sys, zipfile
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent / "APP"
TOOLS_DIR = Path(__file__).resolve().parent
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))
FORBIDDEN_NAMES = {'.developer_bypass', '.secret_key', 'license.json', 'license_dev.json', 'asd.db'}
FORBIDDEN_DIRS = {'.venv', '.venv-win', 'dist', 'build', 'logs', 'pdf', 'backups', '__pycache__'}
FORBIDDEN_TOP_DIRS = {'tenants'}
errors: list[str] = []

for p in APP_DIR.rglob('*'):
    rel_path = p.relative_to(APP_DIR)
    # Gli ambienti virtuali sono strumenti locali di sviluppo e non fanno parte
    # del prodotto. Vengono comunque esclusi dalla build dai relativi script.
    if any(part in {'.venv', '.venv-win'} for part in rel_path.parts):
        continue
    rel = rel_path.as_posix()
    parts = set(p.parts)
    if p.is_dir() and p.name in FORBIDDEN_DIRS and p.name not in {'.venv', '.venv-win'}:
        errors.append(f'Directory vietata in APP: {rel}')
    elif p.is_dir() and (p.parent == APP_DIR and p.name in FORBIDDEN_TOP_DIRS):
        errors.append(f'Directory vietata in APP: {rel}')
    if p.is_file():
        if p.name in FORBIDDEN_NAMES:
            errors.append(f'File runtime/licenza vietato in APP: {rel}')
        if any(part in (FORBIDDEN_DIRS - {'.venv', '.venv-win'}) for part in p.relative_to(APP_DIR).parts):
            errors.append(f'File dentro directory vietata: {rel}')
        if p.suffix == '.pyc':
            errors.append(f'Bytecode non distribuibile nel sorgente: {rel}')
        if p.suffix == '.spec':
            txt = p.read_text(encoding='utf-8', errors='ignore')
            for forbidden in ['"tenants"', '"pdf"', '"logs"', '"backups"', '"asd.db"', '"license.json"', '".developer_bypass"']:
                if forbidden in txt and 'FORBIDDEN_OK' not in txt:
                    errors.append(f'Spec contiene riferimento vietato {forbidden}: {rel}')

# Import controllato app: verifica rotte essenziali e creazione runtime in cartella temporanea.
os.environ.setdefault('ASD_PRO_DATA_DIR', str(APP_DIR / '_preflight_runtime_tmp'))
try:
    import app as app_module
    flask_app = app_module.app
    routes = {str(r.rule) for r in flask_app.url_map.iter_rules()}
    for route in ['/dashboard', '/giornata-operativa', '/backup', '/licenza']:
        if route not in routes:
            errors.append(f'Rotta obbligatoria mancante: {route}')
except Exception as exc:
    errors.append(f'Import app fallito: {exc}')

# Pulizia runtime temporaneo
import shutil
shutil.rmtree(APP_DIR / '_preflight_runtime_tmp', ignore_errors=True)

if errors:
    print('PREFLIGHT PRODUZIONE FALLITO')
    for e in errors:
        print(' -', e)
    sys.exit(1)
print('PREFLIGHT PRODUZIONE OK')
