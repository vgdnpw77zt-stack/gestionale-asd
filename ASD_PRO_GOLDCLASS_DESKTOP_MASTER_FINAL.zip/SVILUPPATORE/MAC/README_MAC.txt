ASD PRO GOLDCLASS — MAC

USO
1) Dalla cartella principale: AVVIO_SENZA_PRIVILEGI.command
2) Oppure direttamente: SVILUPPATORE/MAC/INSTALLA_E_AVVIA.command

BUILD
BUILD_MAC_APP.command crea la .app.
BUILD_MAC_DMG.command crea il DMG.

DATI
I dati restano in ~/Library/Application Support/ASD Pro Goldclass

COMUNICAZIONI
Mail e WhatsApp vengono aperti tramite le app locali del Mac. Nessun SMTP o provider API è richiesto.
