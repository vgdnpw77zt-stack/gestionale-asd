#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$(cd "$SCRIPT_DIR/../APP" && pwd)"
cd "$APP_DIR"

xattr -cr "$APP_DIR" 2>/dev/null || true
chmod -R u+rwX "$APP_DIR" 2>/dev/null || true

if [ -x "/Library/Frameworks/Python.framework/Versions/3.11/bin/python3" ]; then
  PYTHON_BIN="/Library/Frameworks/Python.framework/Versions/3.11/bin/python3"
elif command -v python3 >/dev/null 2>&1; then
  PYTHON_BIN="$(command -v python3)"
else
  echo "ERRORE: Python 3 non trovato."
  exit 1
fi

VENV_PY="$APP_DIR/.venv/bin/python"
CREATED_VENV=0
if [ ! -d ".venv" ] || [ ! -x "$VENV_PY" ]; then
  echo "Creo ambiente virtuale Python..."
  rm -rf .venv
  "$PYTHON_BIN" -m venv .venv
  CREATED_VENV=1
fi

if [ "$CREATED_VENV" -eq 1 ] || [ ! -f ".venv/.deps_ready" ]; then
  echo "Preparo le dipendenze (prima installazione)..."
  "$VENV_PY" -m ensurepip --upgrade >/dev/null 2>&1 || true
  "$VENV_PY" -m pip install --upgrade pip setuptools wheel
  "$VENV_PY" -m pip install -r requirements.txt
  touch ".venv/.deps_ready"
else
  echo "Ambiente Python già pronto."
fi
