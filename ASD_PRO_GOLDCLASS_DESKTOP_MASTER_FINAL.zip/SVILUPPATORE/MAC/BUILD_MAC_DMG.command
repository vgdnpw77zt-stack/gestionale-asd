#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$SCRIPT_DIR/../APP"
cd "$APP_DIR"

find_app(){
  if [ -d "dist/ASD Pro Goldclass.app" ]; then echo "dist/ASD Pro Goldclass.app"; return 0; fi
  if ls dist/*.app >/dev/null 2>&1; then ls -d dist/*.app | head -n 1; return 0; fi
  return 1
}

APP_BUNDLE="$(find_app || true)"
if [ -z "$APP_BUNDLE" ]; then
  echo "Nessuna .app trovata. Avvio automaticamente la build Mac..."
  "$SCRIPT_DIR/BUILD_MAC_APP.command"
  APP_BUNDLE="$(find_app || true)"
fi

if [ -z "$APP_BUNDLE" ]; then
  echo "ERRORE: nessuna .app trovata. Il DMG non può essere creato."
  echo "Contenuto dist:"
  ls -la dist || true
  read -p "Premi INVIO per chiudere..."
  exit 1
fi

APP_NAME="$(basename "$APP_BUNDLE")"
APP_LABEL="${APP_NAME%.app}"
DMG_NAME="${APP_LABEL// /_}_macOS.dmg"
DMG_PATH="$APP_DIR/dist/$DMG_NAME"
STAGE_DIR="$APP_DIR/.dmg_stage"

rm -f "$DMG_PATH"
rm -rf "$STAGE_DIR"
mkdir -p "$STAGE_DIR"
cp -R "$APP_BUNDLE" "$STAGE_DIR/$APP_NAME"
ln -s /Applications "$STAGE_DIR/Applications"
hdiutil create -volname "$APP_LABEL" -srcfolder "$STAGE_DIR" -ov -format UDZO "$DMG_PATH"
rm -rf "$STAGE_DIR"

echo "DMG creato: $DMG_PATH"
read -p "Premi INVIO per chiudere..."
