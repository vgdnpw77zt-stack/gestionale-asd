#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$(cd "$SCRIPT_DIR/../APP" && pwd)"
cd "$APP_DIR"
chmod +x "$SCRIPT_DIR/ensure_mac_venv.sh" 2>/dev/null || true
"$SCRIPT_DIR/ensure_mac_venv.sh"
echo "Avvio ASD Pro Goldclass..."
exec "$APP_DIR/.venv/bin/python" desktop_webview.py
