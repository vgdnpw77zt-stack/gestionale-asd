#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$SCRIPT_DIR/../APP"
cd "$APP_DIR"
read -p "Nome app cliente (es. Bodymind Aerial Studio): " APP_NAME
if [ -z "$APP_NAME" ]; then APP_NAME="Asd Pro System"; fi
APP_NAME="$APP_NAME" python3 - <<'PYINNER'
from pathlib import Path
import os, re, json
name=os.environ.get('APP_NAME','Asd Pro System')
for spec_name in ['AsdProSystemDesktop.spec']:
    p=Path(spec_name)
    if not p.exists(): continue
    txt=p.read_text(encoding='utf-8')
    txt=re.sub(r"name='[^']+'", f"name='{name}'", txt, count=1)
    txt=re.sub(r"name='[^']+\.app'", f"name='{name}.app'", txt)
    p.write_text(txt,encoding='utf-8')
cfg_path=Path('config.json')
cfg={}
if cfg_path.exists():
    try: cfg=json.loads(cfg_path.read_text(encoding='utf-8'))
    except Exception: cfg={}
branding=cfg.get('branding') if isinstance(cfg.get('branding'),dict) else {}
branding['app_name']=name
branding['suite_label']=name
cfg['branding']=branding
cfg['nome_asd']=cfg.get('nome_asd') or name
cfg_path.write_text(json.dumps(cfg,indent=4,ensure_ascii=False),encoding='utf-8')
print('Personalizzazione completata:', name)
PYINNER
read -p "Premi INVIO per chiudere..."
