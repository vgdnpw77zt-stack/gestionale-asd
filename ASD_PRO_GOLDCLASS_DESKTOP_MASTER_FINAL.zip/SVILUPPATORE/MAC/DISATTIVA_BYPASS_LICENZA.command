#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$SCRIPT_DIR/../APP"
OWNER_DIR="$SCRIPT_DIR/../OWNER_DEV_LICENSE_KIT"
rm -f "$APP_DIR/.developer_bypass"
rm -f "$OWNER_DIR/.developer_bypass"
echo "Bypass licenza sviluppatore disattivato in APP e OWNER_DEV_LICENSE_KIT."
read -p "Premi INVIO per chiudere..."
