#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$SCRIPT_DIR/../APP"
cd "$APP_DIR"
SRC=""
if [ -f "static/app_icon.png" ]; then SRC="static/app_icon.png"; elif [ -f "app_icon.png" ]; then SRC="app_icon.png"; elif [ -f "static/logo.png" ]; then SRC="static/logo.png"; else echo "Metti il logo in APP/static/app_icon.png"; read -p "Premi INVIO..."; exit 1; fi
mkdir -p static
rm -rf app_icon.iconset
mkdir app_icon.iconset
sips -z 16 16 "$SRC" --out app_icon.iconset/icon_16x16.png >/dev/null
sips -z 32 32 "$SRC" --out app_icon.iconset/icon_16x16@2x.png >/dev/null
sips -z 32 32 "$SRC" --out app_icon.iconset/icon_32x32.png >/dev/null
sips -z 64 64 "$SRC" --out app_icon.iconset/icon_32x32@2x.png >/dev/null
sips -z 128 128 "$SRC" --out app_icon.iconset/icon_128x128.png >/dev/null
sips -z 256 256 "$SRC" --out app_icon.iconset/icon_128x128@2x.png >/dev/null
sips -z 256 256 "$SRC" --out app_icon.iconset/icon_256x256.png >/dev/null
sips -z 512 512 "$SRC" --out app_icon.iconset/icon_256x256@2x.png >/dev/null
sips -z 512 512 "$SRC" --out app_icon.iconset/icon_512x512.png >/dev/null
sips -z 1024 1024 "$SRC" --out app_icon.iconset/icon_512x512@2x.png >/dev/null
iconutil -c icns app_icon.iconset -o static/app_icon.icns
rm -rf app_icon.iconset
echo "Icona creata: APP/static/app_icon.icns"
read -p "Premi INVIO per chiudere..."
