#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$SCRIPT_DIR/../APP"
LICENZA_DIR="$SCRIPT_DIR/../LICENZA"
LICENZA_GUI="$LICENZA_DIR/generate_license_gui.py"

if [ ! -f "$LICENZA_GUI" ]; then
  echo "ERRORE: generatore licenza non trovato: $LICENZA_GUI"
  read -p "Premi INVIO per chiudere..."
  exit 1
fi

cd "$APP_DIR"
chmod +x "$SCRIPT_DIR/ensure_mac_venv.sh"
"$SCRIPT_DIR/ensure_mac_venv.sh"

# Necessario: generate_license_gui.py vive in SVILUPPATORE/LICENZA,
# ma importa il pacchetto asd_app che vive in SVILUPPATORE/APP.
export PYTHONPATH="$APP_DIR${PYTHONPATH:+:$PYTHONPATH}"
"$APP_DIR/.venv/bin/python" "$LICENZA_GUI"
read -p "Premi INVIO per chiudere..."
