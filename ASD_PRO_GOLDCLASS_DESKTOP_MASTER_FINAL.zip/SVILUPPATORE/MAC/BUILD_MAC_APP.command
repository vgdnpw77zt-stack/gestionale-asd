#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$SCRIPT_DIR/../APP"
cd "$APP_DIR"
find . -type d -name "__pycache__" -prune -exec rm -rf {} +
find . -name "*.pyc" -delete

chmod +x "$SCRIPT_DIR/ensure_mac_venv.sh"
"$SCRIPT_DIR/ensure_mac_venv.sh"
VENV_PY="$APP_DIR/.venv/bin/python"

# Non aggiornare PyInstaller a versioni casuali: usa esattamente requirements.txt.
"$VENV_PY" -m pip install --upgrade pip setuptools wheel
"$VENV_PY" -m pip install -r requirements.txt
"$VENV_PY" "$SCRIPT_DIR/../TOOLS/production_preflight.py"

rm -rf build dist __pycache__
# Igiene build cliente: niente runtime, dati, licenze o bypass dentro APP/bundle.
rm -f asd.db license.json license_dev.json .secret_key .developer_bypass
rm -rf tenants pdf logs backups
find . -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
find . -name '*.pyc' -delete 2>/dev/null || true
xattr -cr . 2>/dev/null || true

SPEC_FILE="AsdProSystemDesktop.spec"
if [ ! -f "$SPEC_FILE" ]; then
  echo "ERRORE: manca $SPEC_FILE in APP."
  read -p "Premi INVIO per chiudere..."
  exit 1
fi

"$VENV_PY" -m PyInstaller "$SPEC_FILE" --noconfirm --clean

APP_PATH=""
if [ -d "dist/ASD Pro Goldclass.app" ]; then
  APP_PATH="dist/ASD Pro Goldclass.app"
elif ls dist/*.app >/dev/null 2>&1; then
  APP_PATH="$(ls -d dist/*.app | head -n 1)"
fi

if [ -z "$APP_PATH" ]; then
  echo "ERRORE: nessuna .app trovata in dist/."
  echo "Contenuto dist:"
  ls -la dist || true
  read -p "Premi INVIO per chiudere..."
  exit 1
fi

xattr -cr "$APP_PATH" 2>/dev/null || true
echo "APP creata in: $APP_DIR/$APP_PATH"
read -p "Premi INVIO per chiudere..."
