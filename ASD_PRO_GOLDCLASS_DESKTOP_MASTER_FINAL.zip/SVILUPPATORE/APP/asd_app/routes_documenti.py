from io import BytesIO

from .core import *
from flask import abort
import mimetypes
from .docx_engine import build_placeholder_map, compile_docx
from .pdf_templates import build_iscrizione_pdf


def get_tesserato_or_404(cursor, tesserato_id: int):
   # Restituisce sempre anche i dati del genitore/tutore collegati al minore,
   # così i DOCX vengono compilati con dati tesserato + dati ASD + dati tutore.
   return cursor.execute("""
       SELECT
           t.*,
           m.genitore AS genitore,
           m.telefono_genitore AS telefono_genitore,
           m.email_genitore AS email_genitore,
           m.consenso_firmato AS consenso_firmato,
           m.data_consenso AS data_consenso,
           m.note_consenso AS note_consenso
       FROM tesserati t
       LEFT JOIN minori m ON m.tesserato_id = t.id
       WHERE t.id=?
   """, (tesserato_id,)).fetchone()


def _template_select_options(selected_filename: str = "") -> str:
   options = []
   for item in list_template_library_files():
       sel = " selected" if item["filename"] == selected_filename else ""
       options.append(f"<option value='{e(item['filename'])}'{sel}>{e(item['label'])}</option>")
   return "".join(options)


def _tesserato_select_options(rows, selected_id: int = 0) -> str:
   options = []
   for r in rows:
       sel = " selected" if int(r["id"]) == int(selected_id or 0) else ""
       is_minor, badges, needs_alert = _minor_document_state(dict(r))
       suffix = " · minore" if is_minor else ""
       options.append(f"<option value='{r['id']}'{sel}>{e(r['nome'])} {e(r['cognome'])}{suffix}</option>")
   return "".join(options)



def _minor_document_state(row: dict) -> tuple[bool, str, bool]:
   is_minor, age = get_minor_status_from_birthdate(row.get("data_nascita") or "")
   if not is_minor:
       return False, "", False
   has_parent = bool((row.get("genitore") or "").strip())
   has_contact = bool((row.get("telefono_genitore") or "").strip() or (row.get("email_genitore") or "").strip())
   consent_ok = int(row.get("consenso_firmato") or 0) == 1
   badges = ["<span class='pill'>Minore</span>"]
   if age is not None:
       badges.append(f"<span class='pill'>{age} anni</span>")
   if has_parent and has_contact and consent_ok:
       badges.append("<span class='badge valido'>Tutela ok</span>")
       return True, " ".join(badges), False
   if not has_parent:
       badges.append("<span class='badge in_scadenza'>Serve genitore</span>")
   elif not has_contact:
       badges.append("<span class='badge in_scadenza'>Manca recapito</span>")
   elif not consent_ok:
       badges.append("<span class='badge in_scadenza'>Consenso da registrare</span>")
   return True, " ".join(badges), True

def _asd_folder_options(selected_folder: str = "") -> str:
   options = ["<option value=''>Archivio ASD principale</option>"]
   base = get_asd_media_dir()
   for path in sorted(base.iterdir(), key=lambda p: p.name.lower()):
       if path.is_dir() and not path.name.startswith('.'):
           rel = path.relative_to(base).as_posix()
           sel = " selected" if rel == selected_folder else ""
           options.append(f"<option value='{e(rel)}'{sel}>{e(rel.replace('_', ' '))}</option>")
   return "".join(options)


def _asd_document_rows() -> list[dict]:
   rows = []
   asd_dir = get_asd_media_dir()
   for path in sorted(asd_dir.rglob('*'), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True):
       if not path.is_file():
           continue
       if path.name.startswith(".") or path.name.startswith("~$"):
           continue
       rel = path.relative_to(asd_dir).as_posix()
       folder = path.parent.relative_to(asd_dir).as_posix() if path.parent != asd_dir else ""
       rows.append({
           "filename": rel,
           "original_filename": path.name,
           "folder": folder,
           "size_kb": max(1, int(round(path.stat().st_size / 1024))),
           "updated_at": datetime.fromtimestamp(path.stat().st_mtime).strftime("%d/%m/%Y"),
           "relative_path": secure_relative_media_path("documenti_asd", rel),
       })
   return rows


def _save_uploaded_asd_document(file_storage, folder_name: str = "") -> tuple[str, str]:
   if not file_storage or not file_storage.filename:
       raise ValueError("Seleziona un file da caricare.")
   if not allowed_document(file_storage.filename):
       raise ValueError("Formato documento non supportato.")
   original = secure_filename(file_storage.filename)
   ext = original.rsplit(".", 1)[1].lower()
   folder_clean = sanitize_folder_name(folder_name, "") if folder_name else ""
   save_dir = get_asd_named_folder(folder_clean) if folder_clean else get_asd_media_dir()
   safe_name = make_unique_storage_name(save_dir, original, fallback_stem="documento_asd", preferred_ext=f'.{ext}')
   save_path = save_dir / safe_name
   file_storage.save(save_path)
   relative = secure_relative_media_path("documenti_asd", folder_clean, safe_name)
   return relative, original


def _compile_template_to_tesserato(template_filename: str, tesserato_row, cfg: dict) -> tuple[str, str, str]:
   src = get_template_library_path(template_filename)
   template_root = get_template_library_dir().resolve()
   if template_root not in src.parents or not src.exists():
       raise ValueError("Modello ASD non trovato.")
   if src.suffix.lower() != ".docx":
       raise ValueError("La compilazione automatica è disponibile solo per modelli DOCX.")

   tesserato_id = int(tesserato_row["id"])
   dest_dir = get_tesserato_media_dir(tesserato_id)
   dest_name = make_unique_storage_name(dest_dir, f"{src.stem}_compilato.docx", fallback_stem="documento_compilato", preferred_ext=".docx")
   dest_path = dest_dir / dest_name

   pkg = get_package_summary(db().cursor(), int(tesserato_row["id"]))
   enriched = dict(tesserato_row)
   enriched.update({
       "pacchetto_tipo": pkg["tipo"],
       "ingressi_totali": pkg["ingressi_totali"],
       "ingressi_residui": pkg["ingressi_residui"],
       "pacchetto_scadenza": pkg["scadenza"],
       "pacchetto_data_acquisto": pkg["data_acquisto"],
       "pacchetto_note": pkg["note"],
       "pacchetto_certificato_richiesto": pkg["certificato_richiesto"],
   })
   mapping = build_placeholder_map(cfg, enriched)
   compile_docx(src, dest_path, mapping)
   if not dest_path.exists():
       raise ValueError("Il file DOCX compilato non è stato creato correttamente.")

   relative = str(Path("tesserati") / str(tesserato_id) / dest_name).replace("\\", "/")
   label = DOCUMENT_TEMPLATE_LABELS.get(src.name, src.stem.replace("_", " "))
   titolo = f"{label} compilato"
   original_filename = dest_name
   return relative, original_filename, titolo


def _send_document_email(cfg: dict, recipient: str, subject: str, body: str, doc_row) -> None:
   """Prepara il messaggio nel client email locale."""
   if str((cfg.get("mail") or {}).get("enabled", "0")) != "1":
       raise ValueError("Invio email disattivato. Attivalo in Impostazioni > Comunicazioni.")
   path = document_abs_path(doc_row["filename"])
   if not path.exists(): raise ValueError("Il file da inviare non esiste sul disco.")
   import webbrowser
   webbrowser.open(f"mailto:{quote(recipient, safe='@._-+')}?subject={quote(subject, safe='')}&body={quote(body + chr(10) + chr(10) + 'Documento disponibile nel gestionale: ' + path.name, safe='')}")


@app.route("/documenti", methods=["GET", "POST"])
@login_required
def documenti():
   conn = db()
   c = conn.cursor()

   raw_id = request.args.get("tesserato_id") or request.form.get("tesserato_id") or "0"
   tesserato_id = parse_int(raw_id, 0)
   tesserati = c.execute("""
       SELECT t.id, t.nome, t.cognome, t.data_nascita, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato, m.data_consenso
       FROM tesserati t
       LEFT JOIN minori m ON m.tesserato_id = t.id
       ORDER BY t.cognome, t.nome
   """).fetchall()

   if request.method == "POST":
       action_values = [str(v).strip() for v in request.form.getlist("action") if str(v).strip()]
       if "compile_template_from_library" in action_values:
           action = "compile_template_from_library"
       elif "template_from_library" in action_values or "template" in action_values:
           action = "template_from_library"
       elif "create_asd_folder" in action_values:
           action = "create_asd_folder"
       elif "upload_asd" in action_values:
           action = "upload_asd"
       elif "upload" in action_values:
           action = "upload"
       else:
           action = "upload"

       if action in {"template_from_library", "template", "compile_template_from_library"}:
           try:
               tesserato_target_id = parse_int(request.form.get("tesserato_id"), 0)
               if tesserato_target_id <= 0:
                   raise ValueError("Seleziona un tesserato.")
               tesserato_target = get_tesserato_or_404(c, tesserato_target_id)
               if not tesserato_target:
                   raise ValueError("Tesserato non trovato.")
               template_filename = require_non_empty(request.form.get("template_filename", ""), "Modello ASD", 180)
               categoria = (request.form.get("categoria_template", "Documenti ASD") or "Documenti ASD").strip()
               if categoria not in DOCUMENT_CATEGORIES:
                   categoria = "Documenti ASD"
               note = truncate(request.form.get("note_template", "").strip(), 300)
               data_scadenza_raw = request.form.get("data_scadenza_template", "").strip()
               data_scadenza = require_valid_date(data_scadenza_raw, "la data di scadenza") if data_scadenza_raw else ""

               if action == "compile_template_from_library":
                   rel_path, original_filename, titolo = _compile_template_to_tesserato(template_filename, tesserato_target, load_config())
                   success_msg = "Modello DOCX compilato e salvato correttamente."
               else:
                   rel_path, original_filename, titolo = copy_template_to_tesserato(template_filename, tesserato_target_id)
                   success_msg = "Modello ASD assegnato correttamente."

               c.execute(
                   """
                   INSERT INTO documenti(
                       tesserato_id, titolo, categoria, filename, original_filename,
                       data_caricamento, data_scadenza, note, visibile, tipo_template
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
                   """,
                   (tesserato_target_id, titolo, categoria, rel_path, original_filename, now_iso_date(), data_scadenza, note, template_filename),
               )
               conn.commit()
               conn.close()
               return redirect_with_message("/documenti", success_msg, "success", tesserato_id=tesserato_target_id)
           except ValueError as exc:
               conn.close()
               return layout(alert_html(str(exc), "error"))

       if action == "create_asd_folder":
           try:
               folder_name = sanitize_folder_name(require_non_empty(request.form.get("folder_name", ""), "Nome cartella", 80), "cartella")
               get_asd_named_folder(folder_name)
               conn.close()
               return redirect_with_message("/documenti", f"Cartella ASD '{folder_name}' creata correttamente.", "success")
           except ValueError as exc:
               conn.close()
               return layout(alert_html(str(exc), "error"))

       if action == "upload_asd":
           try:
               folder_name = request.form.get("asd_folder", "").strip()
               _, original_filename = _save_uploaded_asd_document(request.files.get("file_asd"), folder_name)
               conn.close()
               folder_msg = f" nella cartella '{sanitize_folder_name(folder_name, '')}'" if folder_name.strip() else ""
               return redirect_with_message("/documenti", f"Documento ASD '{original_filename}' caricato correttamente{folder_msg}.", "success")
           except ValueError as exc:
               conn.close()
               return layout(alert_html(str(exc), "error"))

       if tesserato_id <= 0:
           conn.close()
           return layout(alert_html("Seleziona prima un tesserato.", "warning"))

       tesserato = get_tesserato_or_404(c, tesserato_id)
       if not tesserato:
           conn.close()
           return layout(alert_html("Tesserato non trovato.", "error")), 404

       if action == "upload":
           try:
               titolo = require_non_empty(request.form.get("titolo", ""), "Titolo documento", 160)
               categoria = (request.form.get("categoria", "") or "").strip()
               if categoria not in DOCUMENT_CATEGORIES:
                   raise ValueError("Categoria documento non valida.")
               note = truncate(request.form.get("note", "").strip(), 300)
               data_scadenza_raw = request.form.get("data_scadenza", "").strip()
               data_scadenza = require_valid_date(data_scadenza_raw, "la data di scadenza") if data_scadenza_raw else ""
               visibile = 1 if request.form.get("visibile") == "1" else 0
               rel_path, original_filename = save_uploaded_document(request.files.get("file"), tesserato_id)
               c.execute(
                   """
                   INSERT INTO documenti(
                       tesserato_id, titolo, categoria, filename, original_filename,
                       data_caricamento, data_scadenza, note, visibile, tipo_template
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)
                   """,
                   (tesserato_id, titolo, categoria, rel_path, original_filename, now_iso_date(), data_scadenza, note, visibile),
               )
               conn.commit()
               conn.close()
               return redirect_with_message("/documenti", "Documento caricato correttamente.", "success", tesserato_id=tesserato_id)
           except ValueError as exc:
               conn.close()
               return layout(alert_html(str(exc), "error"))

       conn.close()
       return redirect_with_message("/documenti", "Azione non valida.", "error", tesserato_id=tesserato_id)

   template_rows = list_template_library_files()
   if tesserato_id <= 0:
       conn.close()
       template_table_rows = ""
       if template_rows:
           for item in template_rows:
               template_table_rows += f"""
               <tr>
                   <td>{e(item['label'])}</td>
                   <td>{e(item['filename'])}</td>
                   <td>{item['size_kb']} KB</td>
                   <td><a href="/documenti/modelli/download/{quote(item['filename'])}">Scarica</a></td>
               </tr>
               """
       else:
           template_table_rows = "<tr><td colspan='4'><div class='empty-state'>Nessun modello ASD presente nella cartella media/modelli_asd.</div></td></tr>"

       asd_docs = _asd_document_rows()
       asd_rows = ""
       if asd_docs:
           for item in asd_docs:
               asd_rows += f"""
               <tr>
                   <td>{e(item['folder'].replace('_', ' ') if item['folder'] else 'Archivio principale')}</td>
                   <td><span class='file-chip' title='{e(item['original_filename'])}'>{e(display_filename(item['original_filename']))}</span></td>
                   <td>{item['size_kb']} KB</td>
                   <td>{e(item['updated_at'])}</td>
                   <td>
                       <div class='actions'>
                           <a href="/documenti/asd/preview/{quote(item['filename'], safe='')}" target="_blank" rel="noopener">Anteprima</a>
                           <a href="/documenti/asd/download/{quote(item['filename'], safe='')}">Scarica</a>
                           <form method="POST" action="/documenti/asd/delete" class="inline-form" onsubmit="return confirm('Eliminare questo documento ASD?');">
                               {csrf_input()}
                               <input type="hidden" name="filename" value="{e(item['filename'])}">
                               <button class="danger">Elimina</button>
                           </form>
                       </div>
                   </td>
               </tr>
               """
       else:
           asd_rows = "<tr><td colspan='5'><div class='empty-state'>Nessun documento ASD presente.</div></td></tr>"

       return layout(f"""
       <div class="page-head">
           <div>
               <div class="kicker">Hub documentale</div>
               <h2 class="section-title" style="font-size:2rem;margin-bottom:6px;">Documenti</h2>
               <div class="small-muted">Gestisci modelli, documenti generali dell’associazione e archivi dei tesserati da un’unica schermata.</div>
           </div>
           <div class="page-actions"><a href="/documenti/asd/accordo-spazi" class="cta-secondary">Genera accordo spazi</a></div>
       </div>

       <div class="stats-grid">
           <div class="stat-card"><div class="label">Modelli ASD</div><div class="value">{len(template_rows)}</div></div>
           <div class="stat-card"><div class="label">Documenti ASD</div><div class="value">{len(asd_docs)}</div></div>
           <div class="stat-card"><div class="label">Tesserati disponibili</div><div class="value">{len(tesserati)}</div></div>
       <div class="stat-card"><div class="label">Minori con alert</div><div class="value">{sum(1 for r in tesserati if _minor_document_state(dict(r))[2])}</div></div>
       </div>

       <div class="card" style="padding:24px;background:linear-gradient(135deg, rgba(56,189,248,.16), rgba(96,165,250,.08));border:1px solid rgba(96,165,250,.28);">
           <div class="kicker">Accesso rapido</div>
           <h3 class="section-title" style="font-size:1.5rem;">Apri l’archivio di un tesserato</h3>
           <div class="small-muted" style="margin-bottom:16px;">Entra direttamente nella scheda documentale del tesserato per caricare file, compilare modelli DOCX e generare PDF pronti.</div>
           <form method="GET" class="form-row">
               <select name="tesserato_id" required style="min-width:320px;">
                   <option value="">Seleziona tesserato</option>
                   {_tesserato_select_options(tesserati)}
               </select>
               <button>Apri archivio</button>
           </form>
           <div class="form-hint">I minori vengono evidenziati già in selezione: se la tutela è incompleta, qui conviene completare prima la scheda atleta.</div>
       </div>

       <div class="grid-2">
           <div class="card">
               <div class="kicker">Modelli intelligenti</div>
               <h3 class="section-title">Assegna o compila un modello</h3>
               <div class="small-muted" style="margin-bottom:14px;">Scegli un modello ASD e invialo subito nella cartella del tesserato, oppure compilalo automaticamente con i suoi dati anagrafici.</div>
               <form method="POST" class="form-row">
                   {csrf_input()}
                   <select name="template_filename" required style="min-width:280px;">
                       <option value="">Seleziona modello</option>
                       {_template_select_options()}
                   </select>
                   <select name="tesserato_id" required style="min-width:280px;">
                       <option value="">Seleziona tesserato</option>
                       {_tesserato_select_options(tesserati)}
                   </select>
                   <select name="categoria_template">
                       <option value="Documenti ASD">Documenti ASD</option>
                       <option value="Documenti tesserato">Documenti tesserato</option>
                       <option value="Certificati e certificazioni">Certificati e certificazioni</option>
                   </select>
                   <input name="data_scadenza_template" placeholder="Scadenza (DD/MM/YYYY)">
                   <input name="note_template" placeholder="Note">
                   <div class="actions" style="margin-top:4px;">
                       <button name="action" value="template_from_library">Copia modello</button>
                       <button name="action" value="compile_template_from_library">Compila DOCX</button>
                   </div>
               </form>
           </div>

           <div class="card">
               <div class="kicker">Documentazione istituzionale</div>
               <h3 class="section-title">Documenti ASD</h3>
               <div class="small-muted" style="margin-bottom:14px;">Qui tieni statuto, certificazioni, regolamenti e documenti generali dell’associazione separati dai documenti dei tesserati.</div>
               <div class="small-muted" style="margin-bottom:12px;">Puoi creare cartelle nominate, ad esempio <strong>gare_2026</strong>, e poi caricare ogni documento nel contenitore corretto.</div>
               <div class="grid-2" style="margin-bottom:14px;">
                   <form method="POST" class="form-row card soft">
                       {csrf_input()}
                       <input type="hidden" name="action" value="create_asd_folder">
                       <input name="folder_name" placeholder="Nuova cartella ASD (es. gare_2026)" required>
                       <button>Crea cartella</button>
                   </form>
                   <form method="POST" enctype="multipart/form-data" class="form-row card soft">
                       {csrf_input()}
                       <input type="hidden" name="action" value="upload_asd">
                       <select name="asd_folder">{_asd_folder_options()}</select>
                       <input type="file" name="file_asd" required style="min-width:260px;">
                       <button>Carica documento ASD</button>
                   </form>
               </div>
               <table>
                   <tr><th>Cartella</th><th>File</th><th>Dimensione</th><th>Aggiornato</th><th>Azioni</th></tr>
                   {asd_rows}
               </table>
           </div>
       </div>

       <div class="card">
           <div class="kicker">Libreria pronta all’uso</div>
           <h3 class="section-title">Modelli ASD disponibili</h3>
           <div class="small-muted" style="margin-bottom:10px;">Questi modelli possono essere copiati o compilati automaticamente per ciascun tesserato.</div>
           <table>
               <tr><th>Titolo</th><th>File</th><th>Dimensione</th><th>Azioni</th></tr>
               {template_table_rows}
           </table>
       </div>
       """)

   tesserato = c.execute("""
       SELECT t.*, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato, m.data_consenso, m.note_consenso
       FROM tesserati t
       LEFT JOIN minori m ON m.tesserato_id = t.id
       WHERE t.id=?
   """, (tesserato_id,)).fetchone()
   if not tesserato:
       conn.close()
       return layout(alert_html("Tesserato non trovato.", "error")), 404

   docs = c.execute(
       """
       SELECT *
       FROM documenti
       WHERE tesserato_id=?
       ORDER BY
           CASE categoria
             WHEN 'Certificati e certificazioni' THEN 0
             WHEN 'Documenti tesserato' THEN 1
             ELSE 2
           END,
           data_caricamento DESC,
           id DESC
       """,
       (tesserato_id,),
   ).fetchall()
   conn.close()

   stats_tot = len(docs)
   minor_flag, minor_badges, minor_alert = _minor_document_state(dict(tesserato))
   stats_scaduti = 0
   stats_scadenza = 0
   for d in docs:
       key, _ = document_status_info(d["data_scadenza"] or "")
       if key == "scaduto":
           stats_scaduti += 1
       elif key == "in_scadenza":
           stats_scadenza += 1

   category_options = "".join(f"<option value='{e(cat)}'>{e(cat)}</option>" for cat in DOCUMENT_CATEGORIES)
   template_options = _template_select_options()

   rows_html = ""
   if docs:
       for d in docs:
           badge_key, badge_label = document_status_info(d["data_scadenza"] or "")
           ext = Path(str(d["filename"] or "")).suffix.lower()
           pdf_ready = f"<a href='/documenti/pdf/{d['id']}'>PDF pronto</a>" if ext in {".doc", ".docx"} else ""
           rows_html += f"""
           <tr>
               <td>{e(d['titolo'])}</td>
               <td>{e(d['categoria'])}</td>
               <td><span class='file-chip' title='{e(d['original_filename'])}'>{e(display_filename(d['original_filename']))}</span></td>
               <td>{e(format_display_date(d['data_caricamento']))}</td>
               <td>{e(format_display_date(d['data_scadenza']))}</td>
               <td><span class='badge {e(badge_key)}'>{e(badge_label)}</span></td>
               <td>{'Sì' if int(d['visibile'] or 0) == 1 else 'No'}</td>
               <td>
                   <div class='actions'>
                       <a href="/documenti/preview/{d['id']}" target="_blank" rel="noopener">Anteprima</a>
                       <a href="/documenti/download/{d['id']}">Scarica</a>
                       {pdf_ready}
                       <a href="/comunicazioni?doc_id={d['id']}">Comunicazioni</a>
                       <form method="POST" action="/documenti/delete" class="inline-form" onsubmit="return confirm('Eliminare questo documento?');">
                           {csrf_input()}
                           <input type="hidden" name="tesserato_id" value="{tesserato_id}">
                           <input type="hidden" name="id" value="{d['id']}">
                           <button class="danger">Elimina</button>
                       </form>
                   </div>
               </td>
           </tr>
           """
   else:
       rows_html = "<tr><td colspan='8'><div class='empty-state'>Nessun documento presente per questo tesserato.</div></td></tr>"

   return layout(f"""
   <div class="app-section-hero">
       <div class="kicker">Archivio tesserato</div>
       <h2 style="margin:6px 0 6px 0;font-size:2rem;">{e(tesserato['nome'])} {e(tesserato['cognome'])}</h2>
       <div class="small-muted">Corso: {e(tesserato['corso'] or '-')} • Archivio: cartella personale del tesserato • Certificato tesserato: {e(format_display_date(tesserato['certificato_scadenza'])) or 'Non indicato'}</div>
       <div class="toolbar-actions">{minor_badges}</div>
       <div class="page-actions">
           <a href="/documenti" class="nav-link" style="display:inline-flex;padding:10px 14px;width:auto;">Libreria documenti</a>
           <a href="/tesserati" class="nav-link" style="display:inline-flex;padding:10px 14px;width:auto;">← Torna ai tesserati</a>
       </div>
   </div>

   <div class="metric-strip">
       <div class="metric-box"><div class="label">Documenti totali</div><div class="value">{stats_tot}</div></div>
       <div class="metric-box"><div class="label">In scadenza</div><div class="value">{stats_scadenza}</div></div>
       <div class="metric-box"><div class="label">Scaduti</div><div class="value">{stats_scaduti}</div></div>
       <div class="metric-box"><div class="label">Alert tutela</div><div class="value">{'1' if minor_alert else '0'}</div></div>
   </div>

   {f"<div class='live-alert {'yellow' if minor_alert else 'green'}'><span class='badge-dot {'dot-yellow' if minor_alert else 'dot-green'}'></span><div><strong>Stato minore</strong><div class='small-muted'>{minor_badges}</div></div></div>" if minor_flag else ''}

   <div class="card" style="padding:24px;background:linear-gradient(135deg, rgba(56,189,248,.16), rgba(96,165,250,.08));border:1px solid rgba(96,165,250,.28);">
       <div class="kicker">Azioni rapide</div>
       <h3 class="section-title" style="font-size:1.45rem;">Compila o carica documenti nella cartella del tesserato</h3>
       <div class="small-muted" style="margin-bottom:16px;">Da qui puoi caricare un file manualmente oppure generare subito un documento compilato dal modello ASD selezionato.</div>
       <div class="toolbar-actions">
           <a href="#upload-doc" class="nav-link" style="display:inline-flex;padding:10px 14px;width:auto;">Carica documento</a>
           <a href="/documenti/iscrizione-csen/{tesserato['id']}" class="nav-link" style="display:inline-flex;padding:10px 14px;width:auto;">Modulo iscrizione CSEN</a>
           <a href="#modelli-doc" class="nav-link" style="display:inline-flex;padding:10px 14px;width:auto;">Compila DOCX</a>
           <a href="#archivio-doc" class="nav-link" style="display:inline-flex;padding:10px 14px;width:auto;">Vai all’archivio</a>
       </div>
   </div>

   <div class="grid-2">
       <div class="card card-elevated" id="upload-doc">
           <div class="kicker">Caricamento manuale</div>
           <h3 class="section-title">Nuovo documento</h3>
           <div class="small-muted" style="margin-bottom:12px;">Salva un file reale del tesserato mantenendo titolo, categoria e scadenza subito leggibili nell’archivio.</div>
           {f"<div class='alert warning' style='margin-bottom:12px;'><strong>Attenzione tutela minori.</strong> Prima di usare l'archivio documentale verifica genitore, recapiti e consenso: {minor_badges}</div>" if minor_alert else ''}
           <form method="POST" enctype="multipart/form-data" class="form-row">
               {csrf_input()}
               <input type="hidden" name="action" value="upload">
               <input type="hidden" name="tesserato_id" value="{tesserato_id}">
               <input name="titolo" placeholder="Titolo documento" required style="min-width:260px;">
               <select name="categoria">{category_options}</select>
               <input type="file" name="file" required style="min-width:250px;">
               <input name="data_scadenza" placeholder="Scadenza (DD/MM/YYYY)">
               <input name="note" placeholder="Note" style="min-width:220px;">
               <label style="align-self:center;"><input type="checkbox" name="visibile" value="1" checked> Visibile al tesserato</label>
               <button>Carica documento</button>
           </form>
       </div>

       <div class="card card-elevated" id="modelli-doc">
           <div class="kicker">Modelli ASD</div>
           <h3 class="section-title">Copia o compila modello</h3>
           <div class="small-muted" style="margin-bottom:12px;">Usa i modelli caricati per creare documenti già pronti dentro la cartella personale del tesserato selezionato.</div>
           <form method="POST" class="form-row">
               {csrf_input()}
               <input type="hidden" name="tesserato_id" value="{tesserato_id}">
               <select name="template_filename" required style="min-width:300px;">{template_options}</select>
               <select name="categoria_template">{category_options}</select>
               <input name="data_scadenza_template" placeholder="Scadenza (DD/MM/YYYY)">
               <input name="note_template" placeholder="Note" style="min-width:220px;">
               <div class="actions" style="margin-top:4px;">
                   <button name="action" value="template_from_library">Copia modello</button>
                   <button name="action" value="compile_template_from_library">Compila DOCX</button>
               </div>
           </form>
       </div>
   </div>

   <div class="card" id="archivio-doc">
       <div class="table-toolbar">
           <div>
               <div class="kicker">Archivio operativo</div>
               <h3 class="section-title" style="margin-bottom:4px;">Elenco documenti del tesserato</h3>
               <div class="small-muted">Preview, download, PDF pronto e invio diretto da un’unica tabella.</div>
           </div>
       </div>
       <table>
           <tr><th>Titolo</th><th>Categoria</th><th>File</th><th>Caricamento</th><th>Scadenza</th><th>Stato</th><th>Visibile</th><th>Azioni</th></tr>
           {rows_html}
       </table>
   </div>
   """)


@app.route("/documenti/modelli/download/<path:filename>")
@login_required
def documenti_template_download(filename: str):
   path = get_template_library_path(filename)
   template_root = get_template_library_dir().resolve()
   if template_root not in path.parents or not path.exists():
       return layout(alert_html("Modello ASD non trovato.", "error")), 404
   return send_file(path, as_attachment=True, download_name=path.name)


@app.route("/documenti/preview/<int:doc_id>")
@login_required
def documenti_preview(doc_id: int):
   conn = db()
   row = conn.execute("SELECT * FROM documenti WHERE id=?", (doc_id,)).fetchone()
   conn.close()
   if not row:
       return layout(alert_html("Documento non trovato.", "error")), 404

   path = document_abs_path(row["filename"])
   if not path.exists():
       return layout(alert_html("File documento non trovato sul disco.", "error")), 404

   try:
       preview_path, mime_type = resolve_document_preview_path(path)
   except ValueError as exc:
       return layout(alert_html(str(exc), "warning"))

   return send_file(preview_path, mimetype=mime_type, as_attachment=False, download_name=preview_path.name, conditional=True)


@app.route("/documenti/download/<int:doc_id>")
@login_required
def documenti_download(doc_id: int):
   conn = db()
   row = conn.execute("SELECT * FROM documenti WHERE id=?", (doc_id,)).fetchone()
   conn.close()
   if not row:
       return layout(alert_html("Documento non trovato.", "error")), 404
   path = document_abs_path(row["filename"])
   if not path.exists():
       return layout(alert_html("File documento non trovato sul disco.", "error")), 404
   return send_file(path, as_attachment=True, download_name=row["original_filename"] or path.name)


@app.route("/documenti/pdf/<int:doc_id>")
@login_required
def documenti_pdf(doc_id: int):
   conn = db()
   row = conn.execute("SELECT * FROM documenti WHERE id=?", (doc_id,)).fetchone()
   conn.close()
   if not row:
       return layout(alert_html("Documento non trovato.", "error")), 404
   path = document_abs_path(row["filename"])
   if not path.exists():
       return layout(alert_html("File documento non trovato sul disco.", "error")), 404
   try:
       preview_path, mime_type = resolve_document_preview_path(path)
   except ValueError as exc:
       return layout(alert_html(str(exc), "warning"))
   if mime_type != "application/pdf":
       return layout(alert_html("PDF pronto disponibile solo per documenti convertibili in PDF.", "warning"))
   pdf_name = f"{Path(row['original_filename'] or path.name).stem}.pdf"
   return send_file(preview_path, mimetype="application/pdf", as_attachment=True, download_name=pdf_name, conditional=True)


@app.route("/documenti/asd/download/<path:filename>")
@login_required
def documenti_asd_download(filename: str):
   path = document_abs_path(secure_relative_media_path('documenti_asd', filename))
   asd_root = get_asd_media_dir().resolve()
   if asd_root not in path.parents or not path.exists():
       return layout(alert_html("Documento ASD non trovato.", "error")), 404
   return send_file(path, as_attachment=True, download_name=path.name)


@app.route("/documenti/asd/preview/<path:filename>")
@login_required
def documenti_asd_preview(filename: str):
   path = document_abs_path(secure_relative_media_path('documenti_asd', filename))
   asd_root = get_asd_media_dir().resolve()
   if asd_root not in path.parents or not path.exists():
       return layout(alert_html("Documento ASD non trovato.", "error")), 404
   try:
       preview_path, mime_type = resolve_document_preview_path(path)
   except ValueError as exc:
       return layout(alert_html(str(exc), "warning"))
   return send_file(preview_path, mimetype=mime_type, as_attachment=False, download_name=preview_path.name, conditional=True)


@app.route("/documenti/asd/delete", methods=["POST"])
@login_required
def documenti_asd_delete():
   # Mantiene anche eventuali sottocartelle dell'archivio ASD.
   # Prima veniva conservato solo Path(...).name: i file dentro cartelle non venivano eliminati correttamente.
   filename = (request.form.get("filename", "") or "").strip().replace("\\", "/")
   if not filename:
       return redirect_with_message("/documenti", "Documento ASD non valido.", "error")
   relative = secure_relative_media_path("documenti_asd", filename)
   path = document_abs_path(relative)
   asd_root = get_asd_media_dir().resolve()
   try:
       resolved = path.resolve()
   except Exception:
       resolved = path
   if asd_root not in resolved.parents or not path.exists():
       return redirect_with_message("/documenti", "Documento ASD non trovato.", "error")
   delete_media_file(relative)
   return redirect_with_message("/documenti", "Documento ASD eliminato.", "success")


@app.route("/documenti/delete", methods=["POST"])
@login_required
def documenti_delete():
   doc_id = parse_int(request.form.get("id"), 0)
   tesserato_id = parse_int(request.form.get("tesserato_id"), 0)
   conn = db()
   row = conn.execute("SELECT filename FROM documenti WHERE id=?", (doc_id,)).fetchone()
   if row:
       delete_media_file(row["filename"])
   conn.execute("DELETE FROM documenti WHERE id=?", (doc_id,))
   conn.commit()
   conn.close()
   return redirect_with_message("/documenti", "Documento eliminato.", "success", tesserato_id=tesserato_id)


@app.route("/documenti/email/<int:doc_id>", methods=["GET", "POST"])
@login_required
def documenti_email(doc_id: int):
   return redirect(f"/comunicazioni?doc_id={int(doc_id)}")


@app.route("/documenti/whatsapp/<int:doc_id>", methods=["GET", "POST"])
@login_required
def documenti_whatsapp(doc_id: int):
   return redirect(f"/comunicazioni?doc_id={int(doc_id)}")


@app.route("/documenti/iscrizione-csen/<int:tesserato_id>")
@login_required
def documento_iscrizione_csen(tesserato_id: int):
   conn = db()
   row = conn.execute(
       """SELECT t.*, m.genitore, m.telefono_genitore, m.email_genitore,
                 m.consenso_firmato
          FROM tesserati t
          LEFT JOIN minori m ON m.tesserato_id=t.id
          WHERE t.id=?""",
       (tesserato_id,),
   ).fetchone()
   conn.close()
   if not row:
       return layout(alert_html("Tesserato non trovato.", "error")), 404

   data_nascita = format_display_date(row["data_nascita"] or "")
   is_minor, _age = get_minor_status_from_birthdate(row["data_nascita"] or "")
   cfg = load_config()
   doc_cfg = cfg.get("documenti", {}) if isinstance(cfg.get("documenti"), dict) else {}
   luogo = doc_cfg.get("sede_comune") or cfg.get("comune") or "Aprilia"
   payload = {
       "nome_cognome": f"{row['nome']} {row['cognome']}".strip(),
       "codice_fiscale": row["codice_fiscale"] or "",
       "luogo_nascita": row["luogo_nascita"] or "",
       "data_nascita": data_nascita,
       "residenza": row["residenza"] or "",
       "email": row["email"] or "",
       "telefono": row["telefono"] or "",
       "disciplina": "Danza Acrobatica Aerea 2026/27 - CSEN 80308",
       "is_minor": is_minor,
       "genitore": row["genitore"] or "",
       "cf_tutore": "",
       "telefono_genitore": row["telefono_genitore"] or "",
       "email_genitore": row["email_genitore"] or "",
       "consenso_firmato": bool(row["consenso_firmato"]),
       "luogo_firma": luogo,
   }
   pdf = build_iscrizione_pdf(BASE_DIR, payload)
   filename = f"modulo_iscrizione_{slugify_tenant(payload['nome_cognome'])}.pdf"
   return send_file(BytesIO(pdf), mimetype="application/pdf", as_attachment=True, download_name=filename)
