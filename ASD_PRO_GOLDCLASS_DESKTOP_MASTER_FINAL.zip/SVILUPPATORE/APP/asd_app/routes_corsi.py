from .core import *

@app.route('/corsi', methods=['GET', 'POST'])
@login_required
def corsi():
    conn = db()
    c = conn.cursor()

    if request.method == 'POST':
        action = (request.form.get('action') or 'create').strip()

        if action == 'delete':
            corso_id = parse_int(request.form.get('id', '0'), 0)
            if corso_id <= 0:
                conn.close()
                return redirect_with_message('/corsi', 'Corso non valido.', 'error')
            c.execute('DELETE FROM corsi WHERE id=?', (corso_id,))
            conn.commit()
            conn.close()
            return redirect_with_message('/corsi', 'Corso eliminato.', 'success')

        try:
            nome = require_non_empty(request.form.get('nome', ''), 'Nome corso', 120)
            descrizione = truncate(request.form.get('descrizione', '').strip(), 300)
            orario = truncate(request.form.get('orario', '').strip(), 80)
            max_iscritti = parse_int(request.form.get('max_iscritti', '0'), 0)
            if max_iscritti < 0:
                raise ValueError('Il numero massimo di iscritti non può essere negativo.')
        except ValueError as exc:
            conn.close()
            return redirect_with_message('/corsi', str(exc), 'error')

        if action == 'update':
            corso_id = parse_int(request.form.get('id', '0'), 0)
            if corso_id <= 0:
                conn.close()
                return redirect_with_message('/corsi', 'Corso non valido.', 'error')
            c.execute(
                'UPDATE corsi SET nome=?, descrizione=?, orario=?, max_iscritti=? WHERE id=?',
                (nome, descrizione, orario, max_iscritti, corso_id),
            )
            msg = 'Corso aggiornato.'
        else:
            c.execute(
                'INSERT INTO corsi(nome, descrizione, orario, max_iscritti) VALUES (?, ?, ?, ?)',
                (nome, descrizione, orario, max_iscritti),
            )
            msg = 'Corso creato.'
        conn.commit()
        conn.close()
        return redirect_with_message('/corsi', msg, 'success')

    edit_row = None
    edit_id = parse_int(request.args.get('edit', '0'), 0)
    if edit_id > 0:
        edit_row = c.execute('SELECT * FROM corsi WHERE id=?', (edit_id,)).fetchone()

    rows = c.execute(
        '''
        SELECT c.*,
               (SELECT COUNT(*) FROM prenotazioni p WHERE p.corso_id = c.id) AS totale_prenotazioni
        FROM corsi c
        ORDER BY c.nome
        '''
    ).fetchall()
    conn.close()

    action = 'update' if edit_row else 'create'
    return layout(f'''
    <div class="card">
        <div class="page-head">
            <div>
                <div class="kicker">Programmazione</div>
                <h2 class="section-title">Corsi</h2>
                <div class="small-muted">Da qui puoi creare corsi e aprire direttamente il registro presenze.</div>
            </div>
            <div class="page-actions">
                <a href="/presenze" class="nav-link" style="display:inline-flex;padding:10px 14px;width:auto;">Registro presenze</a>
            </div>
        </div>

        <form method="POST" class="form-row">
            {csrf_input()}
            <input type="hidden" name="action" value="{action}">
            <input type="hidden" name="id" value="{edit_row['id'] if edit_row else ''}">
            <input name="nome" placeholder="Nome corso" required value="{e(edit_row['nome'] if edit_row else '')}">
            <input name="orario" placeholder="Orario / fascia" value="{e(edit_row['orario'] if edit_row else '')}">
            {number_input('max_iscritti', edit_row['max_iscritti'] if edit_row else '', 'Max iscritti', '1', 0)}
            <textarea name="descrizione" placeholder="Descrizione breve">{e(edit_row['descrizione'] if edit_row else '')}</textarea>
            <button>{'Aggiorna corso' if edit_row else 'Crea corso'}</button>
            {"<a href='/corsi' style='align-self:center;'>Annulla modifica</a>" if edit_row else ""}
        </form>

        <table>
            <tr><th>Corso</th><th>Orario</th><th>Descrizione</th><th>Max iscritti</th><th>Prenotazioni</th><th>Presenze</th><th>Azioni</th></tr>
            {''.join(
                f"""<tr>
                    <td>{e(r['nome'])}</td>
                    <td>{e(r['orario'] or '-')}</td>
                    <td>{e(r['descrizione'] or '-')}</td>
                    <td>{int(r['max_iscritti'] or 0)}</td>
                    <td>{int(r['totale_prenotazioni'] or 0)}</td>
                    <td>
                        <a href='/presenze?data={now_iso_date()}&corso_id={r['id']}'>Segna presenze</a>
                    </td>
                    <td>
                        <div class='actions'>
                            <a href='/corsi?edit={r['id']}'>Modifica</a>
                            <form method='POST' class='inline-form' onsubmit="return confirm('Eliminare questo corso?');">
                                {csrf_input()}
                                <input type='hidden' name='action' value='delete'>
                                <input type='hidden' name='id' value='{r['id']}'>
                                <button class='danger'>Elimina</button>
                            </form>
                        </div>
                    </td>
                </tr>""" for r in rows
            )}
        </table>
    </div>
    ''')
