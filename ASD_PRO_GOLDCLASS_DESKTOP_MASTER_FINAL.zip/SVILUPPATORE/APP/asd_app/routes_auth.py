from .core import *

# AUTH
# ==============================
@app.route("/login", methods=["GET", "POST"])
def login():
   error_html = ""
   selected_tenant_input = ""
   selected_username = ""

   if request.method == "POST":
       blocked, blocked_msg = login_blocked()
       if blocked:
           error_html = f"<p style='color:#fecaca;margin:0 0 10px 0;'>{e(blocked_msg)}</p>"
           log_audit('login_blocked', details=blocked_msg, entity_type='auth', status='blocked')
       else:
           tenant_input = request.form.get("tenant", "").strip()
           selected_tenant_input = tenant_input
           tenant = get_tenant_by_code_or_slug(tenant_input) if tenant_input else None
           if tenant and int(tenant.get("active", 1) or 0) == 1:
               set_current_tenant(str(tenant.get("slug") or DEFAULT_TENANT_SLUG))
           elif tenant_input:
               error_html = "<p style='color:#fecaca;margin:0 0 10px 0;'>Tenant / ASD non valida o disattivata.</p>"
               tenant = None
           username = request.form.get("user", "").strip()
           selected_username = username
           password = request.form.get("pass", "").strip()

           if error_html:
               conn = None
               user = None
           else:
               conn = db()
               user = conn.execute(
               "SELECT id, username, password, role, active, must_change_password, full_name FROM users WHERE username=?",
               (username,),
               ).fetchone()
               conn.close()

           ok = False
           inactive = False
           if user:
               inactive = int(user["active"] or 0) != 1
               saved_password = user["password"] or ""
               if saved_password.startswith(("pbkdf2:", "scrypt:")):
                   ok = check_password_hash(saved_password, password)
               else:
                   ok = saved_password == password
                   if ok:
                       conn = db()
                       conn.execute(
                           "UPDATE users SET password=? WHERE id=?",
                           (generate_password_hash(password), user["id"]),
                       )
                       conn.commit()
                       conn.close()

           if ok and not inactive:
               tenant_slug = current_tenant_slug()
               session.clear()
               session["tenant_slug"] = tenant_slug
               session["logged"] = True
               session["user_id"] = int(user["id"])
               session["username"] = str(user["username"] or username)
               session["display_name"] = str(user["full_name"] or user["username"] or username)
               session["role"] = str(user["role"] or "operator").strip().lower()
               session.permanent = True
               csrf_token()
               clear_login_failures()
               conn = db()
               conn.execute("UPDATE users SET last_login_at=?, updated_at=? WHERE id=?", (now_iso_dt(), now_iso_dt(), user["id"]))
               conn.commit()
               conn.close()
               log_audit('login', details=f"Accesso riuscito tenant={tenant_slug}", entity_type='user', entity_id=str(user['id']))
               if int(user["must_change_password"] or 0) == 1:
                   return redirect("/profilo?first_password=1")
               return redirect("/")

           if ok and inactive:
               error_html = "<p style='color:#fecaca;margin:0 0 10px 0;'>Utente disattivato. Contatta un amministratore.</p>"
               log_audit('login_denied_inactive', details=f'utente={username}', entity_type='user', entity_id=str(user['id']) if user else '', status='denied')
           else:
               record_login_failure()
               detail_bits = []
               if selected_tenant_input:
                   detail_bits.append(f"tenant={selected_tenant_input}")
               if selected_username:
                   detail_bits.append(f"utente={selected_username}")
               log_audit('login_failed', details=' '.join(detail_bits) or 'Credenziali non valide', entity_type='auth', status='denied')
               error_html = "<p style='color:#fecaca;margin:0 0 10px 0;'>Credenziali non valide.</p>"

   cfg = load_config()
   branding = cfg.get("branding", {}) if isinstance(cfg.get("branding"), dict) else {}
   app_name = branding.get("app_name") or cfg.get("nome_asd") or "Asd Pro System"
   login_title = branding.get("login_title") or "Accesso area riservata"
   login_subtitle = branding.get("login_subtitle") or "Gestione professionale ASD con ruoli distinti, branding personalizzabile e archivio documentale centralizzato."
   tenants = get_tenant_choices()
   tenant_options = "".join(
       f"<option value='{e(item.get('code') or item.get('slug'))}'{' selected' if selected_tenant_input and selected_tenant_input == str(item.get('code') or item.get('slug')) else ''}>{e(item.get('name'))} · {e(item.get('code') or item.get('slug'))}</option>"
       for item in tenants
   )
   current_tenant_code = ""
   current_tenant = get_tenant_by_code_or_slug(current_tenant_slug())
   if current_tenant:
       current_tenant_code = str(current_tenant.get("code") or current_tenant.get("slug") or "")
   login_logo = f"<img src='{file_url(cfg.get('logo'))}' style='max-width:120px;border-radius:18px;margin-bottom:14px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);padding:8px;'>" if cfg.get("logo") else ""
   login_bg_css = "background: radial-gradient(circle at top, rgba(56,189,248,.14), transparent 30%), linear-gradient(180deg, #08101d, #0b1220);"
   if cfg.get("background"):
       login_bg_css = (
           "background-image: linear-gradient(rgba(4,10,18,.72), rgba(4,10,18,.82)), url('" + file_url(cfg.get("background")) + "');"
           "background-size: cover; background-position: center; background-attachment: fixed;"
       )

   admin_hint = ""
   if not os.environ.get("ASD_ADMIN_PASSWORD"):
       admin_hint = (
           "<div style='font-size:12px;color:#cbd5e1;'>"
           "Utente iniziale: <b>admin</b> • Password iniziale: <b>admin</b>. "
           "Cambiala subito impostando la variabile ambiente ASD_ADMIN_PASSWORD prima del primo avvio in produzione."
           "</div>"
       )

   return f"""<!DOCTYPE html>
<html lang="it">
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>{e(app_name)}</title>
   <link rel="icon" type="image/png" href="/static/app_icon.png">
   <style>
       body {{
           margin:0;
           min-height:100vh;
           display:grid;
           place-items:center;
           {login_bg_css}
           font-family:Arial, sans-serif;
           color:white;
           padding:16px;
       }}
       .login-box {{
           width:min(420px, 100%);
           padding:28px;
           border-radius:22px;
           background:rgba(10,18,32,.88);
           border:1px solid rgba(255,255,255,.08);
           box-shadow:0 20px 48px rgba(0,0,0,.34);
           animation:fadeApp .35s ease;
       }}
       @keyframes fadeApp {{
           from {{ opacity:0; transform:scale(.995); }}
           to {{ opacity:1; transform:scale(1); }}
       }}
       .login-box h2 {{ margin:0 0 12px 0; }}
       .login-box input, .login-box button, .login-box select {{
           width:100%;
           padding:12px;
           border-radius:12px;
           border:none;
           margin-top:10px;
           box-sizing:border-box;
           font-size:14px;
       }}
       .login-box input, .login-box select {{ background:#f8fafc; color:#0f172a; }}
       .login-box button {{
           background:linear-gradient(180deg, #38bdf8, #60a5fa);
           color:#06111d;
           font-weight:800;
           cursor:pointer;
           transition:transform .15s ease, filter .15s ease, box-shadow .15s ease;
       }}
       .login-box button:hover {{ transform:translateY(-1px); filter:brightness(1.03); }}
       .login-box button:active {{ transform:scale(.97); }}
       .muted {{ font-size:12px; opacity:.85; margin-top:12px; }}
   </style>
</head>
<body>
   <form method="POST" class="login-box">
       {csrf_input()}
       {login_logo}
       <div style="text-transform:uppercase;letter-spacing:.12em;font-size:.78rem;color:#9ddcff;font-weight:700;">Accesso</div>
       <h2>{e(login_title)}</h2><div class="muted" style="font-size:14px;margin-top:-2px;margin-bottom:12px;">{e(login_subtitle)}</div>
       {error_html}
       <select name="tenant" required><option value="">Seleziona ASD / tenant</option>{tenant_options}</select>
       <input name="user" placeholder="Utente" value="{e(selected_username)}" required>
       <input name="pass" type="password" placeholder="Password" required>
       <button>Login</button>
       {admin_hint}
       <div class="muted">Sessione protetta • Token CSRF attivo • Upload max {MAX_UPLOAD_MB} MB</div>
   </form>
</body>
</html>"""


@app.route("/logout", methods=["POST"])
@login_required
def logout():
   username = current_username()
   log_audit('logout', details=f"Uscita utente {username}", entity_type='user', entity_id=str(session.get('user_id') or ''))
   session.clear()
   return redirect("/login")


