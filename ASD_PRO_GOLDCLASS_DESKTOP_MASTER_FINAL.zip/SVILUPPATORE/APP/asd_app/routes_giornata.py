
# -*- coding: utf-8 -*-
from .core import *

@app.route("/giornata")
@app.route("/giornata-operativa")
@login_required
def giornata_operativa():
    html = """
    <div class='app-section-hero'>
      <div>
        <div class='kicker'>Operatività</div>
        <h2 class='section-title'>Giornata operativa ASD</h2>
        <div class='small-muted'>Una pagina guida per non dimenticare nulla: presenze, documenti, quote, IA didattica e permessi.</div>
      </div>
      <div class='page-actions'><a href='/' class='nav-link' style='display:inline-flex;padding:10px 14px;width:auto;'>Dashboard</a></div>
    </div>
    <div class='saas-module-grid'>
      <a class='saas-module-card' href='/presenze'><div class='module-kicker'>Step 1</div><strong>Registro presenze</strong><span>Segna presenti e assenti con controllo visivo.</span></a>
      <a class='saas-module-card' href='/documenti'><div class='module-kicker'>Step 2</div><strong>Documenti DOCX</strong><span>Iscrizioni, manleve, crediti scolastici e attestazioni.</span></a>
      <a class='saas-module-card' href='/pagamenti'><div class='module-kicker'>Step 3</div><strong>Quote e pagamenti</strong><span>Controlla pagamenti mese e ricevute.</span></a>
      <a class='saas-module-card' href='/danza'><div class='module-kicker'>Step 4</div><strong>Danza aerea</strong><span>Archivio tecnico, livelli e contenuti.</span></a>
            <a class='saas-module-card' href='/comunicazioni'><div class='module-kicker'>Comunicazioni</div><strong>Mail e WhatsApp</strong><span>Messaggi pronti nelle app del Mac.</span></a>
    </div>
    """
    return layout(html)
