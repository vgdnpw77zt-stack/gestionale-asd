from .core import *
from .pdf_templates import build_ricevuta_pdf


def genera_pdf(nome: str, desc: str, importo: str, *, ricevuta_id: int | None = None,
                data_emissione: str | None = None, codice_fiscale: str = "",
                per_conto_minore: str = "", metodo_pagamento: str = "") -> Path:
   pdf_dir = get_pdf_dir()
   pdf_dir.mkdir(parents=True, exist_ok=True)
   file_path = pdf_dir / f"ricevuta_{now().strftime('%Y%m%d_%H%M%S_%f')}.pdf"
   payload = {
       "numero": str(ricevuta_id or ""),
       "data": data_emissione or now().strftime("%d/%m/%Y"),
       "importo": f"{float(importo):.2f}".replace(".", ","),
       "ricevuto_da": nome,
       "cf_pagante": codice_fiscale,
       "per_conto_minore": per_conto_minore,
       "causale": desc,
       "metodo_pagamento": metodo_pagamento,
       "metodo_dettaglio": metodo_pagamento.capitalize() if metodo_pagamento else "",
   }
   cfg = load_config()
   doc_cfg = cfg.get("documenti", {}) if isinstance(cfg.get("documenti"), dict) else {}
   tenant_name = str(cfg.get("nome_asd") or doc_cfg.get("denominazione") or "ASD")
   # Il modello allegato è già graficamente BodyMind: lo lasciamo intatto finché
   # l'ASD non configura un proprio branding o non si tratta di un tenant diverso.
   is_bodymind = tenant_name.strip().lower().startswith("bodymind aerial studio")
   logo_path = resolve_brand_asset_path(cfg.get("logo")) if cfg.get("logo") else None
   if logo_path or not is_bodymind:
       payload.update({
           "tenant_name": tenant_name,
           "tenant_cf": str(doc_cfg.get("cf") or ""),
           "tenant_address": str(doc_cfg.get("sede_indirizzo") or ""),
           "tenant_affiliation": str(doc_cfg.get("affiliazione") or ""),
           "tenant_representative": str(doc_cfg.get("presidente") or cfg.get("firma") or ""),
       })
       if logo_path:
           payload["tenant_logo"] = str(logo_path)
   file_path.write_bytes(build_ricevuta_pdf(BASE_DIR, payload))
   return file_path


@app.route("/ricevute", methods=["GET", "POST"])
@login_required
def ricevute():
   conn = db()
   c = conn.cursor()

   if request.method == "POST":
       try:
           nome = require_non_empty(request.form.get("nome", ""), "Nome intestatario", 120)
           desc = require_non_empty(request.form.get("desc", ""), "Descrizione / causale", 180)
           imp = parse_float(request.form.get("importo", "").strip(), -1)
           metodo_pagamento = (request.form.get("metodo_pagamento") or "").strip().lower()
           if metodo_pagamento not in {"", "contanti", "bonifico", "altro"}:
               metodo_pagamento = ""
           if imp < 0:
               raise ValueError("Compila un importo valido.")
       except ValueError as exc:
           conn.close()
           return layout(alert_html(str(exc), "error"))

       c.execute(
           "INSERT INTO ricevute(nome, descrizione, importo, data, pagamento_id, pdf_filename, metodo_pagamento) VALUES (?, ?, ?, ?, NULL, NULL, ?)",
           (nome, desc, imp, now_iso_date(), metodo_pagamento),
       )
       ricevuta_id = c.lastrowid
       conn.commit()

       pdf_path = genera_pdf(nome, desc, f"{imp:.2f}", ricevuta_id=ricevuta_id,
                              data_emissione=format_display_date(now_iso_date()),
                              metodo_pagamento=metodo_pagamento)
       c.execute("UPDATE ricevute SET pdf_filename=? WHERE id=?", (pdf_path.name, ricevuta_id))
       conn.commit()
       conn.close()
       return send_file(pdf_path, as_attachment=True, download_name=pdf_path.name)

   rows = c.execute("SELECT * FROM ricevute ORDER BY id DESC").fetchall()
   conn.close()

   html_out = '''
   <div class="card">
       <div class="page-head">
           <div>
               <div class="kicker">Documenti</div>
               <h2 class="section-title">Ricevute Professionali</h2>
           </div>
       </div>
       <form method="POST" class="form-row">
   '''
   html_out += csrf_input()
   html_out += '''
           <input name="nome" placeholder="Nome intestatario" required>
           <input name="desc" placeholder="Descrizione / causale" required>
           <select name="metodo_pagamento"><option value="">Metodo di pagamento</option><option value="contanti">Contanti</option><option value="bonifico">Bonifico</option><option value="altro">Altro</option></select>
   '''
   html_out += number_input("importo", "", "Importo €", "0.01", 0)
   html_out += '''
           <button>Genera PDF</button>
       </form>
       <table>
           <tr><th>Nome</th><th>Descrizione</th><th>Importo</th><th>Data</th><th>PDF</th><th>Azioni</th></tr>
   '''
   for r in rows:
       pdf_link = f'<a href="/ricevute/pdf/{r["id"]}">PDF</a>'
       html_out += f"""
       <tr>
           <td>{e(r['nome'])}</td>
           <td>{e(r['descrizione'])}</td>
           <td>{euro(r['importo'])}</td>
           <td>{e(format_display_date(r['data']))}</td>
           <td>{e(r['pdf_filename'] or '-')}</td>
           <td>
               <div class='actions'>
                   {pdf_link}
                   <form method="POST" action="/ricevute/delete" class="inline-form" onsubmit="return confirm('Eliminare questa ricevuta?');">
                       {csrf_input()}
                       <input type="hidden" name="id" value="{r['id']}">
                       <button class="danger">Elimina</button>
                   </form>
               </div>
           </td>
       </tr>"""
   html_out += "</table></div>"
   return layout(html_out)


@app.route("/ricevute/pdf/<int:ricevuta_id>")
@login_required
def ricevute_pdf(ricevuta_id: int):
   conn = db()
   row = conn.execute("SELECT * FROM ricevute WHERE id=?", (ricevuta_id,)).fetchone()
   if not row:
       conn.close()
       return layout(alert_html("Ricevuta non trovata.", "error")), 404

   if row["pdf_filename"]:
       existing = get_pdf_dir() / str(row["pdf_filename"])
       if existing.exists():
           conn.close()
           return send_file(existing, as_attachment=True, download_name=existing.name)

   details = dict(row)
   if row["pagamento_id"]:
       pay = conn.execute(
           "SELECT p.metodo_pagamento, t.codice_fiscale, m.genitore "
           "FROM pagamenti p JOIN tesserati t ON t.id=p.tesserato_id "
           "LEFT JOIN minori m ON m.tesserato_id=t.id WHERE p.id=?",
           (row["pagamento_id"],),
       ).fetchone()
       if pay:
           details.update(dict(pay))
   pdf_path = genera_pdf(
       row["nome"], row["descrizione"], f"{float(row['importo'] or 0):.2f}",
       ricevuta_id=int(row["id"]),
       data_emissione=format_display_date(row["data"] or now_iso_date()),
       codice_fiscale=str(details.get("codice_fiscale") or ""),
       per_conto_minore=str(details.get("genitore") or ""),
       metodo_pagamento=str(details.get("metodo_pagamento") or ""),
   )
   conn.execute("UPDATE ricevute SET pdf_filename=? WHERE id=?", (pdf_path.name, ricevuta_id))
   conn.commit()
   conn.close()
   return send_file(pdf_path, as_attachment=True, download_name=pdf_path.name)


@app.route("/ricevute/delete", methods=["POST"])
@login_required
def ricevute_delete():
   rec_id = parse_int(request.form.get("id"), 0)
   conn = db()
   row = conn.execute("SELECT pagamento_id, pdf_filename FROM ricevute WHERE id=?", (rec_id,)).fetchone()
   if row and row["pagamento_id"]:
       conn.close()
       return redirect_with_message("/ricevute", "Le ricevute generate da un pagamento non possono essere eliminate da qui. Elimina o correggi il pagamento di origine.", "warning")
   if row and row["pdf_filename"]:
       path = get_pdf_dir() / str(row["pdf_filename"])
       if path.exists():
           path.unlink(missing_ok=True)
   conn.execute("DELETE FROM ricevute WHERE id=?", (rec_id,))
   conn.commit()
   conn.close()
   return redirect_with_message("/ricevute", "Ricevuta eliminata.", "success")
