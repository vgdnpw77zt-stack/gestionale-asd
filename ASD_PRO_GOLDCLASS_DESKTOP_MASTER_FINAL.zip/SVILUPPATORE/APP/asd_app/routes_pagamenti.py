from .core import *


def _payment_quick_form(row, causale: str, mese: int, anno: int, importo_default: str = "") -> str:
   label = "Registra quota mese" if causale == "mensile" else "Registra iscrizione"
   return f"""
   <form method='POST' class='inline-form' style='display:flex;gap:8px;align-items:center;flex-wrap:wrap;'>
       {csrf_input()}
       <input type='hidden' name='focus' value='quick'>
       <input type='hidden' name='tesserato_id' value='{int(row['id'])}'>
       <input type='hidden' name='causale' value='{e(causale)}'>
       <input type='hidden' name='mese' value='{mese}'>
       <input type='hidden' name='anno' value='{anno}'>
       <input name='importo' type='number' min='0' step='0.01' placeholder='Importo €' value='{e(importo_default)}' style='max-width:130px;' required>
       <select name='metodo_pagamento' style='max-width:145px;'>
           <option value=''>Pagamento</option>
           <option value='contanti'>Contanti</option>
           <option value='bonifico'>Bonifico</option>
           <option value='altro'>Altro</option>
       </select>
       <button>{label}</button>
   </form>
   """


def _minor_payment_state(row: dict) -> dict:
   is_minor, age = get_minor_status_from_birthdate(row.get('data_nascita') or '')
   has_parent = bool((row.get('genitore') or '').strip())
   has_contact = bool((row.get('telefono_genitore') or '').strip() or (row.get('email_genitore') or '').strip())
   consent_ok = int(row.get('consenso_firmato') or 0) == 1
   if not is_minor:
       return {'is_minor': False, 'age': age, 'tone': 'ok', 'needs_alert': False, 'badges': ''}
   badges = ["<span class='pill'>Minore</span>"]
   if age is not None:
       badges.append(f"<span class='pill'>{age} anni</span>")
   if has_parent and has_contact and consent_ok:
       badges.append("<span class='badge valido'>Tutela ok</span>")
       return {'is_minor': True, 'age': age, 'tone': 'ok', 'needs_alert': False, 'badges': ' '.join(badges)}
   if not has_parent:
       badges.append("<span class='badge in_scadenza'>Serve genitore</span>")
   elif not has_contact:
       badges.append("<span class='badge in_scadenza'>Manca recapito</span>")
   elif not consent_ok:
       badges.append("<span class='badge in_scadenza'>Consenso da registrare</span>")
   return {'is_minor': True, 'age': age, 'tone': 'warning', 'needs_alert': True, 'badges': ' '.join(badges)}


def _payment_priority(row: dict) -> tuple:
   state = _minor_payment_state(dict(row))
   severity = 0 if state['needs_alert'] else 1
   return (severity, str(row.get('cognome') or '').lower(), str(row.get('nome') or '').lower())


@app.route("/incassi")
@app.route("/quote")
@app.route("/pagamenti/quote")
@login_required
def pagamenti_shortcut():
   mese = parse_int(request.args.get("mese", "0"), 0)
   anno = parse_int(request.args.get("anno", "0"), 0)
   qs = []
   if mese:
       qs.append(f"mese={int(mese)}")
   if anno:
       qs.append(f"anno={int(anno)}")
   suffix = ("?" + "&".join(qs)) if qs else ""
   return redirect("/pagamenti" + suffix)


@app.route("/pagamenti", methods=["GET", "POST"])
@login_required
def pagamenti():
   conn = db()
   c = conn.cursor()
   mese_corrente, anno_corrente = current_month_year()

   if request.method == "POST":
       try:
           tesserato_id = parse_int(request.form.get("tesserato_id", "0"))
           mese = parse_int(request.form.get("mese", mese_corrente))
           anno = parse_int(request.form.get("anno", anno_corrente))
           importo = parse_float(request.form.get("importo", 0))
           causale = normalize_payment_causale(request.form.get("causale", "mensile"))
           if tesserato_id <= 0:
               raise ValueError("Tesserato non valido.")
           if not (1 <= mese <= 12) or anno < 2000:
               raise ValueError("Mese o anno fuori range.")
           if importo <= 0:
               raise ValueError("Importo non valido.")
       except ValueError as exc:
           conn.close()
           return layout(alert_html(str(exc), "error"))

       try:
           metodo_pagamento = (request.form.get("metodo_pagamento") or "").strip().lower()
           if metodo_pagamento not in {"", "contanti", "bonifico", "altro"}:
               metodo_pagamento = ""
           c.execute(
               "INSERT INTO pagamenti(tesserato_id, mese, anno, importo, data, causale, metodo_pagamento) VALUES (?, ?, ?, ?, ?, ?, ?)",
               (tesserato_id, mese, anno, importo, now_iso_date(), causale, metodo_pagamento),
           )
           pagamento_id = c.lastrowid
           if causale in {"iscrizione", "tesseramento", "quota iscrizione", "quota tesseramento"}:
               try:
                   c.execute("UPDATE tesserati SET tesseramento_pagato=1 WHERE id=?", (tesserato_id,))
               except sqlite3.OperationalError:
                   pass
           ensure_payment_artifacts(c, pagamento_id)
           conn.commit()
           # La ricevuta deve esistere subito dopo la registrazione del pagamento.
           # La generiamo fuori dalla transazione per evitare file orfani in caso di rollback DB.
           receipt_error = ""
           try:
               from .routes_ricevute import genera_pdf
               rr = c.execute("SELECT r.*, t.codice_fiscale, m.genitore FROM ricevute r JOIN pagamenti p ON p.id=r.pagamento_id JOIN tesserati t ON t.id=p.tesserato_id LEFT JOIN minori m ON m.tesserato_id=t.id WHERE r.pagamento_id=?", (pagamento_id,)).fetchone()
               if rr:
                   pdf_path = genera_pdf(rr["nome"], rr["descrizione"], f"{float(rr['importo'] or 0):.2f}", ricevuta_id=int(rr["id"]), data_emissione=format_display_date(rr["data"] or now_iso_date()), codice_fiscale=str(rr["codice_fiscale"] or ""), per_conto_minore=str(rr["genitore"] or ""), metodo_pagamento=str(rr["metodo_pagamento"] or ""))
                   c.execute("UPDATE ricevute SET pdf_filename=? WHERE id=?", (pdf_path.name, int(rr["id"])))
                   conn.commit()
           except Exception as exc:
               receipt_error = str(exc)
           log_audit("payment_create", details=f"causale={causale} mese={mese} anno={anno} importo={importo}", entity_type="pagamento", entity_id=str(pagamento_id))
       except sqlite3.IntegrityError:
           conn.close()
           return layout(alert_html("Pagamento già registrato per questo tesserato, mese, anno e causale.", "warning"))
       except Exception as exc:
           conn.rollback()
           conn.close()
           return layout(alert_html(f"Errore nel salvataggio del pagamento: {exc}", "error"))

       conn.close()
       if receipt_error:
           return redirect_with_message(f"/pagamenti?tesserato_id={tesserato_id}&mese={mese}&anno={anno}", f"Pagamento registrato, ma la ricevuta non è stata generata: {receipt_error}", "warning")
       return redirect_with_message(f"/pagamenti?tesserato_id={tesserato_id}&mese={mese}&anno={anno}", "Pagamento registrato: ricevuta pronta e contabilità aggiornata.", "success")

   selected_tesserato_id = parse_int(request.args.get("tesserato_id", "0"), 0)
   selected_mese = parse_int(request.args.get("mese", mese_corrente), mese_corrente)
   selected_anno = parse_int(request.args.get("anno", anno_corrente), anno_corrente)
   if selected_mese < 1 or selected_mese > 12:
       selected_mese = mese_corrente
   if selected_anno < 2000:
       selected_anno = anno_corrente
   focus = (request.args.get("focus") or "").strip().lower()

   utenti = c.execute("""
       SELECT t.*, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato, m.data_consenso
       FROM tesserati t
       LEFT JOIN minori m ON m.tesserato_id = t.id
       ORDER BY t.cognome, t.nome
   """).fetchall()
   rows = c.execute(
       """
       SELECT p.*, t.nome, t.cognome, t.data_nascita, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato, m.data_consenso, r.id AS ricevuta_id
       FROM pagamenti p
       JOIN tesserati t ON t.id = p.tesserato_id
       LEFT JOIN minori m ON m.tesserato_id = t.id
       LEFT JOIN ricevute r ON r.pagamento_id = p.id
       ORDER BY p.anno DESC, p.mese DESC, p.id DESC
       """
   ).fetchall()
   non_pagati_rows = sorted([dict(x) for x in get_non_pagati_rows()], key=_payment_priority)
   iscrizioni_mancanti_rows = sorted([dict(x) for x in get_missing_iscrizione_rows(selected_anno)], key=_payment_priority)
   payment_status_alerts = get_operational_alerts(selected_mese, selected_anno)
   # Connessione tenuta aperta fino alla fine della renderizzazione: lo storico
   # pagamenti deve poter rigenerare/aggiornare artefatti senza cursor chiuso.

   utenti_options = ""
   selected_user = None
   utenti_sorted = sorted([dict(u) for u in utenti], key=_payment_priority)
   for u in utenti_sorted:
       sel = " selected" if int(u["id"]) == int(selected_tesserato_id or 0) else ""
       state = _minor_payment_state(u)
       label_extra = " · alert minore" if state['needs_alert'] else (" · minore" if state['is_minor'] else "")
       utenti_options += f"<option value='{u['id']}'{sel}>{e(u['nome'])} {e(u['cognome'])}{label_extra}</option>"
       if int(u["id"]) == int(selected_tesserato_id or 0):
           selected_user = u

   quick_non_pagati_html = ""
   if non_pagati_rows:
       for row in non_pagati_rows:
           state = _minor_payment_state(row)
           row_class = "table-row-warning" if state['needs_alert'] else "table-row-ok"
           quick_non_pagati_html += f"""
           <tr class='{row_class}'>
               <td><b>{e(row['nome'])} {e(row['cognome'])}</b><div class='small-muted'>{e(row['telefono'] or 'Telefono non indicato')}</div><div class='small-muted'>{state['badges']} {render_member_status_badge(compute_member_status(row.get('id'), selected_mese, selected_anno, payment_status_alerts))}</div></td>
               <td>{selected_mese:02d}/{selected_anno}</td>
               <td>{_payment_quick_form(row, 'mensile', selected_mese, selected_anno)}</td>
           </tr>
           """

   quick_iscrizioni_html = ""
   if iscrizioni_mancanti_rows:
       for row in iscrizioni_mancanti_rows:
           state = _minor_payment_state(row)
           row_class = "table-row-warning" if state['needs_alert'] else "table-row-ok"
           quick_iscrizioni_html += f"""
           <tr class='{row_class}'>
               <td><b>{e(row['nome'])} {e(row['cognome'])}</b><div class='small-muted'>{e(row['telefono'] or 'Telefono non indicato')}</div><div class='small-muted'>{state['badges']} {render_member_status_badge(compute_member_status(row.get('id'), selected_mese, selected_anno, payment_status_alerts))}</div></td>
               <td>{selected_anno}</td>
               <td>{_payment_quick_form(row, 'iscrizione', 1, selected_anno)}</td>
           </tr>
           """

   total_incassi = round(sum(float(r["importo"] or 0) for r in rows), 2)
   total_rows = len(rows)
   total_non_pagati = len(non_pagati_rows)
   total_iscrizioni_mancanti = len(iscrizioni_mancanti_rows)
   minors_with_alert = sum(1 for u in utenti_sorted if _minor_payment_state(u)['needs_alert'])

   html_out = f"""
   <div class="app-section-hero">
       <div class="kicker">Incassi</div>
       <h2 class="section-title">Pagamenti</h2>
       <div class="small-muted">Registra quote, genera ricevute e controlla rapidamente gli incassi.</div>
       <div class="page-actions">
           <a href="/promemoria?mese={selected_mese}&anno={selected_anno}" class="cta-primary">Apri promemoria intelligente</a>
           <a href="/comunicazioni" class="cta-secondary">Comunicazioni</a>
       </div>
       <div class="inline-guide"><strong>Flusso consigliato</strong><ol><li>Registra quota o crea il pagamento del mese.</li><li>Registra il pagamento e, se serve, prepara una comunicazione.</li><li>Apri promemoria intelligente o WhatsApp dai pulsanti sopra.</li></ol></div>
   </div>
   <div class="metric-strip">
       <div class="metric-box {'warn' if total_non_pagati else ''}"><div class="label">Quote mese mancanti</div><div class="value">{total_non_pagati}</div></div>
       <div class="metric-box {'danger' if total_iscrizioni_mancanti else ''}"><div class="label">Iscrizioni mancanti</div><div class="value">{total_iscrizioni_mancanti}</div></div>
       <div class="metric-box"><div class="label">Alert minori</div><div class="value">{minors_with_alert}</div></div>
       <div class="metric-box"><div class="label">Pagamenti visibili</div><div class="value">{total_rows}</div></div>
       <div class="metric-box"><div class="label">Incassato visibile</div><div class="value">{euro(total_incassi)}</div></div>
   </div>
   """

   if focus in {"non_pagati", "iscrizioni_mancanti"}:
       subtitle = "Risoluzione rapida quote del mese" if focus == "non_pagati" else "Risoluzione rapida iscrizioni annuali"
       html_out += f"<div class='live-alert yellow'><span class='badge-dot dot-yellow'></span><div><strong>{subtitle}</strong><div class='small-muted'>Sei arrivato qui dalla dashboard con il filtro operativo già pronto.</div></div></div>"
   if selected_user:
       selected_state = _minor_payment_state(selected_user)
       if selected_state['badges']:
           html_out += f"<div class='live-alert {'yellow' if selected_state['needs_alert'] else 'green'}'><span class='badge-dot {'dot-yellow' if selected_state['needs_alert'] else 'dot-green'}'></span><div><strong>Tesserato selezionato</strong><div class='small-muted'>{e(selected_user['nome'])} {e(selected_user['cognome'])} · stato tutela: {selected_state['badges']}</div></div></div>"

   html_out += f"""
   <div class="grid-2">
       <div class="card form-panel card-elevated">
           <div class="kicker">Filtro operativo</div>
           <h3 class="section-title">Seleziona periodo e tesserato</h3>
           <form method="GET" class="form-row">
               <input type="hidden" name="focus" value="{e(focus)}">
               <select name="tesserato_id"><option value="0">Seleziona tesserato</option>{utenti_options}</select>
               {number_input("mese", selected_mese, "Mese", "1", 1)}
               {number_input("anno", selected_anno, "Anno", "1", 2000)}
               <button>Applica filtro</button>
               <a href="/pagamenti" class="nav-link" style="display:inline-flex;padding:10px 14px;width:auto;">Reset</a>
           </form>
           <div class="form-hint">Usa il filtro per concentrarti su un tesserato o su un periodo preciso senza uscire dalla schermata incassi.</div>
       </div>
       <div class="card form-panel card-elevated">
           <div class="kicker">Registrazione veloce</div>
           <h3 class="section-title">Nuovo pagamento</h3>
           <form method="POST" class="form-row">
               {csrf_input()}
               <select name="tesserato_id">
                   <option value="0">Seleziona tesserato</option>
                   {utenti_options}
               </select>
               <select name="causale">
                   <option value="mensile">Quota mensile</option>
                   <option value="iscrizione">Quota iscrizione</option>
               </select>
               {number_input("mese", selected_mese, "Mese", "1", 1)}
               {number_input("anno", selected_anno, "Anno", "1", 2000)}
               {number_input("importo", "", "Importo €", "0.01", 0)}
               <select name="metodo_pagamento"><option value="">Metodo di pagamento</option><option value="contanti">Contanti</option><option value="bonifico">Bonifico</option><option value="altro">Altro</option></select>
               <button>Salva pagamento</button>
           </form>
           <div class="form-hint">Al salvataggio il sistema continua a generare ricevuta e movimento contabile automatico come prima.</div>
       </div>
   </div>
   """

   if quick_non_pagati_html:
       html_out += f"""
       <div class="card soft" style="margin-top:16px;">
           <div class="table-toolbar">
               <div>
                   <div class="kicker">Operatività immediata</div>
                   <h3 class="section-title">Tesserati senza quota mensile {selected_mese:02d}/{selected_anno}</h3>
                   <div class="small-muted">Criticità e tutele incomplete vengono mostrate prima; i casi già in ordine restano sotto.</div>
               </div>
           </div>
           <table><tr><th>Tesserato / Stato</th><th>Periodo</th><th>Azione rapida</th></tr>{quick_non_pagati_html}</table>
       </div>
       """

   if quick_iscrizioni_html:
       html_out += f"""
       <div class="card soft" style="margin-top:16px;">
           <div class="table-toolbar">
               <div>
                   <div class="kicker">Operatività immediata</div>
                   <h3 class="section-title">Tesserati senza quota iscrizione {selected_anno}</h3>
                   <div class="small-muted">Anche qui i casi con alert minori vengono raggruppati prima dei profili già regolari.</div>
               </div>
           </div>
           <table><tr><th>Tesserato / Stato</th><th>Anno</th><th>Azione rapida</th></tr>{quick_iscrizioni_html}</table>
       </div>
       """

   storico_rows = sorted([dict(r) for r in rows], key=lambda item: (0 if _minor_payment_state(item)['needs_alert'] else 1, -int(item.get('anno') or 0), -int(item.get('mese') or 0), -int(item.get('id') or 0)))
   table_rows_html = ""
   for r in storico_rows:
       payment_state = _minor_payment_state(r)
       row_class = 'table-row-warning' if payment_state['needs_alert'] else 'table-row-ok'
       ricevuta_link = (f'<a href="/ricevute/pdf/{r["ricevuta_id"]}">PDF</a> · <a href="/comunicazioni?tesserato_id={int(r["tesserato_id"])}&ricevuta_id={int(r["ricevuta_id"])}">Invia</a>' if r.get('ricevuta_id') else '-')
       paid_badge = "<span class='badge valido'>PAGATO</span>" if r.get('paid_at') else "<span class='badge in_scadenza'>APERTO</span>"
       table_rows_html += f"""
       <tr class='{row_class}'>
           <td><strong>{e(r['nome'])} {e(r['cognome'])}</strong><div class='small-muted'>{payment_state['badges']} {render_member_status_badge(compute_member_status(r.get('tesserato_id'), selected_mese, selected_anno, payment_status_alerts))}</div></td>
           <td>{e(PAYMENT_CAUSALI.get(normalize_payment_causale(r['causale']), 'Pagamento'))}</td>
           <td>{r['mese']}</td>
           <td>{r['anno']}</td>
           <td>{euro(r['importo'])}</td>
           <td>{e(format_display_date(r['data']))}</td>
           <td>{ricevuta_link}</td>
           <td>{paid_badge}</td>
           <td>
               <div class='actions'>
                   <a href='/promemoria?mese={int(r['mese'])}&anno={int(r['anno'])}'>Apri promemoria</a>
                   <a href='/comunicazioni'>Comunicazioni</a>
                   <form method="POST" action="/pagamenti/delete" class="inline-form" onsubmit="return confirm('Eliminare questo pagamento? Verranno rimossi anche la ricevuta collegata e il movimento contabile automatico.');">
                       {csrf_input()}
                       <input type="hidden" name="id" value="{r['id']}">
                       <button class="danger">Elimina</button>
                   </form>
               </div>
           </td>
       </tr>"""
   if not table_rows_html:
       table_rows_html = "<tr><td colspan='9'><div class='empty-state'><strong>Nessun pagamento trovato</strong>Prova a cambiare filtro o registra un nuovo incasso dal pannello qui sopra.</div></td></tr>"

   html_out += f"""
   <div class="card">
       <div class="table-toolbar">
           <div>
               <div class="kicker">Storico incassi</div>
               <h3 class="section-title" style="margin-bottom:4px;">Elenco pagamenti</h3>
               <div class="small-muted">I profili con alert tutela vengono mostrati prima; i pagamenti già regolari restano sotto, senza alternanza confusa.</div>
           </div>
       </div>
       <table>
           <tr><th>Nome / Stato</th><th>Causale</th><th>Mese</th><th>Anno</th><th>Importo</th><th>Data</th><th>Ricevuta / invio</th><th>Stato</th><th>Azioni</th></tr>
           {table_rows_html}
       </table>
   </div>
   """
   conn.close()
   return layout(html_out)


@app.route("/pagamenti/delete", methods=["POST"])
@login_required
def pagamenti_delete():
   pagamento_id = parse_int(request.form.get("id"), 0)
   if pagamento_id <= 0:
       return redirect_with_message("/pagamenti", "Pagamento non valido.", "error")

   conn = db()
   c = conn.cursor()

   pagamento = c.execute("SELECT id FROM pagamenti WHERE id=?", (pagamento_id,)).fetchone()
   if not pagamento:
       conn.close()
       return redirect_with_message("/pagamenti", "Pagamento non trovato.", "error")

   try:
       ricevuta = c.execute(
           "SELECT id, pdf_filename FROM ricevute WHERE pagamento_id=?",
           (pagamento_id,),
       ).fetchone()

       if ricevuta and ricevuta["pdf_filename"]:
           pdf_path = get_pdf_dir() / str(ricevuta["pdf_filename"])
           if pdf_path.exists():
               pdf_path.unlink(missing_ok=True)

       c.execute("DELETE FROM ricevute WHERE pagamento_id=?", (pagamento_id,))
       c.execute("DELETE FROM movimenti WHERE pagamento_id=?", (pagamento_id,))
       c.execute("DELETE FROM pagamenti WHERE id=?", (pagamento_id,))
       conn.commit()
       log_audit("payment_delete", details="Pagamento eliminato con artefatti collegati", entity_type="pagamento", entity_id=str(pagamento_id))
   except Exception as exc:
       conn.rollback()
       conn.close()
       return redirect_with_message("/pagamenti", f"Errore durante l'eliminazione del pagamento: {exc}", "error")

   conn.close()
   return redirect_with_message("/pagamenti", "Pagamento eliminato correttamente con ricevuta e movimento contabile collegati.", "success")
