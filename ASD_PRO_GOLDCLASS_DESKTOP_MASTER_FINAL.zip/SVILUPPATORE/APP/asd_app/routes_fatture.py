from __future__ import annotations

from pathlib import Path

from reportlab.lib import colors
from .core import *

FATTURA_STATI = ("bozza", "pronta", "inviata", "consegnata", "scartata")

def next_invoice_number(cursor, anno: int) -> int:
    row = cursor.execute("SELECT COALESCE(MAX(numero), 0) AS max_num FROM fatture WHERE anno=?", (anno,)).fetchone()
    return int((row["max_num"] or 0) + 1)

def invoice_storage_dir() -> Path:
    path = get_pdf_dir() / "fatture"
    path.mkdir(parents=True, exist_ok=True)
    return path

def get_fattura(cursor, fattura_id: int):
    return cursor.execute("SELECT * FROM fatture WHERE id=?", (fattura_id,)).fetchone()

def _doc_cfg(cfg: dict) -> dict:
    return cfg.get("documenti", {}) if isinstance(cfg.get("documenti"), dict) else {}

def _issuer_lines(cfg: dict) -> list[str]:
    doc = _doc_cfg(cfg)
    fatt = cfg.get("fatturapa", {}) if isinstance(cfg.get("fatturapa"), dict) else {}
    denominazione = (doc.get("denominazione") or cfg.get("nome_asd") or fatt.get("cedente_nome") or "ASD").strip()
    cf = (doc.get("cf") or fatt.get("cedente_cf") or "").strip()
    piva = (doc.get("piva") or fatt.get("cedente_piva") or "").strip()
    indirizzo = (doc.get("sede_indirizzo") or fatt.get("cedente_indirizzo") or "").strip()
    cap = (doc.get("sede_cap") or fatt.get("cedente_cap") or "").strip()
    comune = (doc.get("sede_comune") or fatt.get("cedente_comune") or "").strip()
    provincia = (doc.get("sede_provincia") or fatt.get("cedente_provincia") or "").strip()
    email = (doc.get("email") or "").strip()
    pec = (doc.get("pec") or fatt.get("cedente_pec") or "").strip()
    telefono = (doc.get("telefono") or fatt.get("cedente_telefono") or "").strip()

    lines = [denominazione]
    cf_piva = " - ".join(part for part in [f"C.F. {cf}" if cf else "", f"P.IVA {piva}" if piva else ""] if part)
    if cf_piva:
        lines.append(cf_piva)
    sede = " ".join(part for part in [indirizzo, cap, comune] if part).strip()
    if provincia:
        sede = f"{sede} ({provincia})".strip()
    if sede:
        lines.append(sede)
    contatti = " • ".join(part for part in [telefono, email, pec] if part)
    if contatti:
        lines.append(contatti)
    return lines

def get_fatturapa_cfg() -> dict:
    return dict(load_config().get("fatturapa", {}))

def generate_invoice_pdf(fattura_row) -> Path:
    cfg = load_config()
    doc = _doc_cfg(cfg)

    out_dir = invoice_storage_dir()
    cleanup_old_files(out_dir, "fattura_*.pdf", keep=60)

    if fattura_row["pdf_path"]:
        existing = Path(str(fattura_row["pdf_path"]))
        if existing.exists():
            return existing

    file_path = out_dir / f"fattura_{fattura_row['anno']}_{int(fattura_row['numero']):05d}.pdf"

    pdf = canvas.Canvas(str(file_path), pagesize=A4)
    width, height = A4
    left, right = 40, width - 40
    top = height - 42

    pdf.setFillColor(colors.whitesmoke)
    pdf.rect(0, 0, width, height, fill=1, stroke=0)

    pdf.setFillColor(colors.HexColor("#1e3a5f"))
    pdf.roundRect(left, top - 110, right - left, 95, 12, fill=1, stroke=0)

    logo_path = resolve_brand_asset_path(cfg.get("logo", "")) if cfg.get("logo") else None
    text_left = left + 22
    if logo_path and logo_path.exists():
        try:
            logo = ImageReader(str(logo_path))
            pdf.drawImage(
                logo,
                left + 18,
                top - 93,
                width=62,
                height=62,
                preserveAspectRatio=True,
                mask="auto"
            )
            text_left = left + 95
        except Exception:
            pass

    issuer_lines = _issuer_lines(cfg)
    pdf.setFillColor(colors.white)
    pdf.setFont("Helvetica-Bold", 17)
    pdf.drawString(text_left, top - 30, truncate(issuer_lines[0], 72))
    pdf.setFont("Helvetica", 9)
    line_y = top - 46
    for line in issuer_lines[1:4]:
        pdf.drawString(text_left, line_y, truncate(line, 95))
        line_y -= 12

    card_x = right - 180
    card_y = top - 96
    pdf.setFillColor(colors.HexColor("#ebf4ff"))
    pdf.setStrokeColor(colors.HexColor("#90cdf4"))
    pdf.roundRect(card_x, card_y, 155, 65, 10, fill=1, stroke=1)
    pdf.setFillColor(colors.HexColor("#1a365d"))
    pdf.setFont("Helvetica-Bold", 11)
    pdf.drawString(card_x + 14, card_y + 44, "FATTURA")
    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(card_x + 14, card_y + 24, f"{int(fattura_row['numero'])}/{int(fattura_row['anno'])}")
    pdf.setFont("Helvetica", 9)
    pdf.drawString(card_x + 14, card_y + 9, f"Data: {format_display_date(fattura_row['data'])}")

    box_top = top - 135
    pdf.setFillColor(colors.white)
    pdf.setStrokeColor(colors.HexColor("#d1d5db"))
    pdf.roundRect(left, box_top - 90, right - left, 80, 10, fill=1, stroke=1)
    pdf.setFillColor(colors.HexColor("#2d3748"))
    pdf.setFont("Helvetica-Bold", 11)
    pdf.drawString(left + 18, box_top - 25, "Cliente / Cessionario")
    pdf.setFont("Helvetica", 10)
    pdf.drawString(left + 18, box_top - 44, truncate(fattura_row['cliente_nome'], 95))
    cliente_line2 = " - ".join(part for part in [f"CF {fattura_row['cliente_cf']}" if fattura_row['cliente_cf'] else "", f"P.IVA {fattura_row['cliente_piva']}" if fattura_row['cliente_piva'] else ""] if part)
    if cliente_line2:
        pdf.drawString(left + 18, box_top - 60, truncate(cliente_line2, 95))
    cliente_sede = " ".join(part for part in [fattura_row['cliente_indirizzo'] or "", fattura_row['cliente_cap'] or "", fattura_row['cliente_comune'] or ""] if part).strip()
    provincia = (fattura_row['cliente_provincia'] or '').strip()
    if provincia:
        cliente_sede = f"{cliente_sede} ({provincia})".strip()
    if cliente_sede:
        pdf.drawString(left + 18, box_top - 76, truncate(cliente_sede, 95))

    table_top = box_top - 120
    table_left = left
    table_right = right
    col_desc = 300
    col_imp = 90
    col_iva = 100

    pdf.setFillColor(colors.HexColor("#edf2f7"))
    pdf.setStrokeColor(colors.HexColor("#cbd5e0"))
    pdf.rect(table_left, table_top, table_right - table_left, 24, fill=1, stroke=1)
    pdf.setFillColor(colors.HexColor("#1a202c"))
    pdf.setFont("Helvetica-Bold", 10)
    pdf.drawString(table_left + 8, table_top + 8, "Descrizione")
    pdf.drawString(table_left + col_desc + 8, table_top + 8, "Imponibile")
    pdf.drawString(table_left + col_desc + col_imp + 8, table_top + 8, "IVA")
    pdf.drawString(table_right - 55, table_top + 8, "Totale")

    row_y = table_top - 34
    pdf.setFillColor(colors.white)
    pdf.rect(table_left, row_y, table_right - table_left, 34, fill=1, stroke=1)
    pdf.setFillColor(colors.black)
    pdf.setFont("Helvetica", 9)
    pdf.drawString(table_left + 8, row_y + 20, truncate(fattura_row['descrizione'], 58))
    pdf.drawRightString(table_left + col_desc + col_imp - 8, row_y + 20, euro(fattura_row['imponibile'] or fattura_row['importo']))
    iva_label = f"{float(fattura_row['aliquota_iva'] or 0):.2f}%"
    if float(fattura_row['aliquota_iva'] or 0) == 0 and fattura_row['natura']:
        iva_label = f"0% ({fattura_row['natura']})"
    pdf.drawRightString(table_left + col_desc + col_imp + col_iva - 8, row_y + 20, iva_label)
    pdf.drawRightString(table_right - 8, row_y + 20, euro(fattura_row['totale_documento'] or fattura_row['importo']))

    imponibile = float(fattura_row['imponibile'] or fattura_row['importo'] or 0)
    imposta = float(fattura_row['imposta'] or 0)
    totale = float(fattura_row['totale_documento'] or fattura_row['importo'] or 0)
    bollo = 2.0 if int(fattura_row['bollo'] or 0) == 1 else 0.0

    totals_x = right - 210
    totals_y = row_y - 100
    pdf.setFillColor(colors.HexColor("#f7fafc"))
    pdf.setStrokeColor(colors.HexColor("#cbd5e0"))
    pdf.roundRect(totals_x, totals_y, 210, 88, 10, fill=1, stroke=1)
    pdf.setFillColor(colors.black)
    pdf.setFont("Helvetica", 10)
    pdf.drawString(totals_x + 14, totals_y + 62, "Imponibile")
    pdf.drawRightString(totals_x + 195, totals_y + 62, euro(imponibile))
    pdf.drawString(totals_x + 14, totals_y + 44, "IVA")
    pdf.drawRightString(totals_x + 195, totals_y + 44, euro(imposta))
    pdf.drawString(totals_x + 14, totals_y + 26, "Bollo")
    pdf.drawRightString(totals_x + 195, totals_y + 26, euro(bollo))
    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawString(totals_x + 14, totals_y + 8, "Totale documento")
    pdf.drawRightString(totals_x + 195, totals_y + 8, euro(totale))

    footer_y = 85
    pdf.setStrokeColor(colors.HexColor("#cbd5e0"))
    pdf.line(left, footer_y + 28, right, footer_y + 28)
    pdf.setFillColor(colors.HexColor("#4a5568"))
    pdf.setFont("Helvetica", 8.5)
    regime = (cfg.get("fatturapa", {}) or {}).get("regime_fiscale", "")
    note = "Documento PDF di cortesia"
    if regime:
        note += f" • Regime fiscale: {regime}"
    pdf.drawString(left, footer_y + 10, truncate(note, 115))
    presidente = (doc.get("presidente") or cfg.get("firma") or "").strip()
    if presidente:
        pdf.drawString(left, footer_y - 6, truncate(f"Riferimento ASD: {presidente}", 90))
    pdf.drawRightString(right, footer_y - 6, truncate(issuer_lines[0], 80))

    pdf.save()
    return file_path

# resto invariato

def xml_safe(value) -> str:
    return e(value or "")

def generate_invoice_xml(fattura_row) -> Path:
    cfg = get_fatturapa_cfg()
    out_dir = invoice_storage_dir()
    cleanup_old_files(out_dir, "fattura_*.xml", keep=60)
    xml_path = out_dir / f"fattura_{fattura_row['anno']}_{int(fattura_row['numero']):05d}.xml"
    progressivo = "{:05d}".format(int(fattura_row["numero"]))
    piva = cfg.get("cedente_piva", "")
    codice_destinatario = fattura_row["cliente_codice_destinatario"] or cfg.get("codice_destinatario_default", "0000000")
    natura = fattura_row["natura"] or cfg.get("natura_default", "N2.2")
    natura_xml = f"<Natura>{xml_safe(natura)}</Natura>" if float(fattura_row["aliquota_iva"] or 0) == 0 else ""
    pec_xml = f"<PECDestinatario>{xml_safe(fattura_row['cliente_pec'])}</PECDestinatario>" if fattura_row["cliente_pec"] else ""
    bollo_line = ""
    if int(fattura_row["bollo"] or 0) == 1:
        bollo_line = "<DatiBollo><BolloVirtuale>SI</BolloVirtuale><ImportoBollo>2.00</ImportoBollo></DatiBollo>"
    imponibile = float(fattura_row["imponibile"] or fattura_row["importo"] or 0)
    imposta = float(fattura_row["imposta"] or 0)
    totale = float(fattura_row["totale_documento"] or fattura_row["importo"] or 0)
    aliquota = float(fattura_row["aliquota_iva"] or 0)

    xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<p:FatturaElettronica versione="FPR12" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:p="http://ivaservizi.agenziaentrate.gov.it/docs/xsd/fatture/v1.2">
  <FatturaElettronicaHeader>
    <DatiTrasmissione>
      <IdTrasmittente><IdPaese>IT</IdPaese><IdCodice>{xml_safe(piva)}</IdCodice></IdTrasmittente>
      <ProgressivoInvio>{progressivo}</ProgressivoInvio>
      <FormatoTrasmissione>FPR12</FormatoTrasmissione>
      <CodiceDestinatario>{xml_safe(codice_destinatario)}</CodiceDestinatario>
      {pec_xml}
    </DatiTrasmissione>
    <CedentePrestatore>
      <DatiAnagrafici>
        <IdFiscaleIVA><IdPaese>IT</IdPaese><IdCodice>{xml_safe(piva)}</IdCodice></IdFiscaleIVA>
        <CodiceFiscale>{xml_safe(cfg.get("cedente_cf", ""))}</CodiceFiscale>
        <Anagrafica><Denominazione>{xml_safe(cfg.get("cedente_nome", ""))}</Denominazione></Anagrafica>
        <RegimeFiscale>{xml_safe(cfg.get("regime_fiscale", "RF01"))}</RegimeFiscale>
      </DatiAnagrafici>
      <Sede>
        <Indirizzo>{xml_safe(cfg.get("cedente_indirizzo", ""))}</Indirizzo>
        <CAP>{xml_safe(cfg.get("cedente_cap", ""))}</CAP>
        <Comune>{xml_safe(cfg.get("cedente_comune", ""))}</Comune>
        <Provincia>{xml_safe(cfg.get("cedente_provincia", ""))}</Provincia>
        <Nazione>{xml_safe(cfg.get("cedente_nazione", "IT"))}</Nazione>
      </Sede>
    </CedentePrestatore>
    <CessionarioCommittente>
      <DatiAnagrafici>
        <IdFiscaleIVA><IdPaese>{xml_safe(fattura_row["cliente_nazione"] or "IT")}</IdPaese><IdCodice>{xml_safe(fattura_row["cliente_piva"] or "0000000")}</IdCodice></IdFiscaleIVA>
        <CodiceFiscale>{xml_safe(fattura_row["cliente_cf"] or "")}</CodiceFiscale>
        <Anagrafica><Denominazione>{xml_safe(fattura_row["cliente_nome"])}</Denominazione></Anagrafica>
      </DatiAnagrafici>
      <Sede>
        <Indirizzo>{xml_safe(fattura_row["cliente_indirizzo"] or "")}</Indirizzo>
        <CAP>{xml_safe(fattura_row["cliente_cap"] or "")}</CAP>
        <Comune>{xml_safe(fattura_row["cliente_comune"] or "")}</Comune>
        <Provincia>{xml_safe(fattura_row["cliente_provincia"] or "")}</Provincia>
        <Nazione>{xml_safe(fattura_row["cliente_nazione"] or "IT")}</Nazione>
      </Sede>
    </CessionarioCommittente>
  </FatturaElettronicaHeader>
  <FatturaElettronicaBody>
    <DatiGenerali>
      <DatiGeneraliDocumento>
        <TipoDocumento>{xml_safe(fattura_row["tipo_documento"] or "TD01")}</TipoDocumento>
        <Divisa>EUR</Divisa>
        <Data>{xml_safe(fattura_row["data"])}</Data>
        <Numero>{int(fattura_row["numero"])}/{int(fattura_row["anno"])}</Numero>
        {bollo_line}
        <ImportoTotaleDocumento>{totale:.2f}</ImportoTotaleDocumento>
      </DatiGeneraliDocumento>
    </DatiGenerali>
    <DatiBeniServizi>
      <DettaglioLinee>
        <NumeroLinea>1</NumeroLinea>
        <Descrizione>{xml_safe(fattura_row["descrizione"])}</Descrizione>
        <Quantita>1.00</Quantita>
        <PrezzoUnitario>{imponibile:.2f}</PrezzoUnitario>
        <PrezzoTotale>{imponibile:.2f}</PrezzoTotale>
        <AliquotaIVA>{aliquota:.2f}</AliquotaIVA>
        {natura_xml}
      </DettaglioLinee>
      <DatiRiepilogo>
        <AliquotaIVA>{aliquota:.2f}</AliquotaIVA>
        {natura_xml}
        <ImponibileImporto>{imponibile:.2f}</ImponibileImporto>
        <Imposta>{imposta:.2f}</Imposta>
        <EsigibilitaIVA>{xml_safe(cfg.get("esigibilita_iva", "I"))}</EsigibilitaIVA>
      </DatiRiepilogo>
    </DatiBeniServizi>
  </FatturaElettronicaBody>
</p:FatturaElettronica>
'''
    xml_path.write_text(xml, encoding="utf-8")
    return xml_path

@app.route("/fatture", methods=["GET", "POST"])
@login_required
def fatture():
    conn = db()
    c = conn.cursor()
    ensure_column(c, "fatture", "fattura_tipo", "fattura_tipo TEXT NOT NULL DEFAULT 'elettronica'")
    fatt_cfg = get_fatturapa_cfg()
    view_tipo = (request.args.get("tipo") or "tutte").strip().lower()
    if view_tipo not in {"tutte", "normale", "elettronica"}:
        view_tipo = "tutte"
    edit_id = parse_int(request.args.get("edit_id", "0"), 0)
    edit_row = c.execute("SELECT * FROM fatture WHERE id=?", (edit_id,)).fetchone() if edit_id > 0 else None

    if request.method == "POST":
        action = (request.form.get("action", "create_invoice") or "create_invoice").strip()
        if action in {"create_invoice", "update_invoice"}:
            cliente_nome = require_non_empty(request.form.get("cliente_nome", ""), "Cliente", 140)
            cliente_cf = truncate(request.form.get("cliente_cf", "").strip().upper(), 32)
            cliente_piva = truncate(request.form.get("cliente_piva", "").strip(), 32)
            cliente_email = normalize_email(request.form.get("cliente_email", ""), 140)
            cliente_indirizzo = truncate(request.form.get("cliente_indirizzo", "").strip(), 180)
            cliente_codice_dest = truncate(request.form.get("cliente_codice_destinatario", "").strip() or fatt_cfg.get("codice_destinatario_default", "0000000"), 16)
            cliente_pec = normalize_email(request.form.get("cliente_pec", ""), 140)
            cliente_cap = truncate(request.form.get("cliente_cap", "").strip(), 12)
            cliente_comune = truncate(request.form.get("cliente_comune", "").strip(), 80)
            cliente_provincia = truncate(request.form.get("cliente_provincia", "").strip().upper(), 8)
            cliente_nazione = truncate(request.form.get("cliente_nazione", "").strip().upper() or "IT", 4)
            descrizione = require_non_empty(request.form.get("descrizione", ""), "Descrizione", 200)
            imponibile = round(parse_float(request.form.get("importo", "0"), 0.0), 2)
            aliquota_iva = round(parse_float(request.form.get("aliquota_iva", fatt_cfg.get("iva_default", "0")), 0.0), 2)
            natura = truncate(request.form.get("natura", "").strip() or fatt_cfg.get("natura_default", "N2.2"), 8)
            tipo_documento = truncate(request.form.get("tipo_documento", "").strip() or "TD01", 8)
            data_doc = require_valid_date(request.form.get("data", "").strip() or now_iso_date(), "la data")
            bollo = 1 if request.form.get("bollo") == "on" else 0
            fattura_tipo = "normale" if (request.form.get("fattura_tipo", "elettronica") or "").strip().lower() == "normale" else "elettronica"
            if imponibile <= 0:
                conn.close()
                return layout(alert_html("L'importo deve essere maggiore di zero.", "error"))
            if not cliente_cf and not cliente_piva:
                conn.close()
                return layout(alert_html("Inserisci almeno codice fiscale oppure partita IVA del cliente.", "error"))

            imposta = round(imponibile * (aliquota_iva / 100), 2)
            totale_documento = round(imponibile + imposta + (2.0 if bollo else 0.0), 2)
            anno = datetime.strptime(data_doc, "%Y-%m-%d").year

            if action == "create_invoice":
                numero = next_invoice_number(c, anno)
                c.execute(
                    """
                    INSERT INTO fatture(
                        numero, anno, cliente_nome, cliente_cf, cliente_piva, cliente_email,
                        cliente_indirizzo, descrizione, importo, data, stato, bollo,
                        cliente_codice_destinatario, cliente_pec, cliente_cap, cliente_comune,
                        cliente_provincia, cliente_nazione, tipo_documento, aliquota_iva,
                        natura, imponibile, imposta, totale_documento, fattura_tipo
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'bozza', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (numero, anno, cliente_nome, cliente_cf, cliente_piva, cliente_email,
                     cliente_indirizzo, descrizione, imponibile, data_doc, bollo,
                     cliente_codice_dest, cliente_pec, cliente_cap, cliente_comune,
                     cliente_provincia, cliente_nazione, tipo_documento, aliquota_iva,
                     natura, imponibile, imposta, totale_documento, fattura_tipo),
                )
                conn.commit()
                conn.close()
                return redirect_with_message("/fatture", "Fattura salvata in bozza.", "success", tipo=fattura_tipo)

            fattura_id = parse_int(request.form.get("fattura_id", "0"), 0)
            row = get_fattura(c, fattura_id)
            if not row:
                conn.close()
                return redirect_with_message("/fatture", "Fattura non trovata.", "error", tipo=view_tipo)
            if row["stato"] not in ("bozza", "scartata"):
                conn.close()
                return redirect_with_message("/fatture", "Puoi modificare solo bozze o fatture scartate.", "warning", tipo=view_tipo)
            c.execute(
                """
                UPDATE fatture
                SET anno=?, cliente_nome=?, cliente_cf=?, cliente_piva=?, cliente_email=?, cliente_indirizzo=?,
                    descrizione=?, importo=?, data=?, bollo=?, cliente_codice_destinatario=?, cliente_pec=?,
                    cliente_cap=?, cliente_comune=?, cliente_provincia=?, cliente_nazione=?, tipo_documento=?,
                    aliquota_iva=?, natura=?, imponibile=?, imposta=?, totale_documento=?, fattura_tipo=?
                WHERE id=?
                """,
                (anno, cliente_nome, cliente_cf, cliente_piva, cliente_email, cliente_indirizzo,
                 descrizione, imponibile, data_doc, bollo, cliente_codice_dest, cliente_pec,
                 cliente_cap, cliente_comune, cliente_provincia, cliente_nazione, tipo_documento,
                 aliquota_iva, natura, imponibile, imposta, totale_documento, fattura_tipo, fattura_id),
            )
            conn.commit()
            conn.close()
            return redirect_with_message("/fatture", "Fattura aggiornata correttamente.", "success", tipo=fattura_tipo)

        conn.close()
        return redirect_with_message("/fatture", "Azione non valida.", "error", tipo=view_tipo)

    rows = c.execute("SELECT *, COALESCE(fattura_tipo, 'elettronica') AS fattura_tipo_resolved FROM fatture ORDER BY anno DESC, numero DESC, id DESC").fetchall()
    conn.close()
    normali = [r for r in rows if (r['fattura_tipo_resolved'] or 'elettronica') == 'normale']
    elettroniche = [r for r in rows if (r['fattura_tipo_resolved'] or 'elettronica') != 'normale']
    visible_rows = rows if view_tipo == 'tutte' else (normali if view_tipo == 'normale' else elettroniche)
    edit_tipo = (edit_row['fattura_tipo'] if edit_row and edit_row['fattura_tipo'] else 'elettronica') if edit_row else (view_tipo if view_tipo in {'normale','elettronica'} else 'elettronica')

    html = f"""
    <div class=\"app-section-hero\">
        <div class=\"kicker\">Documenti fiscali</div>
        <h2 class=\"section-title\">Fatture</h2>
        <div class=\"small-muted\">Qui distingui chiaramente fatture normali e fatture elettroniche. Le bozze si possono modificare o eliminare finché non vengono inviate.</div>
        <div class=\"tab-switch\">
            <a href=\"/fatture?tipo=tutte\" class=\"{'active' if view_tipo=='tutte' else ''}\">Tutte</a>
            <a href=\"/fatture?tipo=normale\" class=\"{'active' if view_tipo=='normale' else ''}\">Fatture normali</a>
            <a href=\"/fatture?tipo=elettronica\" class=\"{'active' if view_tipo=='elettronica' else ''}\">Fatture elettroniche</a>
        </div>
        <div class=\"inline-guide\"><strong>Guida rapida</strong><ol><li>Scegli il tipo di fattura nel form.</li><li>Le fatture normali producono PDF professionale.</li><li>Le fatture elettroniche producono anche XML locale.</li></ol></div>
    </div>

    <div class=\"stats-grid\" style=\"margin-bottom:18px;\">
        <div class=\"stat-card\"><div class=\"label\">Totale fatture</div><div class=\"value\">{len(rows)}</div></div>
        <div class=\"stat-card\"><div class=\"label\">Fatture normali</div><div class=\"value\">{len(normali)}</div></div>
        <div class=\"stat-card\"><div class=\"label\">Fatture elettroniche</div><div class=\"value\">{len(elettroniche)}</div></div>
        <div class=\"stat-card\"><div class=\"label\">Bozze</div><div class=\"value\">{sum(1 for r in rows if r['stato']=='bozza')}</div></div>
        <div class=\"stat-card\"><div class=\"label\">Inviate</div><div class=\"value\">{sum(1 for r in rows if r['stato']=='inviata')}</div></div>
    </div>

    <div class=\"card card-elevated\">
        <div class=\"kicker\">Gestione locale</div>
        <h3 class=\"section-title\">PDF e XML sul Mac</h3>
        <div class=\"small-muted\">Le fatture vengono create, archiviate e scaricate localmente. Nessun provider online, PEC automatica o collegamento esterno è richiesto.</div>
    </div>

    <div class=\"card card-elevated\" style=\"margin-top:16px;\">
        <div class=\"kicker\">Creazione documento</div>
        <h3 class=\"section-title\">{'Modifica fattura' if edit_row else 'Nuova fattura'}</h3>
        <form method=\"POST\" class=\"form-row\">
            {csrf_input()}
            <input type=\"hidden\" name=\"action\" value=\"{'update_invoice' if edit_row else 'create_invoice'}\">
            <input type=\"hidden\" name=\"fattura_id\" value=\"{edit_row['id'] if edit_row else ''}\">
            <div class=\"form-col\"><label>Tipo fattura</label><select name=\"fattura_tipo\"><option value=\"normale\" {'selected' if edit_tipo=='normale' else ''}>Normale</option><option value=\"elettronica\" {'selected' if edit_tipo!='normale' else ''}>Elettronica</option></select></div>
            <input name=\"cliente_nome\" placeholder=\"Cliente / Ragione sociale\" required value=\"{e(edit_row['cliente_nome']) if edit_row else ''}\">
            <input name=\"cliente_cf\" placeholder=\"Codice fiscale\" value=\"{e(edit_row['cliente_cf']) if edit_row else ''}\">
            <input name=\"cliente_piva\" placeholder=\"Partita IVA\" value=\"{e(edit_row['cliente_piva']) if edit_row else ''}\">
            <input name=\"cliente_email\" placeholder=\"Email cliente\" value=\"{e(edit_row['cliente_email']) if edit_row else ''}\">
            <input name=\"cliente_indirizzo\" placeholder=\"Indirizzo cliente\" value=\"{e(edit_row['cliente_indirizzo']) if edit_row else ''}\">
            <input name=\"cliente_cap\" placeholder=\"CAP\" value=\"{e(edit_row['cliente_cap']) if edit_row else ''}\">
            <input name=\"cliente_comune\" placeholder=\"Comune\" value=\"{e(edit_row['cliente_comune']) if edit_row else ''}\">
            <input name=\"cliente_provincia\" placeholder=\"Provincia\" value=\"{e(edit_row['cliente_provincia']) if edit_row else ''}\">
            <input name=\"cliente_nazione\" placeholder=\"Nazione\" value=\"{e(edit_row['cliente_nazione']) if edit_row else 'IT'}\">
            <input name=\"cliente_codice_destinatario\" placeholder=\"Codice destinatario\" value=\"{e(edit_row['cliente_codice_destinatario']) if edit_row else e(fatt_cfg.get('codice_destinatario_default', '0000000'))}\">
            <input name=\"cliente_pec\" placeholder=\"PEC cliente\" value=\"{e(edit_row['cliente_pec']) if edit_row else ''}\">
            <input name=\"descrizione\" placeholder=\"Descrizione documento\" required style=\"min-width:260px;\" value=\"{e(edit_row['descrizione']) if edit_row else ''}\">
            <input name=\"tipo_documento\" placeholder=\"Tipo documento\" value=\"{e(edit_row['tipo_documento']) if edit_row else 'TD01'}\">
            {number_input('aliquota_iva', edit_row['aliquota_iva'] if edit_row else fatt_cfg.get('iva_default', '0.00'), 'Aliquota IVA', '0.01', 0)}
            <input name=\"natura\" placeholder=\"Natura\" value=\"{e(edit_row['natura']) if edit_row else e(fatt_cfg.get('natura_default', 'N2.2'))}\">
            {number_input('importo', edit_row['imponibile'] if edit_row else '', 'Imponibile', '0.01', 0)}
            <input name=\"data\" placeholder=\"Data (DD/MM/YYYY)\" value=\"{format_display_date(edit_row['data']) if edit_row else format_display_date(now_iso_date())}\">
            <label style=\"align-self:center;\"><input type=\"checkbox\" name=\"bollo\" {'checked' if edit_row and int(edit_row['bollo'] or 0) == 1 else ''}> Bollo virtuale 2€</label>
            <button>{'Aggiorna bozza' if edit_row else 'Salva bozza'}</button>
            {f"<a href='/fatture?tipo={view_tipo}' class='cta-secondary'>Annulla modifica</a>" if edit_row else ''}
        </form>
        <div class=\"inline-guide\"><strong>Differenza tra i due flussi</strong><p>La fattura <b>normale</b> è pensata per PDF professionali e uso interno. La fattura <b>elettronica</b> usa anche XML locale.</p></div>
    </div>

    <div class=\"card\" style=\"margin-top:16px;\">
        <div class=\"table-toolbar\"><div><div class=\"kicker\">Archivio</div><h3 class=\"section-title\" style=\"margin-bottom:4px;\">Elenco fatture</h3><div class=\"small-muted\">Le bozze possono essere modificate o eliminate. Le fatture pronte restano protette.</div></div></div>
        <table>
            <tr><th>Numero</th><th>Tipo</th><th>Data</th><th>Cliente</th><th>Totale</th><th>Stato</th><th>Azioni</th></tr>
    """
    if visible_rows:
        for r in visible_rows:
            pronta_form = ""
            delete_form = ""
            edit_link = ""
            fattura_tipo = (r['fattura_tipo_resolved'] or 'elettronica')
            if r['stato'] == 'bozza':
                pronta_form = f"<form method='POST' action='/fatture/pronta/{r['id']}' class='inline-form'>{csrf_input()}<button>Segna pronta</button></form>"
                edit_link = f"<a href='/fatture?tipo={view_tipo}&edit_id={r['id']}'>Modifica</a>"
            if r['stato'] in ('bozza', 'scartata'):
                delete_form = f"<form method='POST' action='/fatture/elimina/{r['id']}' class='inline-form' onsubmit=\"return confirm('Eliminare definitivamente questa fattura {r['stato']}?');\">{csrf_input()}<button class='danger'>Elimina</button></form>"
                if not edit_link:
                    edit_link = f"<a href='/fatture?tipo={view_tipo}&edit_id={r['id']}'>Modifica</a>"
            xml_link = '' if fattura_tipo == 'normale' else f"<a href='/fatture/xml/{r['id']}'>XML</a>"
            html += f"""
            <tr>
                <td>{int(r['numero'])}/{int(r['anno'])}</td>
                <td><span class='badge badge-soft'>{'Normale' if fattura_tipo == 'normale' else 'Elettronica'}</span></td>
                <td>{e(format_display_date(r['data']))}</td>
                <td>{e(r['cliente_nome'])}</td>
                <td>{euro(r['totale_documento'] or r['importo'])}</td>
                <td><span class=\"badge\">{e(r['stato'])}</span></td>
                <td><div class=\"actions\"><a href=\"/fatture/pdf/{r['id']}\">PDF</a>{xml_link}{edit_link}{pronta_form}{delete_form}</div></td>
            </tr>
            """
    else:
        html += "<tr><td colspan='7'><div class='empty-state'>Nessuna fattura presente per questo filtro.</div></td></tr>"
    html += """
        </table>
        <div class=\"footer-note\" style=\"margin-top:12px;\">Le fatture normali generano PDF professionale. Le elettroniche possono produrre XML FatturaPA localmente.</div>
    </div>
    """
    return layout(html)


@app.route("/fatture/pdf/<int:fattura_id>")
@login_required
def fatture_pdf(fattura_id: int):
    conn = db()
    c = conn.cursor()
    row = get_fattura(c, fattura_id)
    if not row:
        conn.close()
        return redirect_with_message("/fatture", "Fattura non trovata.", "error")
    pdf_path = generate_invoice_pdf(row)
    c.execute("UPDATE fatture SET pdf_path=? WHERE id=?", (str(pdf_path), fattura_id))
    conn.commit()
    conn.close()
    return send_file(pdf_path, as_attachment=True, download_name=pdf_path.name)

@app.route("/fatture/xml/<int:fattura_id>")
@login_required
def fatture_xml(fattura_id: int):
    conn = db()
    c = conn.cursor()
    row = get_fattura(c, fattura_id)
    if not row:
        conn.close()
        return redirect_with_message("/fatture", "Fattura non trovata.", "error")
    xml_path = generate_invoice_xml(row)
    c.execute("UPDATE fatture SET xml_path=? WHERE id=?", (str(xml_path), fattura_id))
    conn.commit()
    conn.close()
    return send_file(xml_path, as_attachment=True, download_name=xml_path.name)

@app.route("/fatture/pronta/<int:fattura_id>", methods=["POST"])
@login_required
def fatture_pronta(fattura_id: int):
    conn = db()
    c = conn.cursor()
    row = get_fattura(c, fattura_id)
    if not row:
        conn.close()
        return redirect_with_message("/fatture", "Fattura non trovata.", "error")
    if row['stato'] != 'bozza':
        conn.close()
        return redirect_with_message("/fatture", "Solo le bozze possono essere segnate come pronte.", "warning")
    c.execute("UPDATE fatture SET stato='pronta' WHERE id=?", (fattura_id,))
    conn.commit()
    conn.close()
    return redirect_with_message("/fatture", "Fattura segnata come pronta.", "success")

@app.route("/fatture/elimina/<int:fattura_id>", methods=["POST"])
@login_required
def fatture_elimina(fattura_id: int):
    conn = db()
    c = conn.cursor()
    row = get_fattura(c, fattura_id)
    if not row:
        conn.close()
        return redirect_with_message("/fatture", "Fattura non trovata.", "error")
    if row['stato'] not in ('bozza', 'scartata'):
        conn.close()
        return redirect_with_message("/fatture", "Puoi eliminare solo bozze o fatture scartate.", "warning")
    for field in ('pdf_path', 'xml_path'):
        try:
            raw_path = row[field]
            if raw_path:
                p = Path(str(raw_path))
                if p.exists() and p.is_file():
                    p.unlink(missing_ok=True)
        except Exception:
            pass
    c.execute("DELETE FROM fatture WHERE id=?", (fattura_id,))
    conn.commit()
    conn.close()
    log_audit('invoice_delete', details=f"Fattura {fattura_id} eliminata stato={row['stato']}", entity_type='fattura', entity_id=str(fattura_id))
    return redirect_with_message("/fatture", "Fattura eliminata correttamente.", "success")
