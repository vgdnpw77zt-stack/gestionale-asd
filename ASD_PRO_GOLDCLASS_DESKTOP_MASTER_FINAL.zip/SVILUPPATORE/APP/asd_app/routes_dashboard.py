# -*- coding: utf-8 -*-
from .core import *

@app.route("/")
@app.route("/dashboard")
@login_required
def dashboard():
    cfg = load_config()
    mese, anno = current_month_year()
    mese = parse_int(request.args.get("mese", mese), mese)
    anno = parse_int(request.args.get("anno", anno), anno)
    metrics = get_dashboard_metrics(mese, anno)
    alerts = list(metrics.get("alerts", []) or [])
    tasks = list(metrics.get("tasks", []) or [])

    payment_alerts = [a for a in alerts if a.get("category") == "pagamento"]
    tesseramento_alerts = [a for a in alerts if a.get("category") == "tesseramento"]
    minor_alerts = [a for a in alerts if a.get("category") == "minore"]
    cert_alerts = [a for a in alerts if a.get("category") == "certificato"]
    data_alerts = [a for a in alerts if a.get("category") == "anagrafica"]

    conn = db()
    try:
        recenti = conn.execute("SELECT id,nome,cognome,corso FROM tesserati ORDER BY cognome COLLATE NOCASE ASC, nome COLLATE NOCASE ASC LIMIT 28").fetchall()
    except Exception:
        recenti = []
    finally:
        conn.close()

    recenti_bits = []
    for r in recenti:
        status = compute_member_status(r['id'], mese, anno, alerts)
        recenti_bits.append(f"<div class='pro-mini-row a3-person-row a7-person-row'><div><b>{e(r['cognome'])} {e(r['nome'])}</b><span>{e(r['corso'] or 'Nessun corso')}</span></div>{render_member_status_badge(status)}<a class='pro-cta slim' href='/tesserati?edit={int(r['id'])}&drawer=1'>Apri</a></div>")
    recenti_html = "".join(recenti_bits) or "<div class='a2-empty'>Nessun tesserato ancora presente.</div>"

    critical_count = sum(1 for a in alerts if a.get("severity") == "critical")
    warning_count = sum(1 for a in alerts if a.get("severity") == "warning")
    total_actions = len(alerts)
    top_alerts = render_operational_alert_cards(alerts, limit=4, empty="Tutto in ordine per oggi. Nessuna azione urgente nel periodo selezionato.")
    tesseramenti_html = render_operational_alert_cards(tesseramento_alerts, limit=5, empty="Nessuna quota tesseramento mancante.")
    payments_html = render_operational_alert_cards(payment_alerts, limit=5, empty="Nessuna quota mensile mancante per il periodo selezionato.")
    minors_html = render_operational_alert_cards(minor_alerts, limit=5, empty="Nessun minore con consenso/tutela incompleta.")
    certs_html = render_operational_alert_cards(cert_alerts, limit=5, empty="Nessun certificato critico o in scadenza.")
    data_html = render_operational_alert_cards(data_alerts, limit=4, empty="Nessun dato anagrafico essenziale mancante.")
    today_blocked_class = 'danger' if metrics.get('oggi_bloccati') else 'ok'
    today_quote_class = 'warn' if metrics.get('quote_mancanti') else 'ok'

    if critical_count:
        focus_title = f"{critical_count} criticità da chiudere prima"
        focus_text = "Parti dagli alert rossi: bloccano documenti, minori o idoneità sportiva."
        focus_class = "danger"
    elif warning_count:
        focus_title = f"{warning_count} verifiche operative aperte"
        focus_text = "Non è tutto bloccante, ma conviene chiuderle prima della prossima lezione."
        focus_class = "warning"
    else:
        focus_title = "Workspace in ordine"
        focus_text = "Quote, certificati e consensi non mostrano criticità per il periodo selezionato."
        focus_class = "ok"

    html = f"""
    <div class='pro-dashboard a2-dashboard a3-dashboard a5-dashboard a6-dashboard a7-dashboard a71-dashboard a8-dashboard a16-dashboard a18-dashboard a19-dashboard'>
      <section class='a3-command-hero a6-command-hero {focus_class}'>
        <div class='a3-hero-copy a6-hero-copy'>
          <div class='kicker'>Centro operativo ASD</div>
          <div class='tenant-title-wrap a11-title-wrap'><h1 class='tenant-display-title'>{e(cfg.get('nome_asd') or 'ASD Pro')}</h1><span class='a11-title-orbit hero-orbit' aria-hidden='true'><i></i><i></i><i></i></span></div>
          <p class='a3-hero-sub'>Dashboard decisionale: prima cosa fare, poi dove cliccare. Niente alert anonimi.</p>
          <div class='a3-focus-pill {focus_class}'><span class='dot'></span><strong>{e(focus_title)}</strong><span>{e(focus_text)}</span></div>
          <div class='a6-status-strip' aria-label='Sintesi operativa'>
            <span><b>{int(metrics['minori_critici'])}</b> minori</span>
            <span><b>{int(metrics['certificati_critici'])}</b> certificati</span>
            <span><b>{int(metrics.get('tesseramenti_mancanti',0))}</b> tesseramenti</span>
            <span><b>{int(metrics['quote_mancanti'])}</b> quote</span>
            <span><b>{int(metrics.get('task_in_lavorazione',0))}</b> in carico</span>
          </div>
        </div>
        <div class='a3-hero-panel a6-hero-panel a9-task-panel'>
          <div class='a9-task-head'>
            <div>
              <div class='a3-today-label'>Task operativi</div>
              <div class='a3-today-mini'><b>{int(metrics.get('bloccanti',0))}</b> bloccanti · <b>{int(metrics.get('task_in_lavorazione',0))}</b> in carico</div>
            </div>
            <span class='a9-task-count'>{int(total_actions)} task da gestire</span>
          </div>
          <div class='a9-action-grid' aria-label='Azioni rapide dashboard'>
            <a class='a9-action-tile blue' href='/promemoria?guida=1&mese={int(mese)}&anno={int(anno)}'>
              <span class='a9-action-icon'>🔔</span>
              <strong>Motore promemoria</strong>
              <small>Genera promemoria automatici e personalizzati per quote e scadenze.</small>
            </a>
            <a class='a9-action-tile green' href='/tesserati/guidato'>
              <span class='a9-action-icon'>👤＋</span>
              <strong>Nuovo tesserato</strong>
              <small>Crea un nuovo tesserato e avvia subito il percorso completo.</small>
            </a>
            <a class='a9-action-tile purple' href='/pagamenti?mese={int(mese)}&anno={int(anno)}'>
              <span class='a9-action-icon'>💳</span>
              <strong>Registra pagamento</strong>
              <small>Registra un pagamento e genera la ricevuta in automatico.</small>
            </a>
          </div>
          <details class='a9-more-actions'>
            <summary>Altre azioni rapide</summary>
            <form class='a3-period-form a9-period-form' method='get' action='/'>
              <input type='number' min='1' max='12' name='mese' value='{int(mese)}' aria-label='Mese'>
              <input type='number' min='2000' max='2100' name='anno' value='{int(anno)}' aria-label='Anno'>
              <button class='pro-cta strong' type='submit'>Filtra periodo</button>
            </form>
          </details>
        </div>
      </section>


      <section class='a19-situation-strip {focus_class}'>
        <div>
          <span class='a3-eyebrow'>Situazione generale</span>
          <strong>{'Tutto sotto controllo' if total_actions == 0 else f'{total_actions} cose da sistemare oggi'}</strong>
          <small>{'Nessuna criticità operativa aperta nel periodo selezionato.' if total_actions == 0 else 'Parti dalle priorità rosse, poi chiudi pagamenti e promemoria.'}</small>
        </div>
        <a class='pro-cta {'strong' if total_actions else ''}' href='/promemoria?mese={int(mese)}&anno={int(anno)}'>{'Apri centro operativo' if total_actions else 'Verifica comunque'}</a>
      </section>

      <section class='pro-kpi-grid a2-kpi-grid a3-kpi-grid a6-kpi-grid a10-kpi-grid' aria-label='Indicatori dashboard'>
        <a class='pro-kpi a3-kpi a10-kpi {'danger' if metrics.get('tesseramenti_mancanti') else ''}' href='/pagamenti?focus=iscrizioni_mancanti&anno={int(anno)}'><span class='a10-kpi-icon'>🪪</span><div class='a10-kpi-text'><div class='num'>{int(metrics.get('tesseramenti_mancanti',0))}</div><div class='lab'>Tesseramenti mancanti</div><small>Obbligatorio bloccante</small></div></a>
        <a class='pro-kpi a3-kpi a10-kpi {'warn' if metrics['quote_mancanti'] else ''}' href='/pagamenti?mese={int(mese)}&anno={int(anno)}&focus=non_pagati'><span class='a10-kpi-icon'>📅</span><div class='a10-kpi-text'><div class='num'>{int(metrics['quote_mancanti'])}</div><div class='lab'>Quote mese mancanti</div><small>Apri pagamenti</small></div></a>
        <a class='pro-kpi a3-kpi a10-kpi ok' href='/pagamenti?mese={int(mese)}&anno={int(anno)}'><span class='a10-kpi-icon euro'>€</span><div class='a10-kpi-text'><div class='num'>{e(euro(metrics['incasso_mese']))}</div><div class='lab'>Incasso mese</div><small>{int(metrics['pagamenti_ricevuti'])} pagamenti ricevuti</small></div></a>
        <a class='pro-kpi a3-kpi a10-kpi {'danger' if metrics['minori_critici'] else ''}' href='/minori?focus=criticita'><span class='a10-kpi-icon'>👤</span><div class='a10-kpi-text'><div class='num'>{int(metrics['minori_critici'])}</div><div class='lab'>Minori da completare</div><small>Consenso/tutela</small></div></a>
        <a class='pro-kpi a3-kpi a10-kpi {'danger' if metrics['certificati_critici'] else ''}' href='/documenti?focus=certificati_critici'><span class='a10-kpi-icon'>🛡️</span><div class='a10-kpi-text'><div class='num'>{int(metrics['certificati_critici'])}</div><div class='lab'>Certificati critici</div><small>Scaduti o mancanti</small></div></a>
        <a class='pro-kpi a3-kpi a10-kpi {'warn' if metrics['dati_incompleti'] else ''}' href='/tesserati?focus=dati_incompleti'><span class='a10-kpi-icon'>📁</span><div class='a10-kpi-text'><div class='num'>{int(metrics['dati_incompleti'])}</div><div class='lab'>Dati incompleti</div><small>Anagrafica essenziale</small></div></a>
        <a class='pro-kpi a3-kpi a10-kpi {'warn' if metrics.get('task_in_lavorazione') else ''}' href='/promemoria?focus=in_carico&mese={int(mese)}&anno={int(anno)}'><span class='a10-kpi-icon'>💼</span><div class='a10-kpi-text'><div class='num'>{int(metrics.get('task_in_lavorazione',0))}</div><div class='lab'>Task in carico</div><small>Workflow operativo</small></div></a>
      </section>

      <section class='a3-workspace-grid a6-workspace-grid a18-workspace-grid'>
        <div class='a18-workspace-main'>
        <div class='pro-panel a2-priority-panel a3-priority-panel a6-priority-panel'>
          <div class='pro-panel-head a3-panel-head'>
            <div><span class='a3-eyebrow'>Priorità assoluta</span><h2>Cosa devi fare ora</h2></div>
            <a class='pro-cta strong' href='/promemoria?mese={int(mese)}&anno={int(anno)}'>Vedi tutto</a>
          </div>
          <div class='a2-alert-list a3-alert-list a5-focus-alerts'>{top_alerts}</div>
        </div>
      <section class='pro-panel a17-automation-panel a18-automation-panel'>
        <div class='a17-automation-head'>
          <div>
            <span class='a3-eyebrow'>Automazioni comunicazioni</span>
            <h2>Promemoria automatici da scegliere</h2>
            <p>Decidi tu cosa inviare: WhatsApp pronto all'invio, promemoria pagamenti, tesseramenti dopo 10 giorni, certificati e tutela minori. Nessun invio parte senza scelta operativa.</p>
          </div>
          <a class='pro-cta strong' href='/promemoria/whatsapp?mese={int(mese)}&anno={int(anno)}'>Apri WhatsApp</a>
        </div>
        <div class='a17-automation-grid'>
          <a class='a17-automation-tile whatsapp' href='/promemoria/whatsapp?tipo=pagamenti&mese={int(mese)}&anno={int(anno)}'>
            <span>💬</span><b>WhatsApp pagamenti</b><small>{int(metrics.get('quote_mancanti',0))} quote da sollecitare con messaggio pronto.</small>
          </a>
          <a class='a17-automation-tile danger' href='/promemoria/whatsapp?tipo=tesseramenti&mese={int(mese)}&anno={int(anno)}'>
            <span>🪪</span><b>Tesseramento 10 giorni</b><small>{int(metrics.get('tesseramenti_mancanti',0))} tesseramenti bloccanti da ricordare.</small>
          </a>
          <a class='a17-automation-tile' href='/promemoria/whatsapp?tipo=certificati&mese={int(mese)}&anno={int(anno)}'>
            <span>🛡️</span><b>Certificati</b><small>Avvisi per certificato scaduto, mancante o in scadenza.</small>
          </a>
          <a class='a17-automation-tile' href='/promemoria/whatsapp?tipo=minori&mese={int(mese)}&anno={int(anno)}'>
            <span>👨‍👩‍👧</span><b>Genitori / tutela</b><small>Promemoria consenso, tutela e dati genitore per minori.</small>
          </a>
        </div>
      </section>
        </div>
        <aside class='pro-panel a3-assistant-panel a6-assistant-panel a18-assistant-panel'>
          <span class='a3-eyebrow'>Assistente operativo</span>
          <h2>Controllo guidato</h2>
          <ol class='a3-steps a7-steps'>
            <li><b>1. Blocchi reali</b><span>tesseramento, minori e certificati: l'atleta resta rosso finché il dato non viene corretto.</span></li>
            <li><b>2. Urgenza visibile</b><span>ogni task mostra da quanto tempo è aperto o quando va ricordato.</span></li>
            <li><b>3. WhatsApp controllato</b><span>anteprima messaggio prima dell'apertura WhatsApp: nessun invio automatico nascosto.</span></li>
          </ol>
          <a class='pro-cta strong full' href='/promemoria?guida=1&mese={int(mese)}&anno={int(anno)}'>Avvia controllo guidato</a>
        </aside>
      </section>


      <section class='pro-panel a16-today-panel'>
        <div class='a16-today-copy'>
          <span class='a3-eyebrow'>Controllo automatico pre-lezione</span>
          <h2>Oggi in palestra</h2>
          <p>Prima di aprire le presenze: verifica chi è presente, quante attività risultano aperte e quanti atleti sono bloccati da tesseramento, tutela o certificato.</p>
        </div>
        <div class='a16-today-grid'>
          <a href='/presenze' class='a16-today-card ok'><b>{int(metrics.get('oggi_presenti',0))}</b><span>presenti oggi</span></a>
          <a href='/corsi' class='a16-today-card'><b>{int(metrics.get('oggi_corsi',0))}</b><span>corsi con presenze</span></a>
          <a href='/promemoria?mese={int(mese)}&anno={int(anno)}' class='a16-today-card {today_blocked_class}'><b>{int(metrics.get('oggi_bloccati',0))}</b><span>atleti bloccati</span></a>
          <a href='/pagamenti?mese={int(mese)}&anno={int(anno)}&focus=non_pagati' class='a16-today-card {today_quote_class}'><b>{int(metrics.get('quote_mancanti',0))}</b><span>quote da verificare</span></a>
        </div>
        <a class='pro-cta strong a16-today-action' href='/presenze'>Apri controllo presenze</a>
      </section>

      <section class='a3-board a6-board'>
        <div class='pro-panel'><div class='pro-panel-head'><h2>Tesseramenti bloccanti</h2><a class='pro-cta strong' href='/pagamenti?focus=iscrizioni_mancanti&anno={int(anno)}'>Apri tesseramenti</a></div><div class='a2-alert-list compact'>{tesseramenti_html}</div></div>
        <div class='pro-panel'><div class='pro-panel-head'><h2>Pagamenti da controllare</h2><a class='pro-cta strong' href='/pagamenti?mese={int(mese)}&anno={int(anno)}&focus=non_pagati'>Apri pagamenti</a></div><div class='a2-alert-list compact'>{payments_html}</div></div>
        <div class='pro-panel'><div class='pro-panel-head'><h2>Minori da completare</h2><a class='pro-cta strong' href='/minori'>Apri minori</a></div><div class='a2-alert-list compact'>{minors_html}</div></div>
        <div class='pro-panel'><div class='pro-panel-head'><h2>Certificati</h2><a class='pro-cta' href='/documenti'>Documenti</a></div><div class='a2-alert-list compact'>{certs_html}</div></div>
        <div class='pro-panel'><div class='pro-panel-head'><h2>Dati e tesserati</h2><a class='pro-cta' href='/tesserati'>Vai ai tesserati</a></div><div class='a2-alert-list compact'>{data_html}</div><div class='pro-list a3-roster'>{recenti_html}</div></div>
      </section>
    </div>
    """
    return layout(html)
