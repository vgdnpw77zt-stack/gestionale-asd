from .core import *
from pathlib import Path
from reportlab.lib import colors


def _build_collab_receipt_pdf(cursor, receipt_row, *, force: bool = False) -> Path:
    """Crea o rigenera fisicamente il PDF della ricevuta collaboratore.
    È intenzionalmente autonoma: se il DB dice che la ricevuta esiste ma il file manca,
    il download la ricrea invece di mostrare un falso errore.
    """
    collab = cursor.execute(
        "SELECT nome, cognome, ruolo, telefono, email FROM collaboratori WHERE id=?",
        (receipt_row["collaboratore_id"],),
    ).fetchone()
    if not collab:
        raise RuntimeError("Collaboratore collegato alla ricevuta non trovato.")

    PDF_DIR.mkdir(parents=True, exist_ok=True)
    filename = str(receipt_row["filename"] or "").strip()
    if not filename:
        filename = (
            f"ricevuta_collaboratore_{receipt_row['collaboratore_id']}_"
            f"{int(receipt_row['anno']):04d}_{int(receipt_row['mese']):02d}_"
            f"{now().strftime('%Y%m%d_%H%M%S_%f')}.pdf"
        )
    filename = Path(filename).name
    file_path = PDF_DIR / filename
    if file_path.exists() and file_path.stat().st_size > 0 and not force:
        return file_path

    cfg = load_config()
    doc = cfg.get("documenti", {}) if isinstance(cfg.get("documenti"), dict) else {}
    header_title = (doc.get("denominazione") or cfg.get("nome_asd") or "ASD").strip()
    cf = (doc.get("cf") or "").strip()
    piva = (doc.get("piva") or "").strip()
    sede = " ".join(
        part for part in [
            (doc.get("sede_indirizzo") or "").strip(),
            (doc.get("sede_cap") or "").strip(),
            (doc.get("sede_comune") or "").strip(),
        ] if part
    ).strip()
    provincia = (doc.get("sede_provincia") or "").strip()
    if provincia:
        sede = f"{sede} ({provincia})".strip()
    contatti = " • ".join(
        part for part in [
            (doc.get("telefono") or "").strip(),
            (doc.get("email") or "").strip(),
            (doc.get("pec") or "").strip(),
        ] if part
    )

    pdf = canvas.Canvas(str(file_path), pagesize=A4)
    width, height = A4
    left = 42
    right = width - 42
    top = height - 42
    usable_width = right - left

    pdf.setFillColor(colors.whitesmoke)
    pdf.rect(0, 0, width, height, fill=1, stroke=0)

    pdf.setFillColor(colors.HexColor("#18324d"))
    pdf.roundRect(left, top - 120, usable_width, 102, 14, fill=1, stroke=0)
    pdf.setFillColor(colors.white)
    pdf.setFont("Helvetica-Bold", 16)
    pdf.drawString(left + 20, top - 34, truncate(header_title, 72))
    pdf.setFont("Helvetica", 9)
    line_y = top - 49
    for line in [
        " - ".join(part for part in [f"C.F. {cf}" if cf else "", f"P.IVA {piva}" if piva else ""] if part),
        sede,
        contatti,
    ]:
        if line:
            pdf.drawString(left + 20, line_y, truncate(line, 95))
            line_y -= 12

    title_y = top - 150
    pdf.setFillColor(colors.HexColor("#111827"))
    pdf.setFont("Helvetica-Bold", 20)
    pdf.drawString(left, title_y, "RICEVUTA COLLABORATORE")
    pdf.setFont("Helvetica", 10)
    pdf.setFillColor(colors.HexColor("#4b5563"))
    pdf.drawRightString(right, title_y, f"Data emissione: {format_display_date(receipt_row['data_generazione']) or now().strftime('%d/%m/%Y')}")

    box_top = top - 178
    box_height = 255
    pdf.setFillColor(colors.white)
    pdf.setStrokeColor(colors.HexColor("#d1d5db"))
    pdf.roundRect(left, box_top - box_height, usable_width, box_height, 12, fill=1, stroke=1)

    label_x = left + 18
    value_x = left + 170
    row_y = box_top - 34
    descrizione = f"Compenso collaboratore {collab['nome']} {collab['cognome']} - {int(receipt_row['mese']):02d}/{int(receipt_row['anno']):04d}"
    rows_pdf = [
        ("Collaboratore", f"{collab['nome']} {collab['cognome']}"),
        ("Periodo", f"{int(receipt_row['mese']):02d}/{int(receipt_row['anno']):04d}"),
        ("Totale ore", f"{float(receipt_row['totale_ore'] or 0):.2f}"),
        ("Paga oraria", euro(receipt_row['paga_oraria'])),
        ("Totale compenso", euro(receipt_row['totale_compenso'])),
        ("Descrizione", descrizione),
    ]
    for label, value in rows_pdf:
        pdf.setFillColor(colors.HexColor("#1f2937"))
        pdf.setFont("Helvetica-Bold", 10)
        pdf.drawString(label_x, row_y, label)
        pdf.setFillColor(colors.black)
        pdf.setFont("Helvetica", 10)
        pdf.drawString(value_x, row_y, truncate(str(value), 80))
        row_y -= 28

    pdf.setFillColor(colors.HexColor("#1f2937"))
    pdf.setFont("Helvetica-Bold", 10)
    pdf.drawString(label_x, row_y - 10, "Dichiarazione")
    pdf.setFont("Helvetica", 10)
    pdf.drawString(
        label_x,
        row_y - 30,
        truncate(f"Si attesta la liquidazione del compenso di {euro(receipt_row['totale_compenso'])} per l'attività svolta nel periodo indicato.", 120),
    )

    pdf.setStrokeColor(colors.HexColor("#cbd5e1"))
    pdf.line(left, 122, right, 122)
    pdf.setFillColor(colors.HexColor("#111827"))
    pdf.setFont("Helvetica", 9)
    firmatario = (doc.get("presidente") or cfg.get("firma") or "").strip()
    if firmatario:
        pdf.drawString(left, 102, truncate(f"Firma ASD: {firmatario}", 90))
    pdf.save()

    if not file_path.exists() or file_path.stat().st_size <= 0:
        raise RuntimeError("PDF ricevuta collaboratore non creato sul disco.")
    return file_path


@app.route("/collaboratori/ricevute")
@login_required
def collaboratori_ricevute():
    conn = db()
    c = conn.cursor()
    rows = c.execute(
        '''
        SELECT cr.*, c.nome, c.cognome
        FROM collaboratori_ricevute cr
        JOIN collaboratori c ON c.id = cr.collaboratore_id
        ORDER BY cr.anno DESC, cr.mese DESC, cr.id DESC
        '''
    ).fetchall()
    conn.close()

    html = '''
    <div class="app-section-hero">
      <div class="kicker">Collaboratori</div>
      <h2 class="section-title">Ricevute collaboratori</h2>
      <div class="small-muted">Archivio reale dei PDF generati alla chiusura mese. Se un file manca, il download tenta la rigenerazione sicura dai dati salvati.</div>
      <div class="page-actions"><a href="/collaboratori" class="cta-secondary">Torna ai collaboratori</a></div>
      <div class="inline-guide"><strong>Come funziona</strong><p>Prima registra le ore, poi da Collaboratori usa <b>Genera ricevuta</b>. Qui trovi PDF, rigenerazione e cancellazione controllata.</p></div>
    </div>
    <div class="card">
      <table>
        <tr><th>Collaboratore</th><th>Periodo</th><th>Ore</th><th>Paga oraria</th><th>Compenso</th><th>Data</th><th>Azioni</th></tr>
    '''
    if rows:
        for row in rows:
            html += f"""
            <tr>
              <td><strong>{e(row['nome'])} {e(row['cognome'])}</strong></td>
              <td>{int(row['mese'] or 0):02d}/{int(row['anno'] or 0):04d}</td>
              <td>{float(row['totale_ore'] or 0):.2f}</td>
              <td>{euro(row['paga_oraria'])}</td>
              <td><strong>{euro(row['totale_compenso'])}</strong></td>
              <td>{e(format_display_date(row['data_generazione']))}</td>
              <td>
                <div class='actions'>
                  <a href="/collaboratori/ricevute/pdf/{row['id']}" class="cta-secondary">PDF</a>
                  <a href="/collaboratori/ricevute/pdf/{row['id']}?force=1" class="cta-secondary">Rigenera</a>
                  <form method="POST" action="/collaboratori/ricevute/delete" class="inline-form" onsubmit="return confirm('Eliminare questa ricevuta collaboratore?');">
                    {csrf_input()}
                    <input type="hidden" name="id" value="{row['id']}">
                    <button class="danger">Elimina</button>
                  </form>
                </div>
              </td>
            </tr>
            """
    else:
        html += "<tr><td colspan='7'><div class='empty-state'><strong>Nessuna ricevuta collaboratore presente</strong>Registra ore e usa Genera ricevuta nella pagina Collaboratori.</div></td></tr>"

    html += "</table></div>"
    return layout(html)


@app.route("/collaboratori/ricevute/pdf/<int:ricevuta_id>")
@login_required
def collaboratori_ricevute_pdf(ricevuta_id: int):
    force = request.args.get("force") == "1"
    conn = db()
    c = conn.cursor()
    row = c.execute("SELECT * FROM collaboratori_ricevute WHERE id=?", (ricevuta_id,)).fetchone()
    if not row:
        conn.close()
        return layout(alert_html("Ricevuta collaboratore non trovata.", "error")), 404
    try:
        abs_path = _build_collab_receipt_pdf(c, row, force=force)
        if str(row["filename"] or "") != abs_path.name:
            c.execute("UPDATE collaboratori_ricevute SET filename=? WHERE id=?", (abs_path.name, ricevuta_id))
            conn.commit()
    except Exception as exc:
        conn.close()
        return layout(alert_html(f"Impossibile generare il PDF ricevuta collaboratore: {exc}", "error")), 500
    conn.close()
    return send_file(abs_path, as_attachment=True, download_name=abs_path.name)


@app.route("/collaboratori/ricevute/delete", methods=["POST"])
@login_required
def collaboratori_ricevute_delete():
    ricevuta_id = parse_int(request.form.get("id", "0"), 0)
    conn = db()
    c = conn.cursor()
    row = c.execute("SELECT filename, movimento_id FROM collaboratori_ricevute WHERE id=?", (ricevuta_id,)).fetchone()
    if not row:
        conn.close()
        return redirect_with_message("/collaboratori/ricevute", "Ricevuta non trovata.", "error")

    filename = str(row["filename"] or "")
    movimento_id = row["movimento_id"]
    c.execute("DELETE FROM collaboratori_ricevute WHERE id=?", (ricevuta_id,))
    if movimento_id:
        c.execute("DELETE FROM movimenti WHERE id=?", (movimento_id,))
    conn.commit()
    conn.close()

    if filename:
        for candidate in {PDF_DIR / filename, PDF_DIR / Path(filename).name}:
            try:
                if candidate.exists() and candidate.is_file():
                    candidate.unlink()
            except Exception:
                pass

    return redirect_with_message("/collaboratori/ricevute", "Ricevuta collaboratore eliminata.", "success")
