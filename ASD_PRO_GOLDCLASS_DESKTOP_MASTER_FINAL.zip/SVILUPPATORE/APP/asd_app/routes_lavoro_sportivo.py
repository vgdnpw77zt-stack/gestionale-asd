# -*- coding: utf-8 -*-
"""Gestione mensile semplice dei collaboratori sportivi e prospetti F24.

Il modulo non invia dichiarazioni a INPS/Agenzia Entrate: calcola e prepara i dati
necessari al pagamento e alla successiva verifica del consulente/intermediario.
"""
from __future__ import annotations

from datetime import date
from pathlib import Path
from flask import request, redirect, send_file
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

from .core import *
from .docx_engine import build_placeholder_map, compile_docx


SPORT_ACTIVITY_CODES = {
    "atleta": "30",
    "allenatore": "21",
    "istruttore": "22",
    "direttore_tecnico": "23",
    "direttore_sportivo": "24",
    "preparatore_atletico": "25",
    "direttore_gara": "26",
    "tesserato": "27",
}
RAPPORTI = {
    "sportivo_co.co.co": "Lavoratore sportivo - co.co.co.",
    "amministrativo_co.co.co": "Collaborazione amministrativo-gestionale",
}
SECTIONS = {
    "nessuna": ("CXX", 0.25, 0.0203, "D1/D2"),
    "altra_previdenza": ("C10", 0.24, 0.0, "D3"),
}
INPS_THRESHOLD = 5000.0
FISCAL_THRESHOLD = 15000.0


def _month_year():
    m = parse_int(request.values.get("mese", date.today().month), date.today().month)
    y = parse_int(request.values.get("anno", date.today().year), date.today().year)
    return max(1, min(12, m)), y


def _next_month_deadline(month: int, year: int) -> str:
    y, m = (year + 1, 1) if month == 12 else (year, month + 1)
    return f"16/{m:02d}/{y:04d}"


def _load_collaboratori(conn):
    return conn.execute(
        "SELECT * FROM collaboratori WHERE attivo=1 ORDER BY cognome, nome"
    ).fetchall()


def _annual_prior(conn, collab_id: int, month: int, year: int) -> float:
    row = conn.execute(
        """SELECT COALESCE(SUM(compenso_lordo),0) AS tot
           FROM collaboratori_liquidazioni
           WHERE collaboratore_id=? AND anno=? AND mese<?""",
        (collab_id, year, month),
    ).fetchone()
    return float(row["tot"] or 0)


def _hours(conn, collab_id: int, month: int, year: int) -> float:
    row = conn.execute(
        """SELECT COALESCE(SUM(ore),0) AS ore
           FROM ore_collaboratori
           WHERE collaboratore_id=? AND mese=? AND anno=? AND COALESCE(liquidato,0)=0""",
        (collab_id, month, year),
    ).fetchone()
    return round(float(row["ore"] or 0), 2)


def _calculate(row, hours: float, prior: float) -> dict:
    gross = round(hours * float(row["paga_oraria"] or 0), 2)
    tipo = str(row["tipo_rapporto"] or "sportivo_co.co.co")
    coverage = str(row["copertura_previdenziale"] or "nessuna")
    external = float(row["compensi_sportivi_esterni_anno"] or 0)
    explicit_franchise = float(row["franchigia_inps_precedente"] or 0)
    # Per evitare di sommare due volte lo stesso dato, usa il maggiore tra
    # compensi esterni dichiarati e franchigia già utilizzata.
    previous_total = prior + max(external, explicit_franchise)

    # La franchigia di 5.000 euro è annuale e, se ci sono altri committenti,
    # va considerata sulla totalità dei compensi rilevanti.
    remaining = max(0.0, INPS_THRESHOLD - previous_total)
    eligible = round(max(0.0, gross - remaining), 2)

    if coverage == "altra_previdenza":
        ivs_rate = 0.24
        additional_rate = 0.0
        causale = "C10"
        tipo_inps = "D3" if tipo == "sportivo_co.co.co" else "D6"
    else:
        # Nel 2026 anche le co.co.co. amministrativo-gestionali D4/D5 sono
        # al 25% IVS + 2,03% prestazioni non pensionistiche.
        ivs_rate = 0.25
        additional_rate = 0.0203
        causale = "CXX"
        tipo_inps = "D1/D2" if tipo == "sportivo_co.co.co" else "D4/D5"

    # Fino al 31/12/2027 la quota IVS è calcolata sul 50% dell'imponibile;
    # la quota assistenziale aggiuntiva è calcolata sull'intero imponibile.
    ivs_base = round(eligible * 0.50, 2)
    inps_ivs = round(ivs_base * ivs_rate, 2)
    inps_add = round(eligible * additional_rate, 2)
    inps_total = round(inps_ivs + inps_add, 2)
    worker_inps = round(inps_total / 3, 2)
    asd_inps = round(inps_total - worker_inps, 2)

    taxable_before = previous_total + gross
    taxable_after_threshold = max(0.0, taxable_before - FISCAL_THRESHOLD)
    previous_taxable = max(0.0, previous_total - FISCAL_THRESHOLD)
    fiscal_month_base = round(max(0.0, taxable_after_threshold - previous_taxable), 2)
    # Per le co.co.co. sportive/amministrativo-gestionali la tassazione oltre
    # la soglia fiscale non è una ritenuta forfettaria del 20%: dipende dal
    # trattamento fiscale del rapporto e dalle informazioni annuali del lavoratore.
    # Il gestionale calcola quindi l'imponibile fiscale ma lascia la ritenuta
    # a un importo manuale verificabile prima di generare l'F24.
    withholding = 0.0

    net = round(gross - worker_inps - withholding, 2)
    employer_cost = round(gross + asd_inps, 2)

    return {
        "gross": gross, "prior": round(prior, 2), "external": round(external, 2),
        "remaining_inps": round(remaining, 2), "eligible_inps": eligible,
        "ivs_base": ivs_base, "inps_ivs": inps_ivs, "inps_add": inps_add,
        "inps_total": inps_total, "worker_inps": worker_inps, "asd_inps": asd_inps,
        "fiscal_base": fiscal_month_base, "withholding": withholding,
        "net": net, "employer_cost": employer_cost,
        "causale": causale, "tipo_inps": tipo_inps,
    }


def _save_liquidation(conn, collab_id, month, year, result, row):
    existing = conn.execute(
        "SELECT id FROM collaboratori_liquidazioni WHERE collaboratore_id=? AND mese=? AND anno=?",
        (collab_id, month, year),
    ).fetchone()
    values = (
        result["gross"], result["remaining_inps"], result["ivs_base"],
        result["eligible_inps"], result["inps_total"], result["asd_inps"],
        result["worker_inps"], result["fiscal_base"], result["withholding"],
        result["net"], row["tipo_rapporto"] or "sportivo_co.co.co",
        row["copertura_previdenziale"] or "nessuna",
        result["tipo_inps"], row["attivita_inps_codice"] or "22",
        "pagabile", now_iso_date(), now_iso_date(),
    )
    if existing:
        conn.execute(
            """UPDATE collaboratori_liquidazioni SET compenso_lordo=?, franchigia_inps_precedente=?,
               imponibile_inps_ivS=?, imponibile_inps_assistenziale=?, contributo_inps_totale=?,
               quota_inps_asd=?, quota_inps_collaboratore=?, imponibile_fiscale=?, ritenuta_irpef=?,
               netto_pagato=?, tipo_rapporto=?, copertura_previdenziale=?, tipo_rapporto_inps=?,
               codice_attivita_inps=?, stato=?, updated_at=? WHERE id=?""",
            values[:-1] + (existing["id"],),
        )
    else:
        conn.execute(
            """INSERT INTO collaboratori_liquidazioni(
               collaboratore_id,mese,anno,compenso_lordo,franchigia_inps_precedente,
               imponibile_inps_ivS,imponibile_inps_assistenziale,contributo_inps_totale,
               quota_inps_asd,quota_inps_collaboratore,imponibile_fiscale,ritenuta_irpef,
               netto_pagato,tipo_rapporto,copertura_previdenziale,tipo_rapporto_inps,
               codice_attivita_inps,stato,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (collab_id,month,year)+values,
        )


@app.route("/collaboratori/mensile", methods=["GET", "POST"])
@login_required

def collaboratori_mensile():
    mese, anno = _month_year()
    cfg = load_config()
    lavoro_cfg = cfg.get("lavoro_sportivo", {}) if isinstance(cfg.get("lavoro_sportivo"), dict) else {}
    conn = db()
    try:
        rows = _load_collaboratori(conn)
        data = []
        for row in rows:
            ore = _hours(conn, row["id"], mese, anno)
            prior = _annual_prior(conn, row["id"], mese, anno)
            calc = _calculate(row, ore, prior)
            data.append((row, ore, calc))

        if request.method == "POST":
            lavoro_cfg["inps_codice_sede"] = truncate(request.form.get("inps_codice_sede", lavoro_cfg.get("inps_codice_sede", "")), 20)
            lavoro_cfg["inps_filiale"] = truncate(request.form.get("inps_filiale", lavoro_cfg.get("inps_filiale", "")), 60)
            cfg["lavoro_sportivo"] = lavoro_cfg
            save_config(cfg)
            for row, ore, calc in data:
                manual_tax = parse_float(request.form.get(f"ritenuta_{int(row['id'])}", "0"), 0.0)
                if manual_tax > 0:
                    calc["withholding"] = round(manual_tax, 2)
                    calc["net"] = round(calc["gross"] - calc["worker_inps"] - calc["withholding"], 2)
                _save_liquidation(conn, row["id"], mese, anno, calc, row)
            conn.commit()
            # Ricrea le righe F24 aggregate del mese: una riga INPS e una fiscale.
            conn.execute("DELETE FROM f24_sportivi WHERE mese=? AND anno=?", (mese, anno))
            total_inps = round(sum(x[2]["inps_total"] for x in data), 2)
            total_irpef = round(sum(x[2]["withholding"] for x in data), 2)
            deadline = _next_month_deadline(mese, anno)
            if total_inps:
                # Una riga F24 separata per ogni causale INPS: CXX e C10 non vanno accorpate.
                for causale_inps in sorted({x[2]["causale"] for x in data if x[2]["inps_total"] > 0}):
                    causale_total = round(sum(x[2]["inps_total"] for x in data if x[2]["causale"] == causale_inps), 2)
                    if causale_total <= 0:
                        continue
                    conn.execute("""INSERT INTO f24_sportivi(
                        mese,anno,data_scadenza,codice_tributo,sezione,causale,
                        periodo_da,periodo_a,importo,descrizione,stato,created_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (mese,anno,deadline,"", "INPS",causale_inps,
                         f"{mese:02d}/{anno:04d}",f"{mese:02d}/{anno:04d}",
                         causale_total,"Contributi Gestione Separata collaboratori sportivi",
                         "da_pagare",now_iso_date()))
            if total_irpef:
                conn.execute("""INSERT INTO f24_sportivi(
                    mese,anno,data_scadenza,codice_tributo,sezione,causale,
                    periodo_da,periodo_a,importo,descrizione,stato,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (mese,anno,deadline,"1001","ERARIO","1001",
                     f"{mese:02d}",str(anno),total_irpef,
                     "Ritenute IRPEF su compensi co.co.co. sportivi",
                     "da_pagare",now_iso_date()))
            conn.commit()
            return redirect_with_message(
                f"/collaboratori/mensile?mese={mese}&anno={anno}",
                "Liquidazioni mensili e dati F24 aggiornati.", "success"
            )

        total_gross = round(sum(x[2]["gross"] for x in data),2)
        total_inps = round(sum(x[2]["inps_total"] for x in data),2)
        total_worker = round(sum(x[2]["worker_inps"] for x in data),2)
        total_asd = round(sum(x[2]["asd_inps"] for x in data),2)
        total_tax = round(sum(x[2]["withholding"] for x in data),2)
        total_net = round(sum(x[2]["net"] for x in data),2)

        html = f"""
        <div class='page-head'><div><div class='kicker'>Collaboratori</div>
        <h2 class='section-title'>Liquidazione mensile</h2>
        <p class='small-muted'>Ore registrate → compenso → INPS → ritenuta verificata → netto → dati F24. La ritenuta è modificabile per ogni collaboratore.</p></div>
        <a class='cta-secondary' href='/collaboratori'>Torna ai collaboratori</a></div>
        <form method='get' class='form-row'>
          <label>Mese <input type='number' min='1' max='12' name='mese' value='{mese}'></label>
          <label>Anno <input type='number' min='2023' max='2100' name='anno' value='{anno}'></label>
          <label>Codice sede INPS <input name='inps_codice_sede' value='{e(lavoro_cfg.get("inps_codice_sede", ""))}' placeholder='es. 7000'></label>
          <label>Matricola / filiale INPS <input name='inps_filiale' value='{e(lavoro_cfg.get("inps_filiale", ""))}' placeholder='CAP + Comune'></label>
          <button class='cta-secondary'>Calcola</button>
        </form>
        <div class='metric-strip'>
          <div class='metric-box'><div class='label'>Lordo</div><div class='value'>€ {total_gross:,.2f}</div></div>
          <div class='metric-box'><div class='label'>INPS totale</div><div class='value'>€ {total_inps:,.2f}</div></div>
          <div class='metric-box'><div class='label'>Quota ASD</div><div class='value'>€ {total_asd:,.2f}</div></div>
          <div class='metric-box'><div class='label'>Ritenute</div><div class='value'>€ {total_tax:,.2f}</div></div>
          <div class='metric-box'><div class='label'>Netto</div><div class='value'>€ {total_net:,.2f}</div></div>
        </div>
        <div class='card'><table><thead><tr>
        <th>Collaboratore</th><th>Tipo</th><th>Ore</th><th>Lordo</th><th>INPS</th>
        <th>Quota lavoratore</th><th>Ritenuta</th><th>Netto</th><th>Costo ASD</th><th>Pagamento</th></tr></thead><tbody>
        """
        for row, ore, calc in data:
            html += f"""<tr>
            <td>{e(row['nome'])} {e(row['cognome'])}</td>
            <td>{e(RAPPORTI.get(row['tipo_rapporto'] or 'sportivo_co.co.co.','Collaboratore'))}</td>
            <td>{ore:.2f}</td><td>€ {calc['gross']:.2f}</td>
            <td>€ {calc['inps_total']:.2f}</td><td>€ {calc['worker_inps']:.2f}</td>
            <td><input type='number' step='0.01' min='0' name='ritenuta_{int(row['id'])}' value='{calc['withholding']:.2f}' style='width:110px'></td><td>€ {calc['net']:.2f}</td>
            <td>€ {calc['employer_cost']:.2f}</td><td><form method='post' action='/collaboratori/liquidazioni/paga' class='inline-form'>{csrf_input()}<input type='hidden' name='collaboratore_id' value='{int(row['id'])}'><input type='hidden' name='mese' value='{mese}'><input type='hidden' name='anno' value='{anno}'><button class='cta-secondary'>Segna pagato</button></form></td></tr>"""
        html += f"""</tbody></table></div>
        <div class='card'>
        <form method='post'>{csrf_input()}
          <input type='hidden' name='mese' value='{mese}'><input type='hidden' name='anno' value='{anno}'>
          <button class='cta-primary'>Salva liquidazioni e prepara F24</button>
        </form>
        <p class='small-muted'>La ritenuta IRPEF non viene inventata dal gestionale: per le co.co.co. va verificata in base alla situazione fiscale del collaboratore. Inserisci l'importo corretto nella colonna Ritenuta. Scadenza ordinaria: {e(_next_month_deadline(mese,anno))}. Il programma prepara i dati; il pagamento F24/UniEmens resta da effettuare tramite i canali INPS/Agenzia Entrate o intermediario.</p>
        <a class='cta-secondary' href='/collaboratori/f24?mese={mese}&anno={anno}'>Apri prospetto F24</a>
        </div>"""
        return layout(html)
    finally:
        conn.close()


@app.route("/collaboratori/liquidazioni/paga", methods=["POST"])
@login_required
def collaboratore_liquidazione_paga():
    collab_id = parse_int(request.form.get("collaboratore_id"), 0)
    mese = parse_int(request.form.get("mese"), current_month_year()[0])
    anno = parse_int(request.form.get("anno"), current_month_year()[1])
    conn = db()
    try:
        row = conn.execute("SELECT id, netto_pagato FROM collaboratori_liquidazioni WHERE collaboratore_id=? AND mese=? AND anno=?", (collab_id, mese, anno)).fetchone()
        if not row:
            return redirect_with_message(f"/collaboratori/mensile?mese={mese}&anno={anno}", "Prima salva la liquidazione mensile.", "warning")
        conn.execute("UPDATE collaboratori_liquidazioni SET stato='pagato', updated_at=? WHERE id=?", (now_iso_date(), int(row["id"])))
        conn.commit()
    finally:
        conn.close()
    return redirect_with_message(f"/collaboratori/mensile?mese={mese}&anno={anno}", "Liquidazione segnata come pagata.", "success")


@app.route("/collaboratori/f24")
@login_required

def collaboratori_f24():
    mese, anno = _month_year()
    conn = db()
    try:
        rows = conn.execute("SELECT * FROM f24_sportivi WHERE mese=? AND anno=? ORDER BY sezione", (mese,anno)).fetchall()
        html = f"""<div class='page-head'><div><div class='kicker'>Collaboratori</div>
        <h2 class='section-title'>Prospetto F24 — {mese:02d}/{anno}</h2></div>
        <a class='cta-secondary' href='/collaboratori/mensile?mese={mese}&anno={anno}'>Liquidazione</a><a class='cta-secondary' href='/collaboratori/f24/pdf?mese={mese}&anno={anno}'>Scarica prospetto PDF</a></div>
        <div class='card'><p><strong>Non è il modello F24 ufficiale:</strong> sono i dati pronti da riportare nel modello F24 e da verificare prima del pagamento.</p>
        <p class='small-muted'>Sezione INPS: codice sede <b>{e((load_config().get("lavoro_sportivo") or {}).get("inps_codice_sede", ""))}</b> · matricola/filiale <b>{e((load_config().get("lavoro_sportivo") or {}).get("inps_filiale", ""))}</b></p>
        <table><thead><tr><th>Sezione</th><th>Causale contributo</th><th>Codice</th><th>Periodo</th><th>Importo</th><th>Scadenza</th><th>Stato</th></tr></thead><tbody>"""
        for r in rows:
            action = f"<form method='post' action='/collaboratori/f24/paga' class='inline-form'>{csrf_input()}<input type='hidden' name='id' value='{int(r['id'])}'><input type='hidden' name='mese' value='{mese}'><input type='hidden' name='anno' value='{anno}'><button class='cta-secondary'>{'Segna versato' if (r['stato'] or '') != 'pagato' else 'Versato'}</button></form>"
            html += f"<tr><td>{e(r['sezione'])}</td><td>{e(r['causale'] or '')}</td><td>{e(r['codice_tributo'] or '-') if r['codice_tributo'] else '-'}</td><td>{e((r['periodo_da'] or '')+' '+(r['periodo_a'] or ''))}</td><td>€ {float(r['importo'] or 0):.2f}</td><td>{e(r['data_scadenza'] or '')}</td><td>{action}</td></tr>"
        html += "</tbody></table></div>"
        return layout(html)
    finally:
        conn.close()


@app.route("/documenti/asd/accordo-spazi", methods=["GET", "POST"])
@login_required
def genera_accordo_spazi():
    """Genera il modello di convenzione per l'utilizzo condiviso degli spazi."""
    if request.method == "GET":
        html = """<div class='page-head'><div><div class='kicker'>Documenti ASD</div>
        <h2 class='section-title'>Accordo utilizzo spazi</h2>
        <p class='small-muted'>Modello per utilizzo condiviso e non esclusivo della sala. Compilare le parti e verificare il titolo di disponibilità dell'altra ASD.</p></div></div>
        <form method='post' class='card'>
          <label>Parti contraenti <input name='parti' placeholder='ASD ospitante e BodyMind Aerial Studio ASD' required></label>
          <label>Data inizio <input name='data_inizio' placeholder='01/10/2026' required></label>
          <label>Data fine <input name='data_fine' placeholder='30/09/2027' required></label>
          <label>Preavviso (giorni) <input name='preavviso' value='30'></label>
          <button class='cta-primary'>Genera accordo DOCX</button>
        </form>"""
        return layout(html)

    parts = str(request.form.get("parti") or "").strip()
    start = str(request.form.get("data_inizio") or "").strip()
    end = str(request.form.get("data_fine") or "").strip()
    notice = str(request.form.get("preavviso") or "30").strip()
    if not parts or not start or not end:
        return redirect_with_message("/documenti/asd/accordo-spazi", "Compila parti e durata.", "error")

    cfg = load_config()
    dummy = {"nome":"","cognome":""}
    mapping = build_placeholder_map(cfg, dummy)
    mapping.update({
        "[PARTI CONTRAENTI]": parts,
        "[DATA INIZIO]": start,
        "[DATA FINE]": end,
        "[PREAVVISO]": notice,
        "[GIORNI ORARI]": "Lunedì e mercoledì, 2 ore per giornata, più ulteriori utilizzi previa disponibilità e accordo.",
        "[COSTI UTILIZZO]": "€ 1.000,00 mensili, comprensivi dei servizi accessori indicati nella convenzione.",
        "[CORRISPETTIVO]": "€ 1.000,00 mensili",
    })
    src = get_template_library_path("accordo_spazi.docx")
    if not src.exists():
        return redirect_with_message("/documenti", "Modello accordo spazi non disponibile.", "error")
    outdir = get_asd_media_dir()
    outdir.mkdir(parents=True, exist_ok=True)
    out = outdir / f"accordo_spazi_{now().strftime('%Y%m%d_%H%M%S')}.docx"
    try:
        compile_docx(src, out, mapping)
        return send_file(out, as_attachment=True, download_name=out.name)
    except Exception as exc:
        return redirect_with_message("/documenti", f"Errore generazione accordo: {exc}", "error")


@app.route("/collaboratori/f24/paga", methods=["POST"])
@login_required
def collaboratori_f24_paga():
    rec_id = parse_int(request.form.get("id"), 0)
    mese = parse_int(request.form.get("mese"), current_month_year()[0])
    anno = parse_int(request.form.get("anno"), current_month_year()[1])
    conn = db()
    try:
        conn.execute("UPDATE f24_sportivi SET stato='pagato' WHERE id=?", (rec_id,))
        conn.commit()
    finally:
        conn.close()
    return redirect_with_message(f"/collaboratori/f24?mese={mese}&anno={anno}", "F24 segnato come versato.", "success")


@app.route("/collaboratori/f24/pdf")
@login_required
def collaboratori_f24_pdf():
    mese, anno = _month_year()
    conn = db()
    try:
        rows = conn.execute(
            "SELECT * FROM f24_sportivi WHERE mese=? AND anno=? ORDER BY sezione, codice_tributo",
            (mese, anno),
        ).fetchall()
    finally:
        conn.close()

    pdfdir = get_pdf_dir("f24")
    pdfdir.mkdir(parents=True, exist_ok=True)
    path = pdfdir / f"prospetto_f24_{anno}_{mese:02d}.pdf"
    cfg = load_config()
    doccfg = cfg.get("documenti", {}) if isinstance(cfg.get("documenti"), dict) else {}
    title = (doccfg.get("denominazione") or cfg.get("nome_asd") or "ASD").strip()
    cf = (doccfg.get("cf") or "").strip()

    pdf = canvas.Canvas(str(path), pagesize=A4)
    width, height = A4
    y = height - 55
    pdf.setFont("Helvetica-Bold", 16); pdf.drawString(45, y, "PROSPETTO DATI F24")
    y -= 22
    pdf.setFont("Helvetica", 9); pdf.drawString(45, y, f"{title} — CF {cf} — periodo {mese:02d}/{anno}")
    lavoro_cfg = cfg.get("lavoro_sportivo", {}) if isinstance(cfg.get("lavoro_sportivo"), dict) else {}
    y -= 14; pdf.drawString(45, y, f"INPS sede: {str(lavoro_cfg.get('inps_codice_sede') or '-')[:18]}  |  Matricola/filiale: {str(lavoro_cfg.get('inps_filiale') or '-')[:55]}")
    y -= 28
    pdf.setFont("Helvetica-Bold", 9)
    pdf.drawString(45,y,"SEZIONE"); pdf.drawString(105,y,"CAUSALE"); pdf.drawString(160,y,"CODICE")
    pdf.drawString(230,y,"PERIODO"); pdf.drawString(330,y,"IMPORTO"); pdf.drawString(410,y,"SCADENZA")
    y -= 8; pdf.line(45,y,550,y); y -= 18
    pdf.setFont("Helvetica",9)
    total=0
    for r in rows:
        if y < 70:
            pdf.showPage(); y=height-55; pdf.setFont("Helvetica",9)
        amount=float(r["importo"] or 0); total+=amount
        pdf.drawString(45,y,str(r["sezione"] or "")[:9])
        pdf.drawString(105,y,str(r["causale"] or "")[:12])
        pdf.drawString(160,y,str(r["codice_tributo"] or "-")[:12])
        pdf.drawString(230,y,str(r["periodo_da"] or "")[:13])
        pdf.drawRightString(395,y,f"€ {amount:,.2f}")
        pdf.drawString(410,y,str(r["data_scadenza"] or "")[:12])
        y-=20
    pdf.line(45,y+7,550,y+7)
    pdf.setFont("Helvetica-Bold",10); pdf.drawRightString(395,y-10,f"TOTALE: € {total:,.2f}")
    y-=42
    pdf.setFont("Helvetica",8)
    for line in [
        "Documento di supporto: non è il modello F24 ufficiale e non viene trasmesso telematicamente dal gestionale.",
        "Verificare i dati con il consulente/intermediario e con le posizioni INPS/AE prima del pagamento.",
        "Il versamento resta da effettuare tramite i canali telematici previsti o tramite intermediario."
    ]:
        pdf.drawString(45,y,line); y-=12
    pdf.save()
    return send_file(path, as_attachment=True, download_name=path.name)


@app.route("/collaboratori/adempimenti")
@login_required
def collaboratori_adempimenti():
    mese, anno = _month_year()
    conn = db()
    try:
        rows = conn.execute("""SELECT nome,cognome,ruolo,tipo_rapporto,contratto_firmato,
                                      rasd_stato,rasd_data_comunicazione,uniemens_stato,data_fine
                               FROM collaboratori WHERE attivo=1 ORDER BY cognome,nome""").fetchall()
        f24 = conn.execute("""SELECT sezione,codice_tributo,importo,data_scadenza,stato
                              FROM f24_sportivi WHERE mese=? AND anno=?""",(mese,anno)).fetchall()
    finally:
        conn.close()
    html=f"""<div class='page-head'><div><div class='kicker'>Collaboratori</div>
    <h2 class='section-title'>Adempimenti</h2>
    <p class='small-muted'>Un'unica checklist locale per contratto, RASD, UNIEMENS e F24. Il gestionale non invia nulla online.</p></div>
    <div class='page-actions'><a class='cta-secondary' href='/collaboratori/mensile?mese={mese}&anno={anno}'>Liquidazione</a><a class='cta-secondary' href='/collaboratori'>Anagrafiche</a></div></div>
    <div class='card'><table><thead><tr><th>Collaboratore</th><th>Contratto</th><th>RASD</th><th>UNIEMENS</th><th>Fine</th></tr></thead><tbody>"""
    for r in rows:
        html+=f"""<tr><td>{e(r['nome'])} {e(r['cognome'])}<br><span class='small-muted'>{e(r['ruolo'] or '')}</span></td>
        <td>{'OK' if int(r['contratto_firmato'] or 0) else 'DA VERIFICARE'}</td>
        <td>{e(r['rasd_stato'] or 'da_verificare')} {e(r['rasd_data_comunicazione'] or '')}</td>
        <td>{e(r['uniemens_stato'] or 'da_verificare')}</td>
        <td>{e(r['data_fine'] or '')}</td></tr>"""
    html+="</tbody></table></div><div class='card'><h3 class='section-title'>F24 del periodo</h3><table><thead><tr><th>Sezione</th><th>Codice</th><th>Importo</th><th>Scadenza</th><th>Stato</th></tr></thead><tbody>"
    for r in f24:
        html+=f"<tr><td>{e(r['sezione'])}</td><td>{e(r['codice_tributo'])}</td><td>€ {float(r['importo'] or 0):.2f}</td><td>{e(r['data_scadenza'] or '')}</td><td>{e(r['stato'] or '')}</td></tr>"
    if not f24: html+="<tr><td colspan='5'>Nessun F24 preparato per il periodo.</td></tr>"
    html+="</tbody></table><p class='small-muted'>Per i co.co.co. sportivi l'INPS richiede anche il flusso UNIEMENS; le comunicazioni RASD vanno effettuate quando dovute (inizio, variazione, cessazione), non come un F24 mensile.</p></div>"
    return layout(html)
