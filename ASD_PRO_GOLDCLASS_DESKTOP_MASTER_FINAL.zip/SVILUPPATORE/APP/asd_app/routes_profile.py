from .core import *

@app.route("/profilo", methods=["GET", "POST"])
@login_required
def profilo():
    conn = db()
    c = conn.cursor()
    user = c.execute("SELECT id, username, full_name, email, role, must_change_password FROM users WHERE id=?", (session.get("user_id"),)).fetchone()
    if not user:
        conn.close()
        session.clear()
        return redirect("/login")

    if request.method == "POST":
        action = (request.form.get("action") or "").strip()
        if action == "update_me":
            full_name = truncate(request.form.get("full_name", "").strip(), 140)
            email = normalize_email(request.form.get("email", ""), 160)
            c.execute("UPDATE users SET full_name=?, email=?, updated_at=? WHERE id=?", (full_name, email, now_iso_dt(), user["id"]))
            conn.commit()
            session["display_name"] = full_name or user["username"]
            conn.close()
            return redirect_with_message("/profilo", "Profilo aggiornato.", "success")
        if action == "change_password":
            current_password = request.form.get("current_password", "")
            new_password = require_non_empty(request.form.get("new_password", ""), "Nuova password", 120)
            confirm_password = request.form.get("confirm_password", "")
            if new_password != confirm_password:
                conn.close()
                return redirect_with_message("/profilo", "Le nuove password non coincidono.", "error")
            row = c.execute("SELECT password FROM users WHERE id=?", (user["id"],)).fetchone()
            saved_password = row["password"] or ""
            valid = check_password_hash(saved_password, current_password) if saved_password.startswith(("pbkdf2:", "scrypt:")) else saved_password == current_password
            if not valid:
                conn.close()
                return redirect_with_message("/profilo", "Password attuale non valida.", "error")
            c.execute("UPDATE users SET password=?, must_change_password=0, updated_at=? WHERE id=?", (generate_password_hash(new_password), now_iso_dt(), user["id"]))
            conn.commit()
            conn.close()
            return redirect_with_message("/profilo", "Password aggiornata correttamente.", "success")

    conn.close()
    must_change = int(user["must_change_password"] or 0) == 1
    forced_banner = "<div class='live-alert yellow'><span class='badge-dot dot-yellow'></span><div>Devi aggiornare la password temporanea prima di continuare a usare il sistema in modo sicuro.</div></div>" if must_change else ""
    return layout(f"""
    <div class='card'>
        <div class='page-head'><div><div class='kicker'>Area personale</div><h2 class='section-title'>Profilo utente</h2></div></div>
        {forced_banner}
        <div class='grid-2'>
            <div class='card soft'>
                <h3 class='section-title'>Dati utente</h3>
                <form method='POST' class='form-row'>
                    {csrf_input()}
                    <input type='hidden' name='action' value='update_me'>
                    <input value='{e(user['username'])}' disabled>
                    <input value='{e(role_label(user['role']))}' disabled>
                    <input name='full_name' value='{e(user['full_name'] or '')}' placeholder='Nome completo'>
                    <input name='email' value='{e(user['email'] or '')}' placeholder='Email'>
                    <button>Salva dati</button>
                </form>
            </div>
            <div class='card soft'>
                <h3 class='section-title'>Sicurezza accesso</h3>
                <form method='POST' class='form-row'>
                    {csrf_input()}
                    <input type='hidden' name='action' value='change_password'>
                    <input type='password' name='current_password' placeholder='Password attuale' required>
                    <input type='password' name='new_password' placeholder='Nuova password' required>
                    <input type='password' name='confirm_password' placeholder='Conferma nuova password' required>
                    <button>Aggiorna password</button>
                </form>
            </div>
        </div>
    </div>
    """)
