# -*- coding: utf-8 -*-
from .core import *


def _a19_task_age_label(task):
    """Etichetta prudente di urgenza: usa i dati presenti senza inventare date."""
    try:
        meta = task.get("meta") or {}
        days = None
        for key in ("days_open", "giorni_aperto", "days_overdue", "giorni_scaduto", "days_since", "eta_giorni"):
            if meta.get(key) not in (None, ""):
                days = parse_int(meta.get(key), None)
                break
        if days is None:
            for key in ("days_open", "giorni_aperto", "days_overdue", "giorni_scaduto", "days_since", "eta_giorni"):
                if task.get(key) not in (None, ""):
                    days = parse_int(task.get(key), None)
                    break
        category = task.get("category") or ""
        severity = task.get("severity") or ""
        if days is not None and days >= 0:
            if category == "tesseramento":
                return f"aperto da {days} giorni" + (" · promemoria consigliato" if days >= 10 else f" · promemoria tra {max(0, 10-days)} giorni")
            if "scad" in (task.get("title") or "").lower() or severity == "critical":
                return f"urgenza da {days} giorni"
            return f"aperto da {days} giorni"
        if category == "tesseramento":
            return "bloccante subito · reminder dopo 10 giorni"
        if category == "pagamento":
            return "verifica incasso del periodo selezionato"
        if category == "certificato":
            return "controllo idoneità sportiva"
        if category == "minore":
            return "consenso/tutela da completare"
    except Exception:
        pass
    return "priorità operativa"

def _a19_task_class(task):
    status = (task.get("status") or task.get("task_status") or "").lower()
    return "in-work" if status == "in_lavorazione" else ""



@app.route("/promemoria/task-action", methods=["POST"])
@login_required
def promemoria_task_action():
    task_key = request.form.get("task_key", "").strip()
    status = request.form.get("status", "in_lavorazione").strip()
    note = request.form.get("note", "").strip()
    next_url = request.form.get("next", "/promemoria").strip() or "/promemoria"
    if not next_url.startswith("/"):
        next_url = "/promemoria"
    ok = set_operational_task_status(task_key, status, note, "presa_in_carico")
    if ok:
        return redirect_with_message(next_url, "Task operativo aggiornato: preso in carico.", "success")
    return redirect_with_message(next_url, "Non sono riuscito ad aggiornare il task operativo.", "error")


@app.route("/promemoria", methods=["GET", "POST"])
@login_required
def promemoria():
    mese, anno = current_month_year()
    mese = parse_int(request.args.get("mese", mese), mese)
    anno = parse_int(request.args.get("anno", anno), anno)
    tasks = get_operational_tasks(mese, anno)
    cards = render_operational_alert_cards(tasks, empty="Nessuna criticità aperta per il periodo selezionato.")
    return layout(f"""
    <div class='app-section-hero'><div><div class='kicker'>Controllo operativo</div><h2 class='section-title'>Promemoria</h2><div class='small-muted'>Qui trovi solo le cose da sistemare. Quando vuoi contattare qualcuno, usa Comunicazioni.</div></div><div class='page-actions'><a class='cta-secondary' href='/comunicazioni'>Mail e WhatsApp</a><a class='pro-cta strong' href='/'>Dashboard</a></div></div>
    <div class='card a2-filter-card'><form method='GET' class='form-row'><input type='number' name='mese' value='{mese}' min='1' max='12'><input type='number' name='anno' value='{anno}' min='2000'><button class='cta-primary'>Aggiorna</button></form></div>
    <div class='card a2-operational-board'><div class='table-toolbar'><div><h3 class='section-title' style='margin-bottom:4px;'>Criticità {mese:02d}/{anno}</h3><div class='small-muted'>Gli avvisi scompaiono quando correggi realmente il dato.</div></div></div><div class='a2-alert-list'>{cards}</div></div>
    """)

def _a17_clean_phone(raw: str) -> str:
    s = re.sub(r"\D+", "", str(raw or ""))
    if not s:
        return ""
    if s.startswith("00"):
        s = s[2:]
    if not s.startswith("39") and len(s) in (9, 10):
        s = "39" + s
    return s

def _a17_message_for_task(task: dict, mese: int, anno: int) -> str:
    cat = task.get("category") or "operativo"
    name = task.get("person_name") or "l'atleta"
    if cat == "pagamento":
        return f"Buongiorno, promemoria ASD: per {name} non risulta ancora registrata la quota mensile {int(mese):02d}/{int(anno)}. Quando possibile, inviate conferma del pagamento. Grazie."
    if cat == "tesseramento":
        return f"Buongiorno, promemoria ASD: per {name} risulta ancora da completare la quota di tesseramento/iscrizione {int(anno)}. Il tesseramento è obbligatorio e bloccante per la partecipazione alle attività. Grazie."
    if cat == "certificato":
        return f"Buongiorno, promemoria ASD: per {name} il certificato medico risulta mancante, scaduto o da aggiornare. Vi chiediamo di inviarlo prima della prossima attività. Grazie."
    if cat == "minore":
        return f"Buongiorno, promemoria ASD: per {name} risultano ancora da completare consenso/tutela o dati del genitore/tutore. Vi chiediamo di completarli prima della prossima lezione. Grazie."
    return f"Buongiorno, promemoria ASD: per {name} c'è una verifica da completare nella scheda atleta. Grazie."

def _a17_phone_for_tesserato(conn, tid: int) -> str:
    if not tid:
        return ""
    try:
        row = conn.execute("SELECT * FROM tesserati WHERE id=?", (int(tid),)).fetchone()
        if not row:
            return ""
        cols = set(row.keys()) if hasattr(row, "keys") else set()
        for col in ("telefono_genitore", "cellulare_genitore", "telefono_tutore", "telefono", "cellulare"):
            if col in cols:
                phone = _a17_clean_phone(row[col])
                if phone:
                    return phone
    except Exception:
        return ""
    return ""

@app.route("/comunicazioni", methods=["GET", "POST"])
@app.route("/promemoria/whatsapp", methods=["GET", "POST"])
@login_required
def comunicazioni():
    """Centro locale per creare e preparare comunicazioni. Nessun invio automatico."""
    cfg = load_config()
    mese, anno = current_month_year()
    mese = parse_int(request.values.get("mese", mese), mese)
    anno = parse_int(request.values.get("anno", anno), anno)

    if request.method == "POST":
        action = (request.form.get("action") or "").strip()
        email = (request.form.get("email") or "").strip()
        phone = _a17_clean_phone(request.form.get("phone") or "")
        subject = (request.form.get("subject") or "Comunicazione ASD").strip()[:180]
        body = (request.form.get("body") or "").strip()[:5000]
        if action == "mail":
            if str((cfg.get("mail") or {}).get("enabled", "0")) != "1":
                return redirect_with_message("/comunicazioni", "Email disattivata nelle impostazioni ASD.", "warning")
            if not email:
                return redirect_with_message("/comunicazioni", "Inserisci un indirizzo email.", "error")
            try:
                attachment = (request.form.get("attachment") or "").strip()
                attachment_path = Path(attachment).expanduser() if attachment else None
                if sys.platform == "darwin" and attachment_path and attachment_path.exists():
                    def aq(v):
                        return '"' + str(v).replace('\\', '\\\\').replace('"', '\\"').replace('\r', '\\r').replace('\n', '\\n') + '"'
                    script = (
                        f'tell application "Mail"\n'
                        f'set newMessage to make new outgoing message with properties {{subject:{aq(subject)}, content:{aq(body)}, visible:true}}\n'
                        f'tell newMessage\n'
                        f'make new to recipient at end of to recipients with properties {{address:{aq(email)}}}\n'
                        f'make new attachment with properties {{file name:(POSIX file {aq(str(attachment_path))})}} at after the last paragraph\n'
                        f'end tell\nactivate\nend tell'
                    )
                    subprocess.run(["osascript", "-e", script], check=True, capture_output=True, text=True)
                    return redirect_with_message("/comunicazioni", "Bozza Mail aperta con la ricevuta allegata. Controlla e premi Invia.", "success")
                mailto = f"mailto:{quote(email, safe='@._-+')}?subject={quote(subject, safe='')}&body={quote(body, safe='')}"
                return redirect(mailto)
            except Exception as exc:
                return redirect_with_message("/comunicazioni", f"Impossibile aprire Mail: {exc}", "error")
        if action == "whatsapp":
            if str((cfg.get("whatsapp") or {}).get("enabled", "1")) != "1":
                return redirect_with_message("/comunicazioni", "WhatsApp disattivato nelle impostazioni ASD.", "warning")
            if not phone:
                return redirect_with_message("/comunicazioni", "Inserisci un numero di telefono valido.", "error")
            return redirect(f"whatsapp://send?phone={phone}&text={quote(body, safe='')}")
        return redirect_with_message("/comunicazioni", "Azione non riconosciuta.", "error")

    tid = parse_int(request.args.get("tesserato_id", "0"), 0)
    receipt_id = parse_int(request.args.get("ricevuta_id", "0"), 0)
    doc_id = parse_int(request.args.get("doc_id", "0"), 0)
    preset_email = ""
    preset_phone = ""
    preset_subject = "Comunicazione BodyMind Aerial Studio ASD"
    preset_body = ""
    attachment = ""
    conn = db()
    try:
        if tid:
            row = conn.execute("""SELECT t.*, m.genitore, m.telefono_genitore, m.email_genitore
                                FROM tesserati t LEFT JOIN minori m ON m.tesserato_id=t.id WHERE t.id=?""", (tid,)).fetchone()
            if row:
                preset_email = str(row["email"] or row["email_genitore"] or "").strip()
                preset_phone = _a17_clean_phone(row["telefono"] or row["telefono_genitore"] or "")
        if receipt_id:
            rr = conn.execute("""SELECT r.*, p.tesserato_id, t.nome, t.cognome, t.email, t.telefono,
                                       m.email_genitore, m.telefono_genitore
                                FROM ricevute r JOIN pagamenti p ON p.id=r.pagamento_id
                                JOIN tesserati t ON t.id=p.tesserato_id
                                LEFT JOIN minori m ON m.tesserato_id=t.id WHERE r.id=?""", (receipt_id,)).fetchone()
            if rr:
                tid = int(rr["tesserato_id"] or tid or 0)
                preset_email = str(rr["email"] or rr["email_genitore"] or "").strip()
                preset_phone = _a17_phone_for_tesserato(conn, tid)
                name = f"{rr['nome']} {rr['cognome']}".strip()
                preset_subject = f"Ricevuta ASD - {name}"
                preset_body = "Buongiorno,\n\ncome richiesto, trova in allegato la ricevuta relativa al pagamento registrato presso BodyMind Aerial Studio ASD.\n\nGrazie."
                if rr["pdf_filename"]:
                    path = get_pdf_dir() / str(rr["pdf_filename"])
                    if path.exists():
                        attachment = str(path)
        if doc_id:
            dr = conn.execute("""SELECT d.*, t.nome, t.cognome, t.email, t.telefono,
                                      m.email_genitore, m.telefono_genitore
                               FROM documenti d JOIN tesserati t ON t.id=d.tesserato_id
                               LEFT JOIN minori m ON m.tesserato_id=t.id WHERE d.id=?""", (doc_id,)).fetchone()
            if dr:
                tid = int(dr["tesserato_id"] or tid or 0)
                preset_email = str(dr["email"] or dr["email_genitore"] or "").strip()
                preset_phone = _a17_phone_for_tesserato(conn, tid)
                preset_subject = f"Documento ASD - {dr['titolo']}"
                preset_body = f"Buongiorno,\n\ncome richiesto, trova in allegato il documento '{dr['titolo']}' relativo a {dr['nome']} {dr['cognome']}.\n\nGrazie."
                try:
                    doc_path = document_abs_path(dr["filename"])
                    if doc_path.exists(): attachment = str(doc_path)
                except Exception:
                    attachment = ""
    finally:
        conn.close()

    tipo = (request.args.get("tipo") or "tutti").strip().lower()
    cat_map = {"pagamenti":"pagamento", "tesseramenti":"tesseramento", "certificati":"certificato", "minori":"minore"}
    if tipo not in {"tutti", *cat_map.keys()}: tipo = "tutti"
    tasks = get_operational_tasks(mese, anno)
    if tipo != "tutti":
        tasks = [t for t in tasks if t.get("category") == cat_map[tipo]]
    conn = db(); rows=[]
    try:
        for task in tasks:
            meta=task.get("meta") or {}
            task_tid=parse_int(meta.get("tesserato_id",0),0)
            phone=_a17_phone_for_tesserato(conn,task_tid)
            name=task.get("person_name") or "Tesserato"
            msg=_a17_message_for_task(task,mese,anno)
            email=""
            if task_tid:
                r=conn.execute("SELECT email FROM tesserati WHERE id=?",(task_tid,)).fetchone()
                email=(r["email"] or "").strip() if r else ""
                if not email:
                    r=conn.execute("SELECT email_genitore FROM minori WHERE tesserato_id=?",(task_tid,)).fetchone()
                    email=(r["email_genitore"] or "").strip() if r else ""
            rows.append((task,phone,msg,email,name,task_tid))
    finally:
        conn.close()

    cards=[]
    for task,phone,msg,email,name,task_tid in rows:
        actions=[f"<a class='a2-btn ghost' href='/comunicazioni?tesserato_id={task_tid}&mese={mese}&anno={anno}'>Modifica messaggio</a>"]
        if phone and str((cfg.get("whatsapp") or {}).get("enabled","1"))=="1":
            actions.append(f"<a class='a2-btn primary whatsapp' href='whatsapp://send?phone={phone}&text={quote(msg,safe='')}'>WhatsApp</a>")
        if email and str((cfg.get("mail") or {}).get("enabled","0"))=="1":
            actions.append(f"<a class='a2-btn ghost' href='/comunicazioni?tesserato_id={task_tid}&mese={mese}&anno={anno}'>Email</a>")
        cards.append(f"<article class='a17-wa-card a19-wa-card {e(task.get('severity') or 'warning')}'><div><div class='a19-task-topline'><span class='a2-badge {e(task.get('severity') or 'warning')}'>{e((task.get('category') or 'task').upper())}</span></div><h3>{e(name)}</h3><p>{e(task.get('title') or '')}</p><details class='a19-wa-preview'><summary>Testo</summary><textarea readonly>{e(msg)}</textarea></details></div><div class='a17-wa-actions'>{''.join(actions)}</div></article>")
    body_html="".join(cards) or "<div class='a2-empty'><strong>Nessuna comunicazione suggerita</strong><span>Puoi comunque crearne una manualmente.</span></div>"
    attachment_html = f"<div class='live-alert green'><span class='badge-dot dot-green'></span><div><strong>Ricevuta pronta per la comunicazione</strong><div class='small-muted'>{e(Path(attachment).name)} · aprila e allegala alla mail quando la invii.</div><a href='/ricevute/pdf/{receipt_id}' target='_blank'>Apri ricevuta</a></div></div>" if attachment and receipt_id else ""
    return layout(f"""
    <div class='app-section-hero a17-wa-hero'><div><div class='kicker'>Comunicazioni</div><h2 class='section-title'>Comunicazioni</h2><div class='small-muted'>Un solo posto per creare e preparare email o WhatsApp. Nessun invio automatico.</div></div><a class='pro-cta strong' href='/'>Dashboard</a></div>
    {attachment_html}
    <section class='card'><div class='kicker'>Nuova comunicazione</div><h3 class='section-title'>Crea e prepara</h3>
      <form method='post' class='form-row'>{csrf_input()}<input type='hidden' name='attachment' value='{e(attachment)}'>
        <input name='email' value='{e(preset_email)}' placeholder='Email destinatario'>
        <input name='phone' value='{e(preset_phone)}' placeholder='Telefono WhatsApp'>
        <input name='subject' value='{e(preset_subject)}' placeholder='Oggetto'>
        <textarea name='body' rows='6' style='grid-column:1/-1' placeholder='Scrivi il messaggio...'>{e(preset_body)}</textarea>
        <div style='grid-column:1/-1;display:flex;gap:8px;flex-wrap:wrap'><button class='cta-primary' name='action' value='mail'>Apri in Mail</button><button class='cta-secondary' name='action' value='whatsapp'>Apri WhatsApp</button></div>
      </form>
    </section>
    <section class='pro-panel a17-automation-panel'><div class='a17-automation-head'><div><h2>Promemoria suggeriti</h2><p>Solo quelli utili. L'invio finale resta sempre sotto il tuo controllo.</p></div></div>
      <div class='a17-automation-grid'><a class='a17-automation-tile' href='/comunicazioni?tipo=tutti&mese={mese}&anno={anno}'><b>Tutti</b></a><a class='a17-automation-tile' href='/comunicazioni?tipo=pagamenti&mese={mese}&anno={anno}'><b>Pagamenti</b></a><a class='a17-automation-tile' href='/comunicazioni?tipo=tesseramenti&mese={mese}&anno={anno}'><b>Tesseramenti</b></a><a class='a17-automation-tile' href='/comunicazioni?tipo=certificati&mese={mese}&anno={anno}'><b>Certificati</b></a><a class='a17-automation-tile' href='/comunicazioni?tipo=minori&mese={mese}&anno={anno}'><b>Minori</b></a></div>
    </section><section class='a17-wa-list'>{body_html}</section>
    """)
