# -*- coding: utf-8 -*-
from .core import *


@app.route("/tesserati/guidato")
@login_required
def tesserato_guidato():
    html = """
    <div class='enterprise-shell'>
      <div class='enterprise-topbar'>
        <div class='left'>
          <a class='enterprise-btn primary' href='/'>Dashboard</a>
          <a class='enterprise-btn success' href='/presenze-rapide'>Registra presenze</a>
          <a class='enterprise-btn' href='/documenti'>Documenti</a>
        </div>
      </div>
      <section class='enterprise-section'>
        <h1>Nuovo tesserato</h1>
        <p>Flow guidato: anagrafica, documenti, corso, pagamento e presenze.</p>
        <div class='enterprise-big-actions'>
          <a class='enterprise-big-btn primary' href='/tesserati?new=1&drawer=1'><span class='ico'>+</span><span><b>Apri modulo tesserato</b><small>Funzione originale mantenuta</small></span></a>
          <a class='enterprise-big-btn' href='/documenti'><span class='ico'>D</span><span><b>Documenti DOCX</b><small>Compila modelli</small></span></a>
          <a class='enterprise-big-btn presenze' href='/presenze-rapide'><span class='ico'>P</span><span><b>Presenze rapide</b><small>Registro veloce</small></span></a>
          <a class='enterprise-big-btn' href='/pagamenti'><span class='ico'>€</span><span><b>Pagamenti</b><small>Quote e ricevute</small></span></a>
        </div>
      </section>
    </div>
    """
    return layout(html)


@app.route("/presenze-rapide", methods=["GET", "POST"])
@login_required
def presenze_rapide():
    conn = db()
    today = request.values.get("data") or now_iso_date()
    corso_id = parse_int(request.values.get("corso_id"), 0)

    corsi = conn.execute("SELECT id,nome,orario FROM corsi ORDER BY nome").fetchall()
    if corso_id <= 0 and corsi:
        corso_id = int(corsi[0]["id"])

    selected_course = None
    if corso_id > 0:
        selected_course = conn.execute("SELECT * FROM corsi WHERE id=?", (corso_id,)).fetchone()

    if request.method == "POST":
        action = request.form.get("action", "")
        corso_id = parse_int(request.form.get("corso_id"), 0)
        data = require_valid_date(request.form.get("data", today), "data presenza")
        if corso_id <= 0:
            conn.close()
            return redirect_with_message("/presenze-rapide", "Seleziona un corso.", "error")
        corso_row = conn.execute("SELECT * FROM corsi WHERE id=?", (corso_id,)).fetchone()
        if not corso_row:
            conn.close()
            return redirect_with_message("/presenze-rapide", "Corso non trovato.", "error")

        # Metodo forense: processa solo gli iscritti al corso selezionato, come Registro presenze.
        all_ids = [int(r["id"]) for r in conn.execute("SELECT id FROM tesserati WHERE corso=? ORDER BY cognome,nome", (corso_row["nome"],)).fetchall()]
        checked_ids = {parse_int(x, 0) for x in request.form.getlist("tesserato_id")}
        try:
            conn.execute("DELETE FROM presenze WHERE corso_id=? AND data=?", (corso_id, data))
            for tid in all_ids:
                if action == "tutti_presenti":
                    stato = "presente"
                elif action == "tutti_assenti":
                    stato = "assente"
                else:
                    stato = request.form.get(f"stato_{tid}") or ("presente" if tid in checked_ids else "assente")
                note = truncate(request.form.get(f"note_{tid}", ""), 240)
                conn.execute("INSERT INTO presenze(tesserato_id,corso_id,data,stato,note,created_at,updated_at) VALUES(?,?,?,?,?,?,?)", (tid, corso_id, data, stato, note, now_iso_dt(), now_iso_dt()))
            conn.commit()
            conn.close()
            return redirect_with_message(f"/presenze-rapide?data={data}&corso_id={corso_id}", "Registro rapido salvato: presenti e assenti coerenti con il corso.", "success")
        except Exception as exc:
            conn.rollback()
            conn.close()
            return redirect_with_message("/presenze-rapide", f"Errore presenze: {exc}", "error")

    tesserati = []
    pres = {}
    if selected_course:
        tesserati = conn.execute("SELECT id,nome,cognome,corso,certificato_scadenza FROM tesserati WHERE corso=? ORDER BY cognome,nome", (selected_course["nome"],)).fetchall()
        for r in conn.execute("SELECT * FROM presenze WHERE corso_id=? AND data=?", (corso_id, today)).fetchall():
            pres[int(r["tesserato_id"])] = r
    conn.close()

    present_count = sum(1 for t in tesserati if (pres.get(int(t["id"])) and (pres[int(t["id"])] ["stato"] or "") == "presente"))
    justified_count = sum(1 for t in tesserati if (pres.get(int(t["id"])) and (pres[int(t["id"])] ["stato"] or "") == "giustificato"))
    absent_count = max(0, len(tesserati) - present_count - justified_count)

    opts = "<option value='0'>Seleziona corso</option>" + "".join([f"<option value='{int(c['id'])}' {'selected' if int(c['id'])==corso_id else ''}>{e(c['nome'])} {e(c['orario'] or '')}</option>" for c in corsi])
    rows = []
    for t in tesserati:
        p = pres.get(int(t["id"]))
        stato = p["stato"] if p else "assente"
        dot = "presente" if stato == "presente" else ("giustificato" if stato == "giustificato" else "assente")
        rows.append(f"""
        <tr>
          <td><b>{e(t['cognome'])} {e(t['nome'])}</b><small>{e(t['corso'] or 'Corso non assegnato')}</small></td>
          <td style='text-align:center'><span class='presence-dot {dot}'></span><span class='presenze-status-label'>{e(stato.capitalize())}</span></td>
          <td><input type='checkbox' name='tesserato_id' value='{int(t['id'])}' {'checked' if stato=='presente' else ''} style='min-width:auto;transform:scale(1.2);'></td>
          <td><select name='stato_{int(t['id'])}'><option value='presente' {'selected' if stato=='presente' else ''}>Presente</option><option value='assente' {'selected' if stato=='assente' else ''}>Assente</option><option value='giustificato' {'selected' if stato=='giustificato' else ''}>Giustificato</option></select></td>
          <td><input name='note_{int(t['id'])}' value='{e(p['note'] if p else '')}' placeholder='nota veloce'></td>
        </tr>
        """)
    rows_html = "".join(rows) or "<tr><td colspan='5'><div class='empty-state'>Nessun atleta collegato a questo corso.</div></td></tr>"

    html = f"""
    <div class='enterprise-shell presenze-rapide-pro'>
      <div class='enterprise-topbar'><div class='left'><a class='enterprise-btn primary' href='/'>Dashboard</a><a class='enterprise-btn success' href='/presenze'>Registro completo</a><a class='enterprise-btn' href='/corsi'>Corsi</a></div></div>
      {get_page_alert_html()}
      <section class='presenze-saas-hero'>
        <div class='presenze-saas-panel'>
          <div class='kicker'>Registro veloce</div>
          <h1>Presenze rapide</h1>
          <p>Stessa logica del Registro presenze, ma con meno passaggi: scegli corso e data, controlla i pallini, salva presenti e assenti in un colpo solo.</p>
          <div class='presenze-kpi-grid'>
            <div class='presenze-kpi presente'><span>Presenti</span><b>{present_count}</b></div>
            <div class='presenze-kpi assente'><span>Assenti</span><b>{absent_count}</b></div>
            <div class='presenze-kpi totale'><span>Totale corso</span><b>{len(tesserati)}</b></div>
          </div>
        </div>
        <form method='get' class='presenze-saas-panel'>
          <h3>Filtro rapido</h3>
          <p>Il registro rapido carica solo gli iscritti al corso selezionato.</p>
          <div class='form-row' style='margin-top:14px;'>
            <select name='corso_id'>{opts}</select>
            <input type='date' name='data' value='{e(today)}'>
            <button class='enterprise-btn'>Aggiorna</button>
          </div>
        </form>
      </section>
      <form method='post' class='enterprise-section'>
        {csrf_input()}
        <input type='hidden' name='corso_id' value='{int(corso_id)}'>
        <input type='hidden' name='data' value='{e(today)}'>
        <div class='enterprise-section-head'>
          <div><h2>Registro del giorno</h2><p class='small-muted'>Verde presente, rosso assente, giallo giustificato.</p></div>
          <div class='presenze-actions'>
            <button type='submit' class='success' name='action' value='tutti_presenti'>Tutti presenti</button>
            <button type='submit' class='danger' name='action' value='tutti_assenti'>Tutti assenti</button>
            <button type='submit' class='success' name='action' value='salva'>Salva registro</button>
          </div>
        </div>
        <div class='presenze-table-wrap'>
          <table><tr><th>Tesserato</th><th style='text-align:center'>Stato</th><th>Presente</th><th>Correzione</th><th>Note</th></tr>{rows_html}</table>
        </div>
      </form>
    </div>
    """
    return layout(html)


