# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
from PyInstaller.utils.hooks import collect_submodules

base = Path.cwd().resolve()

hiddenimports = []
# Raccogliamo solo i moduli necessari all’app desktop Mac.
for pkg in ["asd_app", "webview"]:
    try:
        hiddenimports += collect_submodules(pkg)
    except Exception:
        pass

for extra in [
    "desktop_boot",
    
    "webview.platforms.cocoa",
]:
    if extra not in hiddenimports:
        hiddenimports.append(extra)

datas = []
for folder in ["templates", "static"]:
    p = base / folder
    if p.exists():
        datas.append((str(p), folder))

# Include solo modelli/documenti base dell'app: nessun DB, nessun tenant, nessun PDF generato.
models_dir = base / "media" / "modelli_asd"
if models_dir.exists():
    datas.append((str(models_dir), "media/modelli_asd"))

for optional in ["logo_enterprise.png", "app_icon.png"]:
    p = base / optional
    if p.exists():
        datas.append((str(p), "."))

icon_path = base / "static" / "app_icon.icns"
icon_value = str(icon_path) if icon_path.exists() else None

block_cipher = None

a = Analysis(
    ["desktop_webview.py"],
    pathex=[str(base)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "numpy",
        "pandas",
        "matplotlib",
        "scipy",
    ],
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# IMPORTANTE:
# Build macOS in modalità ONEDIR + BUNDLE, non onefile.
# Questo evita il crash PyInstaller/macOS 10.13:
# AssertionError: Executable contains code signature!
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="ASD Pro Goldclass",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    icon=icon_value,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="ASD Pro Goldclass",
)

app = BUNDLE(
    coll,
    name="ASD Pro Goldclass.app",
    icon=icon_value,
    bundle_identifier="it.asdprosystem.goldclass",
    info_plist={
        "CFBundleName": "ASD Pro Goldclass",
        "CFBundleDisplayName": "ASD Pro Goldclass",
        "CFBundleIdentifier": "it.asdprosystem.goldclass",
        "CFBundleVersion": "1.0.0",
        "CFBundleShortVersionString": "1.0.0",
        "NSHighResolutionCapable": True,
    },
)
