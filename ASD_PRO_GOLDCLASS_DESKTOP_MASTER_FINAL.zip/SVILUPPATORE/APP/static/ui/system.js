(function () {
  'use strict';

  function ready(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  function textOf(node) {
    return (node ? node.textContent : '').replace(/\s+/g, ' ').trim();
  }

  function norm(value) {
    return String(value || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  }

  function parseValue(value) {
    var raw = textOf(value);
    var normalizedNumber = raw
      .replace(/\s/g, '')
      .replace(/€/g, '')
      .replace(/\./g, '')
      .replace(',', '.');
    if (/^-?\d+(\.\d+)?$/.test(normalizedNumber)) {
      return { type: 'number', value: parseFloat(normalizedNumber) };
    }
    var dateMatch = raw.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
    if (dateMatch) {
      var year = dateMatch[3].length === 2 ? '20' + dateMatch[3] : dateMatch[3];
      return { type: 'date', value: new Date(Number(year), Number(dateMatch[2]) - 1, Number(dateMatch[1])).getTime() };
    }
    return { type: 'text', value: norm(raw) };
  }

  function wrapTables() {
    document.querySelectorAll('table').forEach(function (table) {
      if (table.closest('.settings-permissions-table')) return;
      if (table.closest('.table-responsive, .table-wrapper, .responsive-table, .ui-table-scroll')) return;
      var wrapper = document.createElement('div');
      wrapper.className = 'ui-table-scroll';
      table.parentNode.insertBefore(wrapper, table);
      wrapper.appendChild(table);
    });
  }

  function enhanceFileInputs() {
    document.querySelectorAll('input[type="file"]').forEach(function (input, index) {
      if (input.closest('.ui-file-upload')) return;

      var id = input.id || ('ui-file-input-' + index + '-' + Math.random().toString(36).slice(2));
      input.id = id;

      var wrapper = document.createElement('div');
      wrapper.className = 'ui-file-upload';

      var label = document.createElement('label');
      label.className = 'ui-file-label';
      label.setAttribute('for', id);
      label.innerHTML = '<span aria-hidden="true">📎</span><span>Seleziona file</span>';

      var name = document.createElement('span');
      name.className = 'ui-file-name';
      name.textContent = 'Nessun file selezionato';

      input.classList.add('ui-file-native');
      input.parentNode.insertBefore(wrapper, input);
      wrapper.appendChild(input);
      wrapper.appendChild(label);
      wrapper.appendChild(name);

      input.addEventListener('change', function () {
        var files = Array.prototype.slice.call(input.files || []);
        if (!files.length) {
          name.textContent = 'Nessun file selezionato';
        } else if (files.length === 1) {
          name.textContent = files[0].name;
        } else {
          name.textContent = files.length + ' file selezionati';
        }
      });

      ['dragenter', 'dragover'].forEach(function (eventName) {
        wrapper.addEventListener(eventName, function (event) {
          event.preventDefault();
          wrapper.classList.add('is-dragover');
        });
      });

      ['dragleave', 'drop'].forEach(function (eventName) {
        wrapper.addEventListener(eventName, function () {
          wrapper.classList.remove('is-dragover');
        });
      });
    });
  }

  function setupSidebar() {
    var button = document.querySelector('.ui-mobile-menu');
    var sidebar = document.getElementById('app-sidebar') || document.querySelector('.sidebar');
    var backdrop = document.querySelector('.ui-sidebar-backdrop');
    if (!button || !sidebar || !backdrop) return;

    function openSidebar() {
      document.body.classList.add('ui-sidebar-open');
      button.setAttribute('aria-expanded', 'true');
      backdrop.hidden = false;
    }

    function closeSidebar() {
      document.body.classList.remove('ui-sidebar-open');
      button.setAttribute('aria-expanded', 'false');
      backdrop.hidden = true;
    }

    button.addEventListener('click', function () {
      if (document.body.classList.contains('ui-sidebar-open')) closeSidebar();
      else openSidebar();
    });

    backdrop.addEventListener('click', closeSidebar);

    sidebar.addEventListener('click', function (event) {
      var link = event.target.closest('a');
      if (link && window.matchMedia('(max-width: 900px)').matches) closeSidebar();
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') closeSidebar();
    });
  }

  function markActionCells() {
    document.querySelectorAll('table tr').forEach(function (row) {
      var cells = row.children;
      if (!cells.length) return;
      var last = cells[cells.length - 1];
      if (last && last.querySelector('a, button, form')) last.classList.add('table-actions');
    });
  }

  function createControlButton(label, className, onClick) {
    var button = document.createElement('button');
    button.type = 'button';
    button.className = className || 'ui-table-btn';
    button.textContent = label;
    button.addEventListener('click', onClick);
    return button;
  }

  function enhanceDataTables() {
    document.querySelectorAll('.ui-table-scroll table, .table-responsive table, .table-wrapper table, .responsive-table table').forEach(function (table, tableIndex) {
      if (table.dataset.uiTableEnhanced === '1') return;
      if (table.closest('.ui-no-table-tools')) return;

      var thead = table.tHead;
      var tbody = table.tBodies && table.tBodies[0];
      if (!thead || !tbody) return;

      var rows = Array.prototype.slice.call(tbody.rows || []);
      var headers = Array.prototype.slice.call(thead.querySelectorAll('th'));
      if (rows.length < 8 || headers.length < 2) return;
      if (table.querySelector('tbody input, tbody select, tbody textarea')) return;

      table.dataset.uiTableEnhanced = '1';
      table.classList.add('ui-data-table');

      var scroll = table.closest('.ui-table-scroll, .table-responsive, .table-wrapper, .responsive-table');
      if (!scroll) return;
      scroll.classList.add('ui-data-table-wrap');

      var state = {
        allRows: rows,
        filteredRows: rows.slice(),
        page: 1,
        perPage: rows.length > 50 ? 25 : rows.length > 20 ? 20 : 10,
        sortIndex: null,
        sortDir: 1,
        query: ''
      };

      var controls = document.createElement('div');
      controls.className = 'ui-table-tools';
      controls.setAttribute('data-table-index', String(tableIndex));

      var searchWrap = document.createElement('label');
      searchWrap.className = 'ui-table-search';
      searchWrap.innerHTML = '<span>Cerca</span>';
      var search = document.createElement('input');
      search.type = 'search';
      search.placeholder = 'Filtra righe...';
      search.autocomplete = 'off';
      searchWrap.appendChild(search);

      var perPageWrap = document.createElement('label');
      perPageWrap.className = 'ui-table-page-size';
      perPageWrap.innerHTML = '<span>Righe</span>';
      var perPage = document.createElement('select');
      [10, 20, 25, 50, 100].forEach(function (size) {
        var option = document.createElement('option');
        option.value = String(size);
        option.textContent = String(size);
        if (size === state.perPage) option.selected = true;
        perPage.appendChild(option);
      });
      if (state.allRows.length < state.perPage) {
        state.perPage = Math.max(10, state.allRows.length);
      }
      perPageWrap.appendChild(perPage);

      var summary = document.createElement('div');
      summary.className = 'ui-table-summary';

      var pagination = document.createElement('div');
      pagination.className = 'ui-table-pagination';
      var prev = createControlButton('‹', 'ui-table-btn ui-table-prev', function () {
        if (state.page > 1) {
          state.page -= 1;
          render();
        }
      });
      var pageLabel = document.createElement('span');
      pageLabel.className = 'ui-table-page-label';
      var next = createControlButton('›', 'ui-table-btn ui-table-next', function () {
        var maxPage = Math.max(1, Math.ceil(state.filteredRows.length / state.perPage));
        if (state.page < maxPage) {
          state.page += 1;
          render();
        }
      });
      pagination.appendChild(prev);
      pagination.appendChild(pageLabel);
      pagination.appendChild(next);

      controls.appendChild(searchWrap);
      controls.appendChild(perPageWrap);
      controls.appendChild(summary);
      controls.appendChild(pagination);
      scroll.parentNode.insertBefore(controls, scroll);

      headers.forEach(function (th, index) {
        if (!textOf(th)) return;
        if (th.querySelector('a, button, input, select')) return;
        th.classList.add('ui-sortable-th');
        th.tabIndex = 0;
        th.setAttribute('role', 'button');
        th.setAttribute('aria-sort', 'none');
        th.title = 'Ordina per ' + textOf(th);
        th.addEventListener('click', function () { sortBy(index); });
        th.addEventListener('keydown', function (event) {
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            sortBy(index);
          }
        });
      });

      search.addEventListener('input', function () {
        state.query = norm(search.value);
        state.page = 1;
        filterRows();
        render();
      });

      perPage.addEventListener('change', function () {
        state.perPage = Number(perPage.value) || 25;
        state.page = 1;
        render();
      });

      function filterRows() {
        if (!state.query) {
          state.filteredRows = state.allRows.slice();
          return;
        }
        state.filteredRows = state.allRows.filter(function (row) {
          return norm(textOf(row)).indexOf(state.query) !== -1;
        });
      }

      function sortBy(index) {
        if (state.sortIndex === index) state.sortDir *= -1;
        else {
          state.sortIndex = index;
          state.sortDir = 1;
        }

        headers.forEach(function (th, i) {
          th.classList.toggle('is-sorted', i === state.sortIndex);
          th.classList.toggle('is-desc', i === state.sortIndex && state.sortDir < 0);
          th.setAttribute('aria-sort', i === state.sortIndex ? (state.sortDir > 0 ? 'ascending' : 'descending') : 'none');
        });

        state.allRows.sort(function (a, b) {
          var av = parseValue(a.cells[index]);
          var bv = parseValue(b.cells[index]);
          var result;
          if (av.type === 'number' && bv.type === 'number') result = av.value - bv.value;
          else if (av.type === 'date' && bv.type === 'date') result = av.value - bv.value;
          else result = String(av.value).localeCompare(String(bv.value), 'it', { numeric: true, sensitivity: 'base' });
          return result * state.sortDir;
        });
        filterRows();
        render();
      }

      function render() {
        var maxPage = Math.max(1, Math.ceil(state.filteredRows.length / state.perPage));
        if (state.page > maxPage) state.page = maxPage;

        var start = (state.page - 1) * state.perPage;
        var end = start + state.perPage;
        var visible = state.filteredRows.slice(start, end);
        var fragment = document.createDocumentFragment();

        state.allRows.forEach(function (row) {
          row.hidden = true;
        });
        visible.forEach(function (row) {
          row.hidden = false;
          fragment.appendChild(row);
        });
        tbody.appendChild(fragment);

        var from = state.filteredRows.length ? start + 1 : 0;
        var to = Math.min(end, state.filteredRows.length);
        summary.textContent = from + '-' + to + ' di ' + state.filteredRows.length + (state.filteredRows.length !== state.allRows.length ? ' filtrate' : '');
        pageLabel.textContent = state.page + ' / ' + maxPage;
        prev.disabled = state.page <= 1;
        next.disabled = state.page >= maxPage;
        pagination.hidden = state.filteredRows.length <= state.perPage && state.allRows.length <= state.perPage;
      }

      filterRows();
      render();
    });
  }

  ready(function () {
    wrapTables();
    enhanceFileInputs();
    markActionCells();
    setupSidebar();
    enhanceDataTables();
  });
})();
