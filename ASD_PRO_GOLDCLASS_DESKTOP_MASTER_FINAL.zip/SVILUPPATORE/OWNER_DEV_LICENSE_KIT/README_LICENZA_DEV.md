# Licenza sviluppo — SOLO PROPRIETARIO

Questa cartella è per Daniele/sviluppatore, non per il cliente finale.

## Regola
- `OWNER_DEV_LICENSE_KIT/.developer_bypass` rimane qui come chiave di sviluppo.
- Non copiare questa cartella dentro `SVILUPPATORE/APP` prima di creare DMG/EXE.
- Non consegnare questa cartella ai clienti.

## Runtime cliente
La licenza cliente deve stare solo in:

- macOS: `~/Library/Application Support/ASD Pro Goldclass/license.json`
- macOS: `~/Library/Application Support/ASD Pro Goldclass/license.json`

## Build commerciale
Gli spec PyInstaller includono solo `templates/`, `static/` e icone/logo di sistema.
Non includono database, tenant, PDF, licenze, bypass, log o dati cliente.
