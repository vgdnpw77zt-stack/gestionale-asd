#!/usr/bin/env python3
"""
Generatore licenza cliente - SOLO SVILUPPATORE.
Non includere questo file nella build cliente.
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

def main() -> int:
    parser = argparse.ArgumentParser(description="Genera license.json firmato per ASD Pro Goldclass")
    parser.add_argument("--app-dir", default="../APP", help="Percorso cartella APP")
    parser.add_argument("--cliente", required=True)
    parser.add_argument("--codice", required=True)
    parser.add_argument("--scadenza", required=True, help="Formato YYYY-MM-DD")
    parser.add_argument("--max-utenti", type=int, default=3)
    parser.add_argument("--piano", default="standard")
    parser.add_argument("--feature", action="append", default=[])
    parser.add_argument("--out", default="license.json")
    args = parser.parse_args()
    app_dir = Path(args.app_dir).resolve()
    sys.path.insert(0, str(app_dir))
    from asd_app.license_manager import save_license
    data = {
        "cliente": args.cliente,
        "codice_cliente": args.codice,
        "scadenza": args.scadenza,
        "max_utenti": args.max_utenti,
        "piano": args.piano,
        "features": args.feature,
    }
    out = Path(args.out).resolve()
    save_license(data, out)
    print(f"Licenza creata: {out}")
    print("Installarla nel runtime cliente, NON dentro il DMG/EXE.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
