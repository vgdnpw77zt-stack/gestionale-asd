#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
xattr -cr "$SCRIPT_DIR" 2>/dev/null || true
chmod -R u+rwX "$SCRIPT_DIR" 2>/dev/null || true
find "$SCRIPT_DIR" -name "*.command" -exec chmod +x {} \; 2>/dev/null || true
find "$SCRIPT_DIR" -name "*.sh" -exec chmod +x {} \; 2>/dev/null || true
bash "$SCRIPT_DIR/SVILUPPATORE/MAC/INSTALLA_E_AVVIA.command"
