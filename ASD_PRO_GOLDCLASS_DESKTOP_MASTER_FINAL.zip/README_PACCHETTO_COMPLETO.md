# ASD Pro Goldclass — versione desktop locale Mac

Questa versione è pensata per l'uso **locale sul Mac**, senza servizi online, cloud, PWA, Stripe, OpenAI, provider WhatsApp o integrazioni remote.

## Cosa contiene

- gestionale ASD completo;
- anagrafiche tesserati e minori;
- corsi e presenze;
- pagamenti, ricevute e contabilità;
- documenti e modelli DOCX;
- fatture con generazione locale PDF/XML;
- collaboratori e relative ricevute;
- promemoria operativi;
- comunicazioni tramite le app del Mac (Mail e WhatsApp);
- backup e ripristino locale;
- utenti, ruoli e permessi;
- licenza locale.

## Comunicazioni

Il software non conserva credenziali SMTP, token API o provider WhatsApp.

- **Email:** prepara un messaggio nel client Mail del Mac.
- **WhatsApp:** apre l'app WhatsApp con il destinatario e il testo già compilati.
- L'ultimo clic su **Invia** resta sempre sotto il controllo dell'operatore.

L'invio automatico tramite WhatsApp personale senza un servizio/API esterno non è una funzione affidabile del desktop e quindi non viene simulato.

## Dati

I dati di lavoro sono separati dal programma e restano nel profilo utente macOS:

`~/Library/Application Support/ASD Pro Goldclass`

Il pacchetto applicativo non deve contenere database cliente, backup, segreti o file di licenza.

## Avvio

Per l'uso in sviluppo:

`AVVIO_SENZA_PRIVILEGI.command`

Per creare l'app Mac:

`SVILUPPATORE/MAC/BUILD_MAC_APP.command`

Per creare il DMG:

`SVILUPPATORE/MAC/BUILD_MAC_DMG.command`

Il bypass sviluppo rimane esclusivamente in:

`SVILUPPATORE/OWNER_DEV_LICENSE_KIT/`

## Filosofia di questa versione

Niente report automatici, audit operativi, dashboard tecniche, servizi cloud o configurazioni che non servono al lavoro quotidiano.

Il software deve fare una cosa bene: **gestire l'ASD localmente, salvare i dati in modo affidabile e rendere semplici le operazioni quotidiane.**
