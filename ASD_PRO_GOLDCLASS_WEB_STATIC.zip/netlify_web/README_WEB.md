# ASD Pro Goldclass — Web static package

Questa cartella è una **versione statica/front-end** pronta per GitHub Pages o Netlify.

## Pubblicazione

### Netlify
Caricare questa cartella come sito statico oppure collegare il repository. Il file di ingresso è `index.html`.

### GitHub Pages
Mettere il contenuto della cartella nella root del repository e abilitare GitHub Pages dalla branch desiderata.

## Importante

Il gestionale desktop originale è un'app Flask + SQLite locale. GitHub Pages e un deploy Netlify statico **non eseguono il backend Flask né SQLite**. Perciò questa cartella non contiene database, Python, licenze, segreti, build Mac, backup, tenant o strumenti di sviluppo.

La demo usa `localStorage` solo per mostrare il flusso dell'interfaccia nel browser. Non deve essere considerata una conversione online completa del gestionale desktop.

Per trasformare il gestionale in una vera applicazione web multiutente servirebbe un backend web separato, autenticazione, database server e gestione sicura dei documenti/backup.
